# HAL / APP / OSAL 任务阅读指南

当前串口规范已精简为4条常用查询和TIME/DB两组维护命令，见 [简明指令与变量规范](串口简明指令与变量规范.md)。旧独立命令已合并。

2026-10-05。两个角色主文件负责调度，app 保存业务，hal 保存自制板驱动。串口解析和自定义通信恢复旧项目的文件名、函数名及阅读顺序。Z-Stack 原任务表、自动组网、AF、ZDO、库和链接配置保持原有路径。

以下路径相对于 `Texas Instruments/ZStack-CC2530-2.5.1a/Projects/zstack/Samples/SampleApp/`。

```text
SampleApp/
├─ Source/
│  ├─ Coordinator.c       协调器任务：初始化、消息、定时事件
│  ├─ EndDevice.c         终端任务：初始化、消息、定时事件
│  ├─ SampleApp.h         端点、Cluster、事件位、周期
│  └─ OSAL_SampleApp.c    SDK 原任务注册
├─ app/
│  ├─ app_coordinator.c   协调器串口、刷卡请求、结果、同步
│  ├─ app_terminal.c      终端串口、刷卡、提交、远程请求
│  ├─ app_database.c      终端 AT24C08 名单和循环考勤
│  ├─ app_host_store.c    协调器 AT24C02 本机成功刷卡统计
│  ├─ app_ui.c            中文页面、倒计时、结果
│  ├─ app_font.h          页面所需的 90 个汉字
│  └─ Common/
│     ├─ device1_uart.c   旧式命令定位、类型识别、拆参数和回调
│     ├─ comm_unicast.c   旧项目单播初始化、发送、接收回调
│     ├─ comm_broadcast.c 旧项目广播初始化、发送、接收回调
│     └─ comm_protocol.c  旧式校验、打包、验证、解包；保留 ATT2
└─ hal/
   ├─ board/board_config.h 自制板引脚、安全上电电平
   ├─ hal_basic.c          LED、按键消抖、蜂鸣器
   ├─ hal_console_uart.c   UART 收发缓存、分行
   ├─ hal_i2c.c            软件 I2C
   ├─ hal_eeprom.c         EEPROM 分页、块寻址
   ├─ hal_rtc.c            RX8010 时钟读写、日期检查
   ├─ hal_rc522.c          软件 SPI、选卡、UID
   ├─ hal_oled.c           SSD1306 命令、分段写入
   └─ hal_delay.c          原短延时接口
```

IAR 的 `App` 节点内用 `hal` 和 `app` 分组，`app` 内含 `Common`，对应实际文件夹。SDK 自己的 `HAL` 分组仍属于协议栈。`CoordinatorEB` 只选协调器任务及业务、统计；`EndDeviceEB` 只选终端任务及业务、数据库。两个角色不再混用 `ROLE` 或 `ATT_TERMINAL` 分支。

## 阅读顺序

先读 `SampleApp.h`，再读 `Coordinator.c` 或 `EndDevice.c` 的 `SampleApp_Init()` 和 `SampleApp_ProcessEvent()`。串口、单播、广播的初始化和业务回调注册直接写在主文件中；每段事件直接调用明确的业务入口。了解某项业务，再跳转到对应 `App_Coordinator_*` / `App_Terminal_*` 函数，最后看它使用的 `Hal_*` 驱动。

例如终端考勤：

```text
SAMPLEAPP_CARD_EVT
  → App_Terminal_Card_Process()
  → 读取 UID 和当前 RTC，按模式执行 App_Database_Execute()

SAMPLEAPP_DATABASE_EVT
  → App_Terminal_Database_Process()
  → 推进 EEPROM 写入、验证、提交
  → 完成后显示结果、蜂鸣、回复请求或上报事件
```

EEPROM 异步提交保留必要状态机，避免一个事件持续等待写入完成；没有增加通用任务框架或第二套调度器。

## 事件与业务入口

`<角色>` 在协调器文件为 `Coordinator`，在终端文件为 `Terminal`。周期和事件位统一在 `SampleApp.h`。

| 事件 | 周期 / 来源 | 主文件调用 | 工作 |
|---|---|---|---|
| `SYS_EVENT_MSG` | SDK 消息 | 原 `switch` 分发 | 逐条处理、释放消息 |
| `INIT_EVT` | 上电 1000 ms，步骤间隔 100 ms | `App_<角色>_Peripherals_Process` | 分步初始化；完成后只启动一次刷卡和存储定时器 |
| `KEY_SCAN_EVT` | 10 ms | `Hal_Key_Poll` → `App_<角色>_Key_Process` | 30 ms 消抖、注册、注销、切换、退出 |
| `UART_RX_EVT` | UART 回调置事件 | `Hal_Uart_Process_Rx` → `SampleApp_SerialCMD` | 收齐完整行，按旧项目入口解析并调用角色命令业务 |
| `DATABASE_EVT` | 10 ms，外设就绪后 | `App_<角色>_Database_Process` | 协调器统计；终端数据库及完成应答 |
| `CONSOLE_EVT` | 10 ms | `Hal_Uart_Flush` → `App_<角色>_Console_Process` | TX、逐条 HELP / 名单 / 日志 / CSV |
| `OLED_EVT` | 10 ms | `App_<角色>_Display_Process` | 就绪后每次最多写 31 列 |
| `CARD_EVT` | 200 ms，外设就绪后 | `App_<角色>_Card_Process` | 移卡门控、UID、捕获时间、执行当前模式 |
| `SECOND_EVT` | 1000 ms | `App_<角色>_Second_Process` | RTC、模式超时、结果保留倒计时、在线状态、校时 |
| `RETRY_EVT` | 单次 2000 ms | `App_<角色>_Retry_Process` | 同事务最多发送 4 次 |
| `BUZZER_EVT` | 单次定时 | `Hal_Buzzer_Off` | 关闭蜂鸣器 |

表内缩写事件均加 `SAMPLEAPP_` 前缀。每个事件处理后只清自己的位、返回剩余事件。`SYS_EVENT_MSG` 优先；多个事件同时到达时 OSAL 继续调度剩余事件。UART 中断只提供接收事件，解析在任务上下文进行。

## 组网与消息

自动组网仍由 Z-Stack 启动路径完成。`OSAL_SampleApp.c` 保留原任务表；`SampleApp_Init()` 注册端点，协调器另注册 `Device_annce`。应用没有第二次建网调用。

主文件的 `ZDO_STATE_CHANGE` 更新 `SampleApp_NwkState`，调用 `App_<角色>_Network_Update()`。AF 消息调用旧名 `SampleApp_MessageMSGCB()` 按 Cluster 分发。ZDO 入网公告仅供观察；业务终端地址和在线状态由 ATT2 HELLO 确认。外设和本地数据库不依赖入网；终端离线仍可操作。

```text
AF_INCOMING_MSG_CMD → SampleApp_MessageMSGCB()
→ Comm_Unicast_ProcessMSG()
→ App_Coordinator_Unicast_Receive() / App_Terminal_Unicast_Receive()
→ Comm_Protocol_UnpackFrame() 验证、解包
→ 本角色按操作码处理会话、事务和业务数据
```

发送先由 `Comm_Protocol_PackFrame()` 组帧，再调用 `Comm_Unicast_Send()`。广播 Cluster 使用 `Comm_Broadcast_ProcessMSG()`；当前考勤通过单播执行，没有为广播增加不存在的业务。

## 串口调用链

```text
HAL UART 回调 → UART_RX_EVT → Hal_Uart_Process_Rx() 拼行
→ SampleApp_SerialCMD()
→ Device1_UART_ProcessCMD() → Device1_UART_ParseCMD()
→ UART_FindCMD() → UART_GetCMDType() → 拆参数
→ App_Coordinator_Command_Process() / App_Terminal_Command_Process()
```

旧项目串口文件位于 `Custom_Driver/Device1`，此次统一放在 `app/Common/device1_uart.c`。使用旧项目逐步解析方式；`hal_console_uart.c` 独占 UART，`device1_uart.c` 负责命令解析和回调。保留完整考勤指令，支持空格或冒号分隔，时间保留 `#TIME YYMMDDhhmmss`。使用固定缓冲区，不增加应用堆分配。完整命令见 [使用手册](ATTENDANCE_GUIDE.md)。

## 命名与范围

其余自编函数使用大驼峰加下划线，如 `Hal_Rtc_Read_Time()`、`App_Terminal_Card_Process()`。本次按要求恢复的 `Comm_*`、`Device1_UART_*`、`UART_FindCMD()`、`SampleApp_MessageMSGCB()` 和 `SampleApp_SerialCMD()` 使用旧名。SDK 要求的任务入口及 API 保留原名。修改范围一行一条语句、独立换行大括号；状态、字段偏移、失败路径写中文说明。

旧 `Custom_Driver` 有效代码已迁入 hal / app；未使用的温湿度、电机、旧考勤不加入固件。本次恢复前源码和工程备份在 `docs/backups/common-restore-20261005/`，当前迁移对照在 `docs/common-restore-migration.json`，具体保留项见 [旧项目串口与通信恢复](旧项目串口与通信恢复.md)。2026-10-02 的迁移记录保留为历史资料。

原版和中文注释版的双角色 IAR 配置通过：协调器 CODE 164603 B、XDATA 7636 B；终端 CODE 136354 B、XDATA 6571 B，均为 0 错误、0 警告。八组主机测试通过，详情见 `docs/build/common-restore-verification.json`。本轮未烧录，实际无线、电池和 OLED 效果需上板验收。
