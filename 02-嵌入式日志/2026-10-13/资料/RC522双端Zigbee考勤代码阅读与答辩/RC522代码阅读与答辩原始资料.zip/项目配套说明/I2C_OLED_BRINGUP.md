> 2026-09-23 更新：以下为历史bring-up/V1记录。当前使用Attendance V2，请以 [完整使用与架构手册](ATTENDANCE_GUIDE.md) 为准。用户已确认早先OLED异常是GND虚接并已修复；本轮仅改代码，未烧录。

# I2C、OLED 与 RTC 实机验证

## 当前实测

两次上电日志对比：

| 状态 | I2C | EEPROM | RTC | OLED |
|---|---:|---:|---:|---|
| 拔掉 OLED | 0 | 0 | 0，flags=0022 | addr=0000 status=1，无屏时预期 NACK |
| 接入 OLED | 2 | 2 | 2，flags=0000 | addr=0000 status=2，总线超时 |

不接 OLED 时，协调器的 I2C 总线、AT24C02 和 RX8010 都能初始化。RTC ReadTime 返回 5 是时间无效/VLF，需要后续校时。接上 OLED 后，I2C_Init 就因 SCL 拉高超时而失败；这发生在 OLED 地址探测之前，所以先检查接入后的电气连接，改 OLED 地址不会解决该超时。

## 对照自制 PCB 原理图

H1 OLED 接口针脚顺序为：

| H1 针脚 | 网络 |
|---:|---|
| 1 | VCC3V3 |
| 2 | GND |
| 3 | OLED_SCL / P1.2 |
| 4 | OLED_SDA / P1.1 |

请断电后对照 OLED 模块或排线自己的丝印，逐针核对 VCC、GND、SCL、SDA。四针 OLED 模块的针序并非都相同；若将模块直接反向或错一位插入，可能让主板 SCL 被接到错误信号/电源。先不要带电插拔。

## 复测步骤

1. 断电检查接口针序与焊点；万用表确认 SCL 不对地短路，H1 的 VCC/GND 没有接反。
2. 正确接线后上电；检查 P1.2/SCL 与 P1.1/SDA 空闲电压接近 3.3V。
3. 重新读取 COM11：应看到 I2C、EEPROM、RTC 初始化为 0，OLED 地址为 003C 或 003D、状态为 0。
4. 验证屏幕文字；再发送 #TIME YYMMDDhhmmss 校时、#TIME 读回时间，并执行 #EEPROM 写入/恢复测试。
5. 若接屏后 SCL 仍低，先拔屏再量主板 H1.3 到 GND 是否短路；再单独检查 OLED 模块/转接线的针脚映射和供电。

新增诊断版已构建，但 C-SPY 重下载时目标识别失败；当前板上运行的已有 OLED 固件已经足以完成上述接线复测。详细日志在 docs/build/。
