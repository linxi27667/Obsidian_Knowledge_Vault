> 2026-09-23 更新：以下为历史bring-up/V1记录。当前使用Attendance V2，请以 [完整使用与架构手册](ATTENDANCE_GUIDE.md) 为准。用户已确认早先OLED异常是GND虚接并已修复；本轮仅改代码，未烧录。

# ZigBee Bring-Up 验证记录

## 编译、下载与网络

2026-09-23，CoordinatorEB OLED 固件构建退出码 0；0 errors、6 warnings，CODE 151894 bytes。CC Debugger 首次下载成功，串口日志确认协调器 state=9、PAN=2B2B、CH=25，RC522 读取 UID 并本地登记。

新增诊断版另加 SCL 超时说明、RTC 总线错误分类和外设最终错误位。其构建 0 errors、6 warnings，CODE 152065 bytes；主机 RC522、EEPROM/RTC 测试通过。诊断版后续重下载返回 Failed to identify device，所以当前 MCU 仍运行首个 OLED 固件。

## OLED 接入对比

拔掉 OLED：

    [DRV] I2C status=0
    [DRV] EEPROM status=0
    [DRV] RTC status=0 flags=0022
    [RTC] status=5 (5=time invalid)
    [DRV] OLED addr=0000 status=1

接入 OLED：

    [DRV] I2C status=2
    [DRV] EEPROM status=2
    [DRV] RTC status=2 flags=0000
    [DRV] OLED addr=0000 status=2

拔屏时 I2C、EEPROM、RTC 都能初始化；RTC 仅时间无效。OLED status=1 是 OLED 不在总线时预期的 NACK。插屏后初始化阶段就报 SCL 超时，早于 OLED 地址探测，因此不是 OLED 地址 0x3C/0x3D 选错。

原理图 H1 OLED 接口顺序为：1=VCC3V3、2=GND、3=OLED_SCL、4=OLED_SDA。应对照 OLED 模块本身丝印逐脚核对，不能仅凭同为四针就直接插接；模块/排线方向不匹配、错位或 SCL 对地短路都可能令插屏后 SCL 拉低。

## 下一步

1. 断电后核对 H1 与 OLED 模块每一针的 VCC、GND、SCL、SDA；确认方向无误、没有错位或焊桥。
2. 断电用万用表检查 SCL 对 GND 无短路；接好后再上电观察两根总线空闲电压应接近 3.3V。
3. 重新测试，期望 I2C/EEPROM/RTC 初始化为 0，OLED 地址应为 003C 或 003D 且 status=0。
4. 屏幕点亮后执行 #TIME YYMMDDhhmmss、#TIME 和 #EEPROM；最后再用终端刷卡确认 ZigBee 上报。
