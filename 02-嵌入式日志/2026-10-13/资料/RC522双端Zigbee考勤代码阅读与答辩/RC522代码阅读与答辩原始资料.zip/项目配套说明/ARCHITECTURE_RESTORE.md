# 架构恢复审计与交付记录

> 历史记录：本文对应 2026-09-24 的恢复阶段，保留当时的目录和构建数据。2026-10-02 已迁入 hal / app，2026-10-05 又恢复旧 Common 串口和通信入口；当前入口和事件表见 [架构阅读指南](SOFTWARE_ARCHITECTURE.md)。

## 边界和基线

本轮目标目录是 `E:\MCU\zigbee\RC522大作业`。参考目录 `E:\MCU\zigbee\dazuoye` 只用于读取和比较，没有写入。实施前保存的目标工程基线在 `docs/backups/architecture-restore-baseline-20260924/`；此前的考勤实现备份在 `docs/backups/architecture-before-20260924/`。构建输出存放于各 IAR 配置目录和 `docs/build/`，与源码差异分开核对。

此前 SDK 对比记录：除下表明确保留的板级适配外，2,219 个 SDK 文件和33个库文件与参考工程相同；生成输出不计为源码差异。针对 `Projects/zstack/Samples/SampleApp`，排除 Obj/List/Exe/Debug/settings 后逐项做 SHA-256 对比：30 个旧文件相同、6 个文件修改、25 个文件新增、没有删掉旧参考文件。

## 修改和保留的差异

| 文件/范围 | 分类 | 处理 |
|---|---|---|
| `Source/Coordinator.c` | 恢复骨架并迁入业务 | 以旧协调器的初始化、OSAL 事件、消息分发和回调顺序组织；终端发现、ATT2、串口和协调器刷卡留在本角色文件 |
| `Source/EndDevice.c` | 恢复骨架并迁入业务 | 以旧终端入口顺序组织；保留本地离线考勤、按键模式、远程请求和 AT24C08 异步事务 |
| `Source/SampleApp.h` | 按考勤事件重整配置 | 将旧温湿度/电机演示周期和事件标志替换为独立考勤事件位及周期；端点、Profile、Cluster 定义保持不变 |
| `Custom_Driver/Device1/device1_uart.c/.h` | 适配旧 UART 解析回调 | 保留旧式“扫描首个 `#` → 命令类型识别 → 参数拆分 → 注册回调”顺序及前缀兼容行为；适配当前考勤参数，不打开硬件 UART |
| `CC2530DB/SampleApp.ewp` | 工程配置整理 | 将驱动、板级、Common、Device1、Device2 分组；协调器/终端使用各自主文件，终端数据库仅进入 EndDeviceEB，移除角色宏和失效业务引用 |
| `Components/hal/target/CC2530EB/hal_board_cfg.h` | 保留硬件适配 | 自制 PCB 的安全上电、LED/按键极性和引脚映射仅在 `GAOCHANG_RC522_BOARD` 分支生效 |
| 原 OSAL、任务注册、ZDO 自动组网、AF 端点和通信模块 | 保持参考实现 | 不增加应用层第二次建网；旧 `comm_*.c/.h` 与参考工程逐字节一致 |
| `Custom_Driver/Board/board_config.h` | 新增硬件适配 | 集中定义自制 PCB 的 SCL、SDA、按键、LED、蜂鸣器、RC522 和 UART 引脚 |
| IAR `.dep`、Obj/List/Exe 等 | 生成文件 | 不作为手工源码差异回滚；最终以 EWP 真实引用和链接映射判断是否参与构建 |

SampleApp 目录新增的25个文件由21个当前模块文件和4个旧版本留档文件组成。当前模块为：

- `Custom_Driver/Board/board_config.h`。
- `Custom_Driver/Common/att_ui.c/.h`、`att_wire.c/.h`。
- `Custom_Driver/Device2/att_db.c/.h`。
- `Custom_Driver/Drivers/drv_basic.c/.h`、`drv_debug.c/.h`、`drv_eeprom.c/.h`、`drv_i2c.c/.h`、`drv_oled.c/.h`、`drv_rc522.c/.h`、`drv_rtc.c/.h`。
- `Legacy/phase1/Coordinator.c`、`hal_board_cfg.h`、`SampleApp.ewp`、`SampleApp.h`，作为历史参考，不进入当前角色固件。

旧 `gc_attendance.c/.h` 已从有效工程引用中移除，留在 `docs/backups/architecture-before-20260924/`。旧温湿度、电机和步进电机演示驱动仍保留在工程目录，但当前 CoordinatorEB/EndDeviceEB 均不编译这些驱动。

## 结构和行为对照

- 网络仍由 Z-Stack 原始启动流程创建；应用只在 `ZDO_STATE_CHANGE` 更新角色状态。
- `SYS_EVENT_MSG` 恢复消息队列循环、`switch` 分发和逐条释放；AF 包经 `SampleApp_MessageMSGCB()` 再进入已有通信模块。
- 初始化、按键、串口接收、数据库、控制台、OLED、刷卡、秒任务、重试和蜂鸣器使用独立事件段落与事件位。
- UART 硬件只由 `drv_debug.c` 打开；中断回调只置 OSAL 事件，命令解析在任务上下文完成。
- ATT2 操作码、端点、Cluster、帧布局、数据库镜像/CRC/提交标记/循环日志和 EEPROM 布局没有更改。
- OLED 刷新事件可能在上电初始化完成前到达；两个角色现会先消费事件位，再仅在外设就绪后访问 UI，主机测试对此有断言。

事件周期详见 [软件架构](SOFTWARE_ARCHITECTURE.md)。串口命令和上板操作详见 [考勤手册](ATTENDANCE_GUIDE.md)。

## 2026-09-29 协议栈架构复查

本次再次按 SHA-256 比较两个项目的 SDK 源码、头文件、库和链接配置（排除 SampleApp 应用目录）：935 个相同，0 个缺失；唯一差异是自制 PCB 所需的 `hal_board_cfg.h`。两个项目的 `OSAL_SampleApp.c`、`comm_unicast.c`、`comm_broadcast.c`、`comm_protocol.c` 逐字节相同。IAR 工程中 DemoEB、RouterEB 的编译选项相同；CoordinatorEB、EndDeviceEB 的设置差异仅为自制板/32k 晶振宏、终端的 MT 串口任务开关和新增驱动的头文件搜索路径，库与链接内存设置未改。

应用层进一步恢复了旧项目的调用方式：

- `SampleApp_ProcessEvent` 每次处理一个事件位，返回剩余事件；`SYS_EVENT_MSG` 仍先处理完整消息队列并逐条释放。多事件同时到达的测试会循环执行到事件位清空。
- 两端 AF 消息按旧项目的 Cluster `switch` 分发单播和广播，并显式列出周期/Flash Cluster；考勤 ATT2 业务仍走单播。
- 协调器注册 `Device_annce` 的 ZDO 消息并在 `ZDO_CB_MSG` 中处理公告。公告只用于观察入网，终端短地址和在线状态仍由 ATT2 HELLO 确认。
- 两个角色直接包含原 `SampleApp.h`，移除了仅为主机测试绕开该头文件的条件编译，以及不再使用的旧周期发送状态。

硬件适配保留以下有意差异：自制板按键由 `KEY_Poll` 采样后进入 `SampleApp_HandleKeys`；终端未启用旧 MT 串口任务，由 `drv_debug` 独占 UART 并在 OSAL 任务中解析；RTC、EEPROM、OLED 和离线考勤定时器从初始化阶段运行，不等待终端入网。协议栈仍按 `OSAL_SampleApp → ZDApp_Init → ZDOInitDevice` 自动建网或入网。

## 验收结果

本轮只做软件验证，没有烧录或声称完成真实双机硬件验证。最终 IAR 构建日志和 map 文件保存在 `docs/build/` 及 `CC2530DB/{CoordinatorEB,EndDeviceEB}/List/SampleApp.map`。主机脚本验证覆盖 UART CR/LF、旧式前缀帧查找、命令参数边界、空格/冒号解析、接收背压、同一轮多个 OSAL 事件、消息释放、初始化前 OLED 门控、两角色注册/注销/考勤、通信重试和来源匹配、AT24C08 镜像断电恢复、重复事务、RTC、RC522 UID 长度及 UI 刷新边界。

IAR 两个配置均为0错误、4条警告。所有警告都是 `Pa050` 行尾提示，来自与参考工程逐字节相同的 `comm_unicast.h`、`comm_broadcast.c/.h` 和 `comm_protocol.c`；改动的角色文件、事件头文件和 UART 解析器没有新增警告。为保留旧通信模块原样，没有只为清除这些提示而改写它们。

| IAR 配置 | 错误 | 警告 | CODE | XDATA |
|---|---:|---:|---:|---:|
| CoordinatorEB | 0 | 4 | 155,021 B | 7,339 B |
| EndDeviceEB | 0 | 4 | 130,852 B | 6,487 B |

CC2530 的 XDATA 容量为8,192字节；链接映射包含0x300字节 XDATA 栈。协调器使用量约89.6%，终端约79.2%，均未溢出。最终日志为 `docs/build/stack-parity-final-CoordinatorEB.log`、`stack-parity-final-EndDeviceEB.log`，map 文件位于两个配置的 `List/SampleApp.map`。

最终主机测试均通过：`test-app.ps1`、`test-attendance.ps1`、`test-console.ps1`、`test-rc522.ps1`、`test-storage.ps1`、`test-ui.ps1`；其中 `test-app.ps1` 额外验证 ZDO 公告、广播分发和多事件依次处理。这验证软件流程和 IAR 链接，不替代真实双机/掉电/OLED 硬件验证；本轮未烧录。
