# Gaochang ZIGBEE-RC522：修改前基线分析与实施记录

> 历史基线：本文保留 2026-09-21 的分析和实施过程。当前目录已迁入 hal / app，当前使用方式见 [架构阅读指南](SOFTWARE_ARCHITECTURE.md) 与 [使用手册](ATTENDANCE_GUIDE.md)。

日期：2026-09-21。本文前半部分记录修改前基线；Phase 2/3 实施结果在第 11 节汇总。源码、工程配置已经发生受控修改，但仍存在硬件网络名不一致等风险，不能把编译通过当作实机验收。

## 1. 工程组织与分析范围

主工程根目录为 `Texas Instruments/ZStack-CC2530-2.5.1a`（下称 STACK）。目标工程为 `STACK/Projects/zstack/Samples/SampleApp/CC2530DB/SampleApp.ewp`，目标配置 `CoordinatorEB`。

- 工程有 DemoEB、CoordinatorEB、RouterEB、EndDeviceEB 四种配置。CoordinatorEB 编译 `Source/Coordinator.c`，排除 `Source/EndDevice.c`；主应用目录没有 SampleApp.c。
- `zigbee传感器例子` 中另有 DHT11、光敏传感器的完整栈副本；`外设参考代码` 中还有独立裸机实验及重复目录。不能把这些副本当作主工程。
- 已递归盘点目录，读取主工程 EWP 文件清单/排除关系、应用、OSAL task 表、启动、板级配置、UART、旧驱动，以及 ZDO 建网关键路径。工程和上级目标路径未发现适用 AGENTS.md。
- 栈并非所有实现均有 C 源码：链接依赖 `Router-Pro.lib`、`Security.lib`、`TIMAC-CC2530.lib`，必须保留。

## 2. 启动流程

`chipcon_cstartup.s51` → `ZMain.c:main()` → 关闭中断 → `HAL_BOARD_INIT()` → `zmain_vdd_check()` → `InitBoard(OB_COLD)` → `HalDriverInit()` → `osal_nv_init()` → `ZMacInit()` → `zmain_ext_addr()` → `zgInit()` → `afInit()` → `osal_init_system()` / `osalInitTasks()` → 开中断 → `InitBoard(OB_READY)` → `zmain_dev_info()` → `osal_start_system()`。

HAL 初始化先于应用初始化。仅在应用中关闭蜂鸣器或修正 LED，不能保证启动早期 GPIO 安全。应在板级初始化边界设置正确安全电平，保留时钟、MAC、NV、OSAL 顺序。

## 3. OSAL 任务表

以下为本次 CoordinatorEB 实际编译的 `OSAL_SampleApp.lst` 中任务指针表，不能仅按条件编译前源码猜 Task ID。

| Task ID | 初始化 | 事件处理 |
|---|---|---|
| 0 | macTaskInit | macEventLoop |
| 1 | nwk_init | nwk_event_loop |
| 2 | Hal_Init | Hal_ProcessEvent |
| 3 | APS_Init | APS_event_loop |
| 4 | APSF_Init | APSF_ProcessEvent |
| 5 | ZDApp_Init | ZDApp_event_loop |
| 6 | ZDNwkMgr_Init | ZDNwkMgr_event_loop |
| 7 | SampleApp_Init | SampleApp_ProcessEvent |

`xMT_TASK` 不是 `MT_TASK`，本配置没有独立 MT task，但仍使用 MT UART 接口。ZIGBEEPRO 启用分片和网络管理相关条件分支。新增业务优先复用应用 task 的事件，不更改任务顺序。

## 4. ZigBee 现有组网链路

`ZDApp_Init()` → `ZDAppCheckForHoldKey()` → `ZDO_Init()` / AF 注册 ZDO endpoint → 非 DEV_HOLD 时 `ZDOInitDevice(0)` → NV/启动模式判定 → `ZDApp_NetworkInit()` → `ZDO_NETWORK_INIT` → `ZDO_StartDevice()` → Coordinator 分支 `NLME_NetworkFormationRequest()` → 栈内部 NWK/MAC → `ZDO_NetworkFormationConfirmCB()` → `ZDO_NETWORK_START` → `ZDApp_NetworkStartEvt()` → `devState = DEV_ZB_COORD` → `ZDO_STATE_CHANGE_EVT` → endpoint 对应应用收到 `ZDO_STATE_CHANGE`。

源码证据：`Components/stack/zdo/ZDApp.c` 的 ZDApp_Init、ZDOInitDevice、ZDApp_NetworkStartEvt、ZDO_NetworkFormationConfirmCB、ZDApp_NetworkInit；`ZDObject.c` 的 ZDO_StartDevice 和状态通知。

`f8wCoord.cfg` 定义 ZDO_COORDINATOR、RTR_NWK；`f8wConfig.cfg` 设置 ZIGBEEPRO、默认信道位图 0x02000000（CH25）、默认 PAN 0x2B2B、SECURE=0。保持现值，不能把启动打印的固定 PAN/CH 当作运行时实际网络信息，NV 恢复也必须纳入测试。

## 5. 修改前 Application 入口与依赖

`Coordinator.c:SampleApp_Init()` 注册串口、单播/广播回调，初始化旧光敏 ADC、蜂鸣器、电机；随后配置 endpoint 并 `afRegister()`，注册 Device_annce 和按键消息。

保持 endpoint=20、Profile=0x0F08、Device=0x0001、Cluster=1/2/3/4、SampleApp_TaskID 获取方式和 AF 注册结构。

事件循环处理 KEY_CHANGE、AF_INCOMING_MSG_CMD、ZDO_CB_MSG、ZDO_STATE_CHANGE、CMD_SERIAL_MSG；建网成功后还会阻塞蜂鸣三次、启动 2 秒光敏采集、10 秒旧业务心跳和 1ms 软件电机 PWM。网络消息回调、串口命令和自动风扇逻辑相互引用，不能只从 EWP 删除驱动文件。

## 6. 修改前 HAL / BSP、UART、Timer、SPI、I2C、NV

- 现有板型默认 SmartRF05 CC2530EB REV17，板级宏在 `Components/hal/target/CC2530EB/hal_board_cfg.h`。
- 原 LED 配置为 P1.0/P1.1/P0.4、低有效；新板只有 P1.0 一个可控 LED，且高有效。直接沿用会占用 I2C SDA 和 ESP UART 候选引脚。
- HAL KEY 使用 P0.1/P2.0，与新板 KEY0/KEY1 一致；现有 25ms 消抖可复用，需确认上下拉、按下边沿及长按重复行为。
- UART 链路：MT_UartInit → HalUARTOpen → `_hal_uart_isr.c`。当前 UART0 ISR，P0.2 RX/P0.3 TX，38400，无硬件流控。驱动内有收发缓冲，优先复用。
- 旧 `device1_uart.c` 是 HAL 写接口和命令解析封装，并未独立初始化硬件串口。
- MT_UartProcessZToolData 已被改成原始接收转 OSAL 消息；局部 buf[128] 的读取没有边界限制，消息分配后未检查 NULL。发送后又调用 deallocate 是多余操作：本版本 OSAL 拒绝释放已入队消息，因此不能断言它已造成 use-after-free；仍应纠正所有权和错误处理。
- Timer 优先用 OSAL_Timers / Hal timer；不得占用 MAC 时基或为蜂鸣器长时间延时。
- 旧 OLED 有私有软件写总线、字体和显示函数，但不读取 ACK，不支持读事务，GPIO 推挽拉高，不能直接作为 EEPROM/RTC 共用 I2C。可保留字体/绘制，替换底层事务。
- 现有 XNV SPI 宏是外部 NV 通道，不等于 RC522 驱动；不能挪用 NV 行为。未发现主工程 RC522/AT24C02/RX8010SJ/ESP12F 专用实现。
- 内部 Flash NV 由 OSAL_Nv / hal_flash / ZGlobals 管理，与外接 AT24C02 用户存储分离。
- 原理图仅有 32MHz 晶振，P2.3/P2.4 标 NC；基线默认选择外部 32kHz。当前工程已在 CoordinatorEB 定义 `OSC32K_CRYSTAL_INSTALLED=FALSE`，选择内部 32 kHz RC，仍需实板验证时钟稳定性。

## 7. 准备清理的旧模块

| 对象 | 当前引用 | 处理计划 |
|---|---|---|
| device1_temp_sensor | Init、采集事件、发送函数/业务回调 | 移除光敏采集调用、事件启动和旧业务引用，再从 CoordinatorEB 排除 |
| device1_motor | Init、1ms PWM、串口 MOTOR/AUTO、DHT11 自动调速 | 一起清理业务回调和事件，再排除驱动 |
| device1_buzzer | 建网提示、告警、串口控制 | 以新板异步蜂鸣器替代，禁止照搬 P0.7/低有效 |
| Device2 DHT11/stepper 等 | EndDevice.c；CoordinatorEB 已排除 | 保留原文件和终端配置，暂不删除共享内容 |
| comm_protocol / unicast / broadcast | AF 接收、串口转发、远端业务 | 保留 AF/endpoint 兼容边界；确认回调解除后才清理旧消息语义 |
| 外设参考代码、传感器完整栈副本 | 不在主 EWP 编译清单 | 暂保留作参考，不做大规模目录移动 |
| delay / Demo 事件宏 | 蜂鸣器、OLED、其他配置引用 | 逐项解除引用，不按名称删除 |

清理须检查 include、符号、callback、定时器启动/重装、AF 分发、EWP 排除配置和最终 linker map。保留原文件优于破坏其他构建配置。

## 8. 必须保留的模块

MAC/ZMAC、NWK、APS/分片、AF、ZDO/ZDApp/ZDNwkMgr、OSAL core/调度/内存/Timer、HAL core、内部 NV、security 及预编译库、链接脚本、网络状态/信道/PAN 管理。仅允许必要且可追溯的板级 HAL 宏适配和已有 UART 接收缺陷修复，不重写协议栈。

## 9. 计划新增/适配驱动

沿用 `Custom_Driver`，增加集中的 Board/board_config 和驱动目录，不机械拆分已有 Coordinator.c。

- LED、KEY、异步 Buzzer、DBG：复用 HAL/OSAL，在 APP/HAL 边界输出启动和实际网络参数。
- 共用 I2C：开漏模拟、ACK/NACK、读事务、有限等待和失败返回；每次事务和事件工作量有上限。
- EEPROM：页边界和有限写周期 ACK 轮询；自检使用明确测试区域并保存/恢复原值，不覆盖未知配置。
- RTC：基本初始化和 BCD 时间读写，失败记录状态，不阻塞网络。
- OLED：复用现有显示资源，优先级低于组网；需补齐 Gaochang 小写显示所需字形。
- RC522：独立寄存器/事务/防冲突/选卡/UID 驱动，有超时，KEY1 触发；RST 网络须核实，IRQ 目前未连接 MCU，可考虑轮询。
- ESP：HAL UART 独立端口、RX callback / buffer、异步复位；必须先明确 UART 网络和 USART1 映射。现有 HAL USART1 默认 P1.6/P1.7 会撞 RC522，不能直接开启。

## 10. 风险与进入修改阶段的条件

1. 原理图 ESP UART 两端网络名不同，P0_4/TX 对 P0_4/RX、P0_5/RX 对 P0_5/TX；PDF 未见桥接，需 CAD 网表或实板通断确认。当前工程保持 ESP 禁用。
2. MCU 的 RC522_RST 与 RC522 页 NRSTPD 的 REST 不同名，需确认是否实板断网或只是文档错误。
3. 蜂鸣器、LED 极性/引脚和 32 kHz 时钟已完成源码级适配；实板极性、启动电平和时钟稳定性仍未验证。
4. I2C 与旧 LED、电机引脚冲突；ESP UART 与默认 UART1/RC522 冲突。
5. 旧 ADC 无限等待和阻塞蜂鸣可能饿死 OSAL；串口存在越界和分配失败风险。
6. 基线 XDATA 6615 字节，新增缓冲和调用栈必须看 map；不能以删除核心栈解决资源不足。
7. 当前枚举到的串口均为蓝牙串口，未确认 CH340 和 CC2530 下载器，不能宣称已上板运行/建网。

## 11. Phase 1 与后续计划

Phase 1 已实际无源码修改编译 CoordinatorEB，通过（0 error / 8 warning）。编译器 8.10.3.10338，banked code / large data / xdata_reentrant；8 个警告均为 Pa050 换行格式。日志见 build/phase1-baseline.log。

Phase 2 已完成：Coordinator.c 保持新板驱动入口，主工程 `SampleApp.ewp` 已移除旧光敏、电机、旧蜂鸣器和旧 Device1 UART 的工程条目；旧源文件仍保留给历史配置参考。Phase 3 已完成源码级 Board/HAL 映射、LED/蜂鸣器安全电平和内部 32 kHz 选项；CoordinatorEB 清理后重编译通过（0 error、5 warning）。RC522、EEPROM/RTC 主机测试均通过。剩余工作是解决原理图歧义、确定实板/下载器，并依次验证 LED/KEY/异步蜂鸣、I2C、EEPROM/RTC/OLED、RC522、ESP UART 和实际网络日志。

优先在基础 GPIO/UART 就绪后尽早上板验证 Coordinator，非关键外设在后续应用事件中初始化，失败仅更新 driver_status。最终完成必须有真实硬件证据，编译通过不等于组网或 UID 读取通过。
