# OLED 中文界面

128×64 OLED 继续使用现有 SSD1306 软件 I2C 和 31 列分段写入。应用只保留一页 128 字节缓冲；每个汉字为 16×16，占上下两页，数字和学号沿用原有 5×7 字模。协调器和终端共用一份界面，顶部显示角色与组网状态，中间显示时间或刷卡结果，第三行显示日期、人数或学号，底部显示按键、倒计时及故障提示。

中文字形来自 [Noto Sans SC 官方仓库](https://github.com/notofonts/noto-cjk/tree/main/Sans/SubsetOTF/SC)，采用 [SIL Open Font License 1.1](https://github.com/notofonts/noto-cjk/blob/main/Sans/LICENSE)。原始 `NotoSansSC-Regular.otf` 和许可文本位于 `assets/fonts`；`scripts/generate-oled-font.py` 仅提取当前界面使用的 90 个汉字，生成 `app/app_font.h`，避免把完整 CJK 字体放入 CC2530 Flash。若新增中文文案，应先在脚本 `PHRASES` 中登记，再重新生成字模。

离线刷卡结果页中间上方显示“倒计时 05秒”并逐秒减少，五秒后恢复时钟，底部保留“终端离线”。注册、注销、考勤成功分别显示“注册成功”“注销成功”“考勤成功”；重复注册显示“该卡已注册”，注销或考勤遇到未知卡显示“该卡未注册”。预览中的 2026-09-23 是固定测试数据，不是固件的启动时间。

运行 `powershell -File scripts/test-ui.ps1` 模拟 I2C 显存，验证页边界、31 列传输、逐秒倒计时及中文文案，输出十四张 128×64 PGM 到 `docs/ui-preview`。`python scripts/render-oled-preview.py` 生成全部页面的联系图。`verify-attendance.ps1` 包含主机测试及两个 IAR 构建。固件显示字节为 GBK，字模头文件为 CP936/CRLF。页面逻辑在 `app/app_ui.c`，底层写入在 `hal/hal_oled.c`，调度在两个角色主文件。
