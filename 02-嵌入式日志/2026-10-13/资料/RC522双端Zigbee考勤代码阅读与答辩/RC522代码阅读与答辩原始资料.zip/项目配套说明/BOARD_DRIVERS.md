# 板级引脚与驱动阅读入口

查全部引脚：SampleApp/hal/board/board_config.h。
协议栈板级适配：Components/hal/target/CC2530EB/hal_board_cfg.h。
LED沿用Components/hal/target/CC2530EB/hal_led.c / include/hal_led.h；调用HalLedSet，SDK初始化一次。
蜂鸣器：SampleApp/hal/hal_buzzer.c / .h；P0.0高电平响，关闭事件由角色主文件调度。
按键：SDK hal_key.c读取引脚，SampleApp/hal/hal_board_key.c每10ms消抖，只产生按下边沿。
hal_basic.c/.h已经从有效工程移除，原文件及工程配置保存在docs/backups/20261008-hal-split。

|器件|引脚|入口|
|---|---|---|
|LED|P1.0，高有效|SDK HalLedSet|
|蜂鸣器|P0.0，高有效|Hal_Buzzer_Beep|
|按键1/按键2|P0.1 / P2.0，低有效|Hal_Key_Poll|
|OLED、RTC、EEPROM I2C|SCL=P1.2，SDA=P1.1|Hal_I2c_*|
|RC522软件SPI|CS=P1.4，CLK=P1.5，MOSI=P1.6，MISO=P1.7|Hal_Rc522_*|
|USB调试串口 UART0 Alt1|RX=P0.2，TX=P0.3|SDK HalUART + Hal_Uart_*|
|ESP12F UART1 Alt1|TX=P0.4，RX=P0.5，RESET=P0.6|ESP版 Hal_Esp12f_*|

ESP_TX接CC2530_RX(P0.5)，ESP_RX接CC2530_TX(P0.4)。RC522硬件RST暂不启用。
角色主文件负责OSAL事件；不要再注册第二套HAL任务或第二次组网。
