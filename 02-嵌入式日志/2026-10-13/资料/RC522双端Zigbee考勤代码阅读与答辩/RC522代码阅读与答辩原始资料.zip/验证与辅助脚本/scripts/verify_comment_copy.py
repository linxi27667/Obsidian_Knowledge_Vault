"""确认原版与中文注释版在用源码只有注释和空白差异。"""
from pathlib import Path
import re
import annotate_chinese

def code_only(source):
    tokens = re.findall(r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[^\s]', source)
    return ''.join(token for token in tokens if not token.startswith(('/*', '//')))

def main():
    original = annotate_chinese.ORIGINAL_ROOT
    annotated = annotate_chinese.ANNOTATED_ROOT
    files = [annotate_chinese.RELATIVE_APP / relative for relative in annotate_chinese.FILE_NOTES]
    files.append(Path('Texas Instruments/ZStack-CC2530-2.5.1a/Components/hal/target/CC2530EB/hal_board_cfg.h'))
    for relative in files:
        left = code_only(annotate_chinese.read_source(original / relative))
        right = code_only(annotate_chinese.read_source(annotated / relative))
        if left != right:
            raise AssertionError('code differs: ' + str(relative))
    task_registry = annotate_chinese.RELATIVE_APP / 'Source/OSAL_SampleApp.c'
    if (original / task_registry).read_bytes() != (annotated / task_registry).read_bytes():
        raise AssertionError('SDK task registry differs')
    print(f'PASS: {len(files)} active files differ only in comments or whitespace')

if __name__ == '__main__':
    main()
