"""检查 HAL/APP 命名、角色选择、工程路径与只读参考项目完整性。"""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import annotate_chinese

ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT.parent / 'dazuoye'
SAMPLE = annotate_chinese.RELATIVE_APP
SDK = Path('Texas Instruments/ZStack-CC2530-2.5.1a')


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_reference():
    expected = json.loads((ROOT / 'docs/build/reference-hal-app-before.json').read_text(encoding='utf-8'))
    suffixes = {Path(name).suffix.lower() for name in expected}
    current = {str(p.relative_to(REFERENCE)): sha256(p) for p in REFERENCE.rglob('*')
               if p.is_file() and p.suffix.lower() in suffixes}
    changes = sorted(name for name in set(expected) | set(current)
                     if expected.get(name) != current.get(name))
    assert not changes, 'Read-only reference changed: ' + repr(changes)

    # 已授权的板级适配不回退；协议栈核心、库、链接脚本、任务注册按字节比较。
    sdk_files = []
    for name in expected:
        relative = Path(name)
        path = relative.as_posix()
        if not path.startswith(SDK.as_posix() + '/'):
            continue
        if ('/Components/' in path and not path.endswith('/hal_board_cfg.h')) or \
                relative.suffix.lower() in {'.lib', '.xcl'} or \
                path == (SAMPLE / 'Source/OSAL_SampleApp.c').as_posix():
            sdk_files.append(name)
    different = [name for name in sdk_files
                 if not (ROOT / name).is_file() or sha256(ROOT / name) != expected[name]]
    assert not different, 'SDK differs from reference: ' + repr(different)
    return {'reference_files': len(expected), 'changed_reference_files': 0,
            'unchanged_sdk_core_library_linker_files': len(sdk_files)}


def check_style():
    functions = 0
    for relative in annotate_chinese.active_files():
        source = annotate_chinese.read_source(ROOT / SAMPLE / relative)
        mask = annotate_chinese.source_mask(source)
        for match in re.finditer(r'(?m)^(?:static\s+)?(?:const\s+)?[\w]+\s+\*?\s*(\w+)\s*\([^;{}]*\)\s*\{', mask):
            name = match[1]
            legacy_common = relative.startswith('app/Common/')
            if not legacy_common and name not in {'SampleApp_Init', 'SampleApp_ProcessEvent', 'SampleApp_MessageMSGCB', 'SampleApp_SerialCMD'}:
                assert re.fullmatch(r'[A-Z][A-Za-z0-9]*(?:_[A-Z][A-Za-z0-9]*)+', name), (relative, name)
            functions += 1
        for match in re.finditer(r'\b(?:if|switch|for|while)\s*\(', mask):
            cursor = match.end()
            depth = 1
            while depth:
                if mask[cursor] == '(':
                    depth += 1
                elif mask[cursor] == ')':
                    depth -= 1
                cursor += 1
            statement = re.match(r'\s*', mask[cursor:])[0]
            next_position = cursor + len(statement)
            # do...while 的尾部不是语句块；普通条件必须换行后使用大括号。
            macro_tail = (match[0].startswith('while') and
                          mask[match.end():cursor - 1].strip() == '0' and
                          mask[:match.start()].rstrip().endswith('}'))
            if mask[next_position] == ';' or macro_tail:
                continue
            assert '\n' in statement and mask[next_position] == '{', (relative, match[0])
        for match in re.finditer(r'\belse\b', mask):
            line_prefix = mask[mask.rfind('\n', 0, match.start()) + 1:match.start()]
            if line_prefix.strip() == '#':
                continue
            rest = mask[match.end():]
            if re.match(r'\s+if\b', rest):
                continue
            whitespace = re.match(r'\s*', rest)[0]
            assert '\n' in whitespace and rest[len(whitespace)] == '{', (relative, 'else')
    return {'active_own_files': len(annotate_chinese.active_files()),
            'named_functions': functions, 'naming_and_braces': 'PASS'}


def check_variables():
    # SDK类型、成员、API及旧SampleApp共用符号保留；自写状态不再使用驼峰变量。
    sdk_names = {
        'afIncomingMSGPacket_t', 'afRegister', 'cId_t', 'clusterID', 'clusterId',
        'devStates_t', 'endPoint', 'endPointDesc_t', 'keyChange_t', 'latencyReq',
        'noLatencyReqs', 'simpleDesc', 'zdoIncomingMsg_t', 'addrMode', 'afAddrMode_t',
        'afAddrType_t', 'afStatus_SUCCESS', 'afStatus_t', 'shortAddr', 'srcAddr',
        'nwkLogicalChannel', 'nwkPanId', 'ioCC2530', 'baudRate', 'callBackFunc',
        'flowControl', 'halUARTCfg_t', 'idleTimeout', 'intEnable', 'maxBufSize',
        'osal_start_timerEx', 'osal_stop_timerEx', 'osal_GetSystemClock'
    }
    template_globals = {'SampleApp_TaskID', 'SampleApp_NwkState', 'SampleApp_epDesc',
                        'SampleApp_ClusterList', 'SampleApp_SimpleDesc'}
    globals_checked = 0
    for relative in annotate_chinese.active_files():
        mask = annotate_chinese.source_mask(annotate_chinese.read_source(ROOT / SAMPLE / relative))
        mixed = set(re.findall(r'\b[a-z][A-Za-z0-9_]*[A-Z][A-Za-z0-9_]*\b', mask)) - sdk_names
        assert not mixed, (relative, 'custom camelCase variables', sorted(mixed))
        depth = 0
        parentheses = 0
        for line in mask.splitlines():
            if depth == 0 and parentheses == 0 and not line.lstrip().startswith(('#', 'typedef')):
                pointer = re.match(r'\s*(?:static\s+)?void\s*\(\s*\*(\w+)\)', line)
                declaration = re.match(r'\s*(?:(?:static|extern|const|volatile)\s+)*\w+\s+(.+)', line)
                names = [pointer[1]] if pointer else []
                if declaration and '(' not in declaration[1]:
                    for part in declaration[1].split(','):
                        name = re.match(r'\s*\*?\s*(\w+)', part)
                        if name and not name[1][0].isdigit():
                            names.append(name[1])
                for name in names:
                    assert name in template_globals or re.fullmatch(r'g_[a-z][a-z0-9_]*', name), (relative, name)
                    globals_checked += 1
            depth += line.count('{') - line.count('}')
            parentheses += line.count('(') - line.count(')')
    return {'global_variables_checked': globals_checked, 'snake_case_and_global_prefix': 'PASS'}


def check_project():
    project = ROOT / SAMPLE / 'CC2530DB/SampleApp.ewp'
    tree = ET.parse(project)
    selected = {role: [] for role in ['CoordinatorEB', 'EndDeviceEB']}
    count = 0
    for node in tree.findall('.//file'):
        name = node.findtext('name')
        expanded = name.replace('$PROJ_DIR$', str(project.parent))
        assert '$' not in expanded, 'Unresolved project variable: ' + name
        path = Path(expanded).resolve()
        assert path.is_file(), 'Missing project reference: ' + str(path)
        count += 1
        if path.suffix.lower() != '.c' or not path.is_relative_to(ROOT / SAMPLE):
            continue
        excluded = {item.text for item in node.findall('./excluded/configuration')}
        for role in selected:
            if role not in excluded:
                selected[role].append(path.relative_to(ROOT / SAMPLE).as_posix())
    for role, expected, unexpected in [
        ('CoordinatorEB', ['Source/Coordinator.c', 'app/app_coordinator.c', 'app/app_host_store.c'],
         ['Source/EndDevice.c', 'app/app_terminal.c', 'app/app_database.c']),
        ('EndDeviceEB', ['Source/EndDevice.c', 'app/app_terminal.c', 'app/app_database.c'],
         ['Source/Coordinator.c', 'app/app_coordinator.c', 'app/app_host_store.c'])]:
        assert all(name in selected[role] for name in expected), selected[role]
        assert all(name not in selected[role] for name in unexpected), selected[role]
    assert 'Custom_Driver' not in project.read_text(encoding='utf-8'), 'Stale project reference'
    return {'resolved_file_references': count, 'role_sources': selected}


def main():
    report = {'timestamp': datetime.now().astimezone().isoformat(),
              'reference': check_reference(), 'style': check_style(), 'variables': check_variables(),
              'project': check_project(), 'validation': 'software only; no flashing'}
    destination = ROOT / 'docs/build/hal-app-architecture-check.json'
    destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PASS: reference unchanged, SDK unchanged, naming/braces and role project references valid')
    print(json.dumps({key: value for key, value in report.items() if key != 'project'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
