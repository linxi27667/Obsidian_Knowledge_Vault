"""从 Noto Sans SC 生成本项目 OLED 需要的 GBK 16x16 汉字点阵。"""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
FONT_FILE = ROOT / "assets/fonts/NotoSansSC-Regular.otf"
OUTPUT = (ROOT / "Texas Instruments/ZStack-CC2530-2.5.1a/Projects/zstack/"
          "Samples/SampleApp/app/app_font.h")

# 页面文本均以中文为主；ASCII 数字、时间与学号仍由原 5x7 数字字模绘制。
PHRASES = {
    "COORDINATOR": "协调器",
    "TERMINAL": "终端设备",
    "ONLINE": "在线",
    "OFFLINE": "离线",
    "CLOCK_INVALID": "时钟未校时",
    "USERS": "用户",
    "KEY_HINT": "按1注册 2注销",
    "ATTENDANCE_HINT": "请刷卡考勤",
    "SCAN_REGISTER": "请刷卡注册",
    "SCAN_REMOVE": "请刷卡注销",
    "REGISTER_EXIT": "再按1退出",
    "REMOVE_EXIT": "再按2退出",
    "SECOND": "秒",
    "COUNTDOWN": "倒计时",
    "DB_BUSY": "数据处理中",
    "DB_ERROR": "数据库异常",
    "PEER_OFFLINE": "终端离线",
    "COORD_OFFLINE": "协调器离线",
    "ID": "学号",
    "OK": "操作成功",
    "BUSY": "设备忙",
    "BAD_PARAMETER": "参数错误",
    "UNKNOWN_CARD": "未注册卡",
    "DATABASE_FULL": "存储已满",
    "ALREADY_EXISTS": "卡已注册",
    "CARD_ALREADY_REGISTERED": "该卡已注册",
    "CARD_NOT_REGISTERED": "该卡未注册",
    "ATTENDANCE_UNREGISTERED": "该卡未注册",
    "STORAGE_ERROR": "存储故障",
    "DATABASE_CORRUPT": "数据损坏",
    "ACK_TIMEOUT": "通信超时",
    "PROTOCOL_ERROR": "协议错误",
    "CARD_PROCESSED": "刷卡处理完成",
    "DATABASE_COMMAND": "数据库命令",
    "CARD_OK": "考勤成功",
    "REGISTER_OK": "注册成功",
    "REMOVE_OK": "注销成功",
    "ATTENDANCE_OK": "考勤成功",
    "REGISTER_MODE": "注册模式",
    "REMOVE_MODE": "注销模式",
    "ATTENDANCE_MODE": "考勤模式",
    "SCAN_WITHIN_30_SEC": "请在30秒内刷卡",
    "SCAN_REGISTERED_CARD": "请刷已注册卡",
    "REMOVE_AND_RESCAN": "移开后重刷",
    "NETWORK_READY": "网络已连接",
    "ATTENDANCE_ONLINE": "考勤服务在线",
    "NETWORK_WAIT": "等待组网",
    "LOCAL_ATTENDANCE_READY": "可离线考勤",
    "SAVING": "正在保存",
    "DO_NOT_POWER_OFF": "请勿断电",
    "REMOVE_ONE_CARD": "请先注销一张卡",
}


def glyph(font, character):
    image = Image.new("1", (16, 16), 0)
    draw = ImageDraw.Draw(image)
    # Noto Sans SC 的 16 px 字框从基线上方约 5 px 开始。
    draw.text((0, -5), character, font=font, fill=1)
    columns = []
    for half in range(2):
        for x in range(16):
            value = sum((1 << y) for y in range(8)
                        if image.getpixel((x, half * 8 + y)))
            columns.append(value)
    return columns


def main():
    font = ImageFont.truetype(str(FONT_FILE), 16)
    characters = sorted({char for phrase in PHRASES.values() for char in phrase
                         if ord(char) > 127}, key=lambda char: char.encode("gbk"))
    lines = [
        "/* 由 scripts/generate-oled-font.py 根据 Noto Sans SC 生成。",
        " * 字体许可：SIL Open Font License 1.1，见 assets/fonts/OFL.txt。",
        " * 每字 16x16；前 16 字节为上半页，后 16 字节为下半页。",
        " */",
        "#ifndef ATT_FONT_H",
        "#define ATT_FONT_H",
        "#include \"ZComDef.h\"",
        "",
    ]
    for key, phrase in PHRASES.items():
        escaped = "".join(f"\\x{byte:02X}" for byte in phrase.encode("gbk"))
        lines.append(f'#define CN_{key} "{escaped}" /* {phrase} */')
    lines.extend([
        "",
        "typedef struct",
        "{",
        "  uint16 code;",
        "  uint8 bitmap[32];",
        "} att_hanzi_t;",
        "",
        f"#define ATT_HANZI_COUNT {len(characters)}",
        "static const att_hanzi_t g_att_hanzi[ATT_HANZI_COUNT] =",
        "{",
    ])
    for character in characters:
        code = int.from_bytes(character.encode("gbk"), "big")
        values = glyph(font, character)
        upper = ", ".join(f"0x{value:02X}" for value in values[:16])
        lower = ", ".join(f"0x{value:02X}" for value in values[16:])
        lines.append(f"  {{0x{code:04X}, {{{upper},")
        lines.append(f"            {lower}}}}}, /* {character} */")
    lines.extend(["};", "", "#endif", ""])
    OUTPUT.write_bytes("\r\n".join(lines).encode("cp936"))
    print(f"generated {len(characters)} Chinese glyphs: {OUTPUT}")


if __name__ == "__main__":
    main()
