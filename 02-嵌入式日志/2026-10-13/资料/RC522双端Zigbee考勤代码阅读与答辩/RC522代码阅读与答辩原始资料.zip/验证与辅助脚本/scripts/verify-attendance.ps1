﻿$ErrorActionPreference='Stop'
foreach($test in @('test-board-hal.ps1','test-storage.ps1','test-host-store.ps1','test-rc522.ps1','test-attendance.ps1','test-app.ps1','test-console.ps1','test-common.ps1','test-ui.ps1')) {
  & (Join-Path $PSScriptRoot $test)
  if($LASTEXITCODE){throw "$test failed: $LASTEXITCODE"}
}
# 直接链接UART驱动，防止固定255的业务mock掩盖ESP版发送容量问题。
& (Join-Path $PSScriptRoot 'test-app.ps1') -RealUart
if($LASTEXITCODE){throw "real UART app regression failed: $LASTEXITCODE"}
foreach($role in @('CoordinatorEB','EndDeviceEB')) {
  & (Join-Path $PSScriptRoot 'build-attendance.ps1') -Role $role -Phase 'attendance-final'
  if($LASTEXITCODE){throw "$role build failed: $LASTEXITCODE"}
}
