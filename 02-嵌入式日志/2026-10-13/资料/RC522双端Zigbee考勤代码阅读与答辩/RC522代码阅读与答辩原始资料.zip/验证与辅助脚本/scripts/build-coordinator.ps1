param([string]$Phase = 'current')
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
$project = Join-Path $taskRoot 'Texas Instruments\ZStack-CC2530-2.5.1a\Projects\zstack\Samples\SampleApp\CC2530DB\SampleApp.ewp'
$log = Join-Path $taskRoot "docs\build\$Phase.log"
& 'E:\MCU\IAR for 8051(8.10)\common\bin\IarBuild.exe' $project -build CoordinatorEB -log all *> $log
$buildExit = $LASTEXITCODE
Get-Content -LiteralPath $log -Tail 16
"IAR_EXIT_CODE=$buildExit"
exit $buildExit
