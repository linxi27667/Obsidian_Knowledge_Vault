$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot -Parent
$base=Join-Path $taskRoot 'Texas Instruments\ZStack-CC2530-2.5.1a\Projects\zstack\Samples\SampleApp'
$hostTests=Join-Path $taskRoot 'tests\host'
$exe=Join-Path $taskRoot 'docs\build\test-attendance.exe'
& gcc -std=c99 -Wall -Wextra -Werror "-I$hostTests" "-I$base\hal" "-I$base\app" "-I$base\app\Common" "$hostTests\test_attendance.c" "$base\hal\hal_eeprom.c" "$base\app\app_database.c" "$base\app\Common\comm_protocol.c" -o $exe
if($LASTEXITCODE){exit $LASTEXITCODE}
& $exe | Tee-Object -FilePath (Join-Path $taskRoot 'docs\build\test-attendance.log')
exit $LASTEXITCODE
