param([ValidateSet('CoordinatorEB','EndDeviceEB')][string]$Role='CoordinatorEB',[string]$Phase='attendance')
$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot -Parent
$project=Join-Path $taskRoot 'Texas Instruments\ZStack-CC2530-2.5.1a\Projects\zstack\Samples\SampleApp\CC2530DB\SampleApp.ewp'
$log=Join-Path $taskRoot "docs\build\$Phase-$Role.log"
& 'E:\MCU\IAR for 8051(8.10)\common\bin\IarBuild.exe' $project -build $Role -log all *> $log
$result=$LASTEXITCODE
Get-Content -LiteralPath $log -Tail 16
exit $result
