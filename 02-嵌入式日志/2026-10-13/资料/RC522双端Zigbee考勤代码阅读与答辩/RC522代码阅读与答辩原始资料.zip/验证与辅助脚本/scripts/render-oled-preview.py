from pathlib import Path
from PIL import Image, ImageDraw
root=Path(__file__).resolve().parents[1]/'docs/ui-preview'
files=sorted(root.glob('*.pgm'))
if not files:
 raise SystemExit('No OLED previews found; run scripts/test-ui.ps1 first')
sheet=Image.new('RGB',(1120,((len(files)+1)//2)*330),'#111923')
d=ImageDraw.Draw(sheet)
for i,path in enumerate(files):
 im=Image.open(path).convert('RGB').resize((512,256),Image.Resampling.NEAREST)
 x=28+(i%2)*560;y=24+(i//2)*330
 d.text((x,y),path.stem,fill='#bde4ed')
 sheet.paste(im,(x,y+26))
sheet.save(root/'oled-contact-sheet.png')
print(root/'oled-contact-sheet.png')
