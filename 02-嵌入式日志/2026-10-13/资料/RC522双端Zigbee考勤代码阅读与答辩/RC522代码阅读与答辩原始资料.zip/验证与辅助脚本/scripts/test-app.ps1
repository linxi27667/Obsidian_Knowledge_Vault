param([switch]$RealUart)
$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot -Parent
$base=Join-Path $taskRoot 'Texas Instruments\ZStack-CC2530-2.5.1a\Projects\zstack\Samples\SampleApp'
$source=Join-Path $taskRoot 'Texas Instruments\ZStack-CC2530-2.5.1a\Projects\zstack\Samples\SampleApp\Source'
$hostTests=Join-Path $taskRoot 'tests\host'
$mock=Join-Path $taskRoot 'tests\app_mock'
foreach($role in @('coordinator','terminal')) {
  $exe=Join-Path $taskRoot "docs\build\test-app-$role.exe"
  $defines=@('-DATTENDANCE_HOST_TEST');if($role -eq 'terminal'){$defines+=@('-DATT_TERMINAL')}
  $roleSource=Join-Path $source $(if($role -eq 'terminal'){'EndDevice.c'}else{'Coordinator.c'})
  if($RealUart){$defines+=@('-DAPP_TEST_REAL_UART')}
  $uartSource=Join-Path $base 'app\Common\device1_uart.c'
  $uartSources=@($uartSource);if($RealUart){$uartSources+="$base\hal\hal_console_uart.c"}
  $commonSources=@("$base\app\Common\comm_protocol.c")
  $dbSources=@("$base\hal\hal_eeprom.c");if($role -eq 'terminal'){$dbSources+="$base\app\app_database.c"}else{$dbSources+="$base\app\app_host_store.c"}
  & gcc -std=c99 -Wall -Wextra -Werror -Wno-misleading-indentation @defines "-I$mock" "-I$hostTests" "-I$source" "-I$base\hal" "-I$base\app" "-I$base\app\Common" "$mock\test_app.c" $roleSource "$base\app\app_$role.c" @uartSources @commonSources @dbSources -o $exe
  if($LASTEXITCODE){exit $LASTEXITCODE}
  & $exe | Tee-Object -FilePath (Join-Path $taskRoot "docs\build\test-app-$role.log")
  if($LASTEXITCODE){exit $LASTEXITCODE}
}

