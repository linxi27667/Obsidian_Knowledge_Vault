$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot -Parent
$drivers=Join-Path $taskRoot 'Texas Instruments\ZStack-CC2530-2.5.1a\Projects\zstack\Samples\SampleApp\hal'
$hostTests=Join-Path $taskRoot 'tests\host'
$exe=Join-Path $taskRoot 'docs\build\test-console.exe'
& gcc -std=c99 -Wall -Wextra -Werror -Wno-misleading-indentation "-I$hostTests" "-I$drivers" "$hostTests\test_console.c" "$drivers\hal_console_uart.c" -o $exe
if($LASTEXITCODE){exit $LASTEXITCODE}
& $exe | Tee-Object -FilePath (Join-Path $taskRoot 'docs\build\test-console.log')
exit $LASTEXITCODE
