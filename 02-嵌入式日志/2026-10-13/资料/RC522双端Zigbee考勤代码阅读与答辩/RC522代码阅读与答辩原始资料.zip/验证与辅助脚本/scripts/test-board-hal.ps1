$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot -Parent
$base=Join-Path $taskRoot 'Texas Instruments\ZStack-CC2530-2.5.1a\Projects\zstack\Samples\SampleApp'
$mock=Join-Path $taskRoot 'tests\gpio_mock'
$hostTests=Join-Path $taskRoot 'tests\host'
$exe=Join-Path $taskRoot 'docs\build\test-board-hal.exe'
& gcc -std=c99 -Wall -Wextra -Werror "-I$mock" "-I$hostTests" "-I$base\hal" "$mock\test_board_hal.c" "$base\hal\hal_buzzer.c" "$base\hal\hal_board_key.c" -o $exe
if($LASTEXITCODE){exit $LASTEXITCODE}
& $exe | Tee-Object -FilePath (Join-Path $taskRoot 'docs\build\test-board-hal.log')
exit $LASTEXITCODE
