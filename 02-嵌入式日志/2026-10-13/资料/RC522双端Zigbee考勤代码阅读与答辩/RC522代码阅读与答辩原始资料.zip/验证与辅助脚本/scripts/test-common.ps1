$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
$base = Join-Path $taskRoot 'Texas Instruments\ZStack-CC2530-2.5.1a\Projects\zstack\Samples\SampleApp'
$hostTests = Join-Path $taskRoot 'tests\host'
$afMock = Join-Path $taskRoot 'tests\common_mock'
$exe = Join-Path $taskRoot 'docs\build\test-common.exe'
& gcc -std=c99 -Wall -Wextra -Werror "-I$afMock" "-I$hostTests" `
  "-I$base\Source" "-I$base\hal" "-I$base\app\Common" `
  "$hostTests\test_common.c" "$base\app\Common\comm_protocol.c" `
  "$base\app\Common\comm_unicast.c" "$base\app\Common\comm_broadcast.c" `
  "$base\app\Common\device1_uart.c" "$base\hal\hal_console_uart.c" -o $exe
if ($LASTEXITCODE) { exit $LASTEXITCODE }
& $exe | Tee-Object -FilePath (Join-Path $taskRoot 'docs\build\test-common.log')
exit $LASTEXITCODE
