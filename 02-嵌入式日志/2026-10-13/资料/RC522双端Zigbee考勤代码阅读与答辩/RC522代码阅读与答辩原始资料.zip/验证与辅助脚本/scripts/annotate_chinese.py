"""从原版同步在用HAL/APP源码，并为中文注释版补充函数阅读说明。"""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL_ROOT = ROOT.parent / 'RC522大作业'
ANNOTATED_ROOT = ROOT.parent / 'RC522大作业_中文注释版'
RELATIVE_APP = Path('Texas Instruments/ZStack-CC2530-2.5.1a/Projects/zstack/Samples/SampleApp')
APP = ANNOTATED_ROOT / RELATIVE_APP

PURPOSES = {
    'app_coordinator': '协调器业务：串口管理、模式同步、远程刷卡、应答和时间源。',
    'app_terminal': '终端业务：本地刷卡、名单管理、异步提交、远程响应和考勤上报。',
    'app_database': '终端AT24C08权威数据库：名单、循环日志、双镜像与重复事务保护。',
    'app_host_store': '协调器AT24C02本机统计：成功应答后计数，双镜像异步保存。',
    'device1_uart': '旧 Device1_UART 串口模块：找命令、判断类型、拆参数、回调。',
    'comm_unicast': '直接恢复旧 Common 单播接口，AF 发送与接收回调。',
    'comm_broadcast': '直接恢复旧 Common 广播接口，AF 消息仍按 Cluster 分发。',
    'comm_protocol': '旧 Common 协议入口，按现有 ATT2 字段打包、校验、解包。',
    'app_ui': '中文OLED业务页面与128字节页缓冲，按事件增量刷新。',
    'app_font': 'Noto Sans SC生成的GBK 16x16点阵与中文文案。',
    'hal_buzzer': 'P0.0蜂鸣器独立驱动，OSAL单次定时事件关闭输出。',
    'hal_board_key': '板上按键消抖；原SDK hal_key负责引脚读取。',
    'hal_console_uart': 'UART0唯一拥有者：38400、收发缓存、分行、背压和OSAL接收事件。',
    'hal_eeprom': 'AT24C02/08的块地址、分页读写和有界ACK轮询。',
    'hal_i2c': 'P1.2/P1.1软件开漏I2C、总线释放和应答时序。',
    'hal_oled': 'SSD1306地址探测、命令、ASCII字模和分段数据写入。',
    'hal_rc522': '软件SPI、MFRC522选卡和4/7/10字节UID读取。',
    'hal_rtc': 'RX8010日期校验、有效标记、读写时钟；编译时间仅供协调器初始化。',
    'hal_delay': '原项目的短延时接口，不承担业务调度。',
    'board_config': '自制板引脚、电气默认状态和ESP禁用配置。',
    'Coordinator': '协调器任务调度：初始化、AF/ZDO消息分发和逐项OSAL事件。',
    'EndDevice': '终端任务调度：初始化、AF消息分发和逐项OSAL事件。',
    'SampleApp': '两角色共用的端点、Cluster、事件位和周期配置。',
    'OSAL_SampleApp': '原Z-Stack任务表与初始化顺序；不要增加第二套建网入口。',
}

EXTRA = {
    'App_Database_Last_Scan_Mode': '读取最后一次持久化远程刷卡的实际模式，重启后重发仍返回原结果类型。',
    'App_Host_Store_Image_Crc': '暂时清除提交标记和CRC字段计算镜像校验值，然后恢复RAM内容。',
    'App_Host_Store_Image_Valid': '检查统计镜像魔数、版本、提交标记和CRC，拒绝未完整提交的镜像。',
    'App_Host_Store_Is_Blank': '检查两个统计镜像是否全为FF；只有全空芯片可以自动建立空统计。',
    'App_Host_Store_Image_Empty': '在RAM准备空统计镜像，不立即写EEPROM。',
    'App_Host_Store_Save_Start': '更新目标镜像代次与CRC，启动失效、写入、回读和最后提交过程。',
    'App_Host_Store_Count_Increment': '增加16位累计计数；到65535后饱和，避免回绕误显示为零。',
    'App_Host_Store_Init': '配置协调器AT24C02并安排两个64字节镜像的逐步读取。',
    'App_Host_Store_Status': '报告统计存储状态；初始化或提交期间返回忙。',
    'App_Host_Store_Count': '按考勤、注册、注销模式读取已经提交的本机计数。',
    'App_Host_Store_Boot_Count': '读取已经提交的启动次数，不把尚未提交的数据当成成功。',
    'App_Host_Store_Record': '复制活动镜像，记录本机成功扫描的计数、UID和原始时间；ATT_OK仅表示接受异步请求。',
    'App_Host_Store_Reset': '在用户明确确认后建立空统计镜像，保留原镜像直到新提交成功。',
    'App_Host_Store_Process': '每10ms推进一次读取或提交；写入失败保留上一份活动统计。',
    'osalInitTasks': '保持原SDK顺序初始化HAL、MAC、NWK、ZDO及SampleApp；应用只注册一次。',
}

def read_source(path):
    raw = path.read_bytes()
    try:
        return raw.decode('utf-8-sig').replace('\r\r\n', '\n').replace('\r\n', '\n')
    except UnicodeError:
        return raw.decode('cp936').replace('\r\r\n', '\n').replace('\r\n', '\n')

def source_mask(source):
    pattern = r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
    return re.sub(pattern, lambda m: ''.join('\n' if c == '\n' else ' ' for c in m[0]), source)

def active_files():
    base = ORIGINAL_ROOT / RELATIVE_APP
    files = []
    for folder in ['hal', 'app']:
        files.extend(p.relative_to(base).as_posix() for p in (base / folder).rglob('*')
                     if p.is_file() and p.suffix in ['.c', '.h'])
    files.extend('Source/' + name for name in ['Coordinator.c', 'EndDevice.c', 'SampleApp.h'])
    return sorted(files)

FILE_NOTES = {relative: PURPOSES.get(Path(relative).stem, '本项目使用的应用或硬件接口。')
              for relative in active_files()}

def function_notes():
    notes = json.loads((ORIGINAL_ROOT / 'docs/hal-app-function-notes.json').read_text(encoding='utf-8'))
    for role in ['Coordinator', 'Terminal']:
        name = 'app/app_' + role.lower() + '.c'
        notes.setdefault(name, {}).update({
            f'App_{role}_Init': '初始化角色业务状态、LED、按键和蜂鸣器；串口、通信、端点与定时事件由角色主文件注册。',
            f'App_{role}_Peripherals_Process': '按调用次数依次初始化外设；准备完成返回1，由角色任务启动刷卡和存储事件。',
            f'App_{role}_Network_Update': '接收ZDO状态变化；更新联网状态，终端就绪时立即发送HELLO取协调器时间。',
            f'App_{role}_Database_Process': '推进本角色EEPROM服务；终端完成提交后才应答、显示结果并通知协调器。',
            f'App_{role}_Display_Process': '读取角色业务状态并推进中文界面的分段刷新。',
            f'App_{role}_Retry_Process': '处理两秒无线重试；终端通知超时不会撤销已保存考勤或阻塞本机操作。',
        })
    return notes

def annotate(relative, source, notes):
    entries = notes.get(relative, {})
    entries = {**entries, **EXTRA}
    mask = source_mask(source)
    pattern = r'(?m)^(?:static\s+)?(?:const\s+)?[\w]+\s+\*?\s*(\w+)\s*\([^;{}]*\)\s*'
    insertions = []
    for match in re.finditer(pattern, mask):
        end = match.end()
        if end >= len(mask) or mask[end] not in '{;':
            continue
        if relative.endswith('.c') and mask[end] != '{':
            continue
        if relative.endswith('.h') and mask[end] != ';':
            continue
        name = match[1]
        summary = entries.get(name)
        if summary:
            insertions.append((match.start(), '/* 功能：' + summary + ' */\n'))
    for position, comment in sorted(insertions, reverse=True):
        source = source[:position] + comment + source[position:]
    purpose = FILE_NOTES[relative]
    return '/* 中文注释版：' + purpose + '\n * 额外注释不改变原版函数逻辑、协议和存储格式。\n */\n' + source

def main():
    notes = function_notes()
    for relative in FILE_NOTES:
        source = read_source(ORIGINAL_ROOT / RELATIVE_APP / relative)
        target = APP / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(annotate(relative, source, notes).replace('\n', '\r\n').encode('cp936'))
    print('annotated', len(FILE_NOTES), 'active files; SDK task callbacks keep original names')

if __name__ == '__main__':
    main()
