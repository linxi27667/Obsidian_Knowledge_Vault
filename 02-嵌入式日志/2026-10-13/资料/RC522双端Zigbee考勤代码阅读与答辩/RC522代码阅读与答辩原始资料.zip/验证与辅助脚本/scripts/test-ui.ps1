$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot -Parent
$base=Join-Path $taskRoot 'Texas Instruments\ZStack-CC2530-2.5.1a\Projects\zstack\Samples\SampleApp'
$hostTests=Join-Path $taskRoot 'tests\host'
$exe=Join-Path $taskRoot 'docs\build\test-ui.exe'
New-Item -ItemType Directory -Force (Join-Path $taskRoot 'docs/ui-preview') | Out-Null
& gcc -std=c99 -Wall -Wextra -Werror "-I$hostTests" "-I$base\hal" "-I$base\app" "-I$base\app\Common" "$hostTests\test_ui.c" "$base\hal\hal_oled.c" "$base\app\app_ui.c" -o $exe
if($LASTEXITCODE){exit $LASTEXITCODE}
Push-Location $taskRoot
try { & $exe | Tee-Object -FilePath (Join-Path $taskRoot 'docs\build\test-ui.log');$result=$LASTEXITCODE } finally { Pop-Location }
exit $result
