$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
$drivers = Join-Path $taskRoot 'Texas Instruments\ZStack-CC2530-2.5.1a\Projects\zstack\Samples\SampleApp\hal'
$hostTests = Join-Path $taskRoot 'tests\host'
$exe = Join-Path $taskRoot 'docs\build\test-rc522.exe'
& gcc -std=c99 -Wall -Wextra -Werror "-I$hostTests" "-I$drivers" `
  "$hostTests\test_rc522.c" "$drivers\hal_rc522.c" -o $exe
if ($LASTEXITCODE) { exit $LASTEXITCODE }
& $exe | Tee-Object -FilePath (Join-Path $taskRoot 'docs\build\test-rc522.log')
exit $LASTEXITCODE
