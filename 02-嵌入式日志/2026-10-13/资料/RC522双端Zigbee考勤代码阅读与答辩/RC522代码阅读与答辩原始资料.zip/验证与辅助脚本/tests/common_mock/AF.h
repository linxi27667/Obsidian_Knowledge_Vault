#ifndef COMMON_TEST_AF_H
#define COMMON_TEST_AF_H
#include "ZComDef.h"

typedef uint8 afStatus_t;
typedef enum { Addr16Bit = 2, AddrBroadcast = 15 } afAddrMode_t;
typedef struct
{
    afAddrMode_t addrMode;
    uint8 endPoint;
    union { uint16 shortAddr; } addr;
} afAddrType_t;
typedef struct { uint8 endPoint; } endPointDesc_t;
typedef struct
{
    afAddrType_t srcAddr;
    struct { uint8 *Data; uint8 DataLength; } cmd;
} afIncomingMSGPacket_t;

#define afStatus_SUCCESS 0
#define AF_DISCV_ROUTE 0x20
#define AF_DEFAULT_RADIUS 30
afStatus_t AF_DataRequest(afAddrType_t *destination, endPointDesc_t *endpoint,
                         uint16 cluster, uint8 len, uint8 *data,
                         uint8 *transaction, uint8 options, uint8 radius);
#endif
