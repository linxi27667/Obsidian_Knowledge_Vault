#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "app_database.h"
#include "hal_eeprom.h"
static uint8 memory[1024],snapshot[1024],baseline[1024];
static uint32 ticks;
static uint8 failWrite,failRead;
uint32 osal_GetSystemClock(void) {return ticks;}
uint8 Hal_I2c_Write(uint8 a,const uint8 *p,uint8 n) {(void)p;assert(a>=0x50&&a<=0x53&&!n);return 0;}
uint8 Hal_I2c_Read_Reg(uint8 a,uint8 reg,uint8 *p,uint8 n) {
  assert(a>=0x50&&a<=0x53&&n<=32&&(uint16)reg+n<=256);
  if(failRead)return I2C_NACK;
  memcpy(p,memory+(a-0x50)*256+reg,n);return 0;
}
uint8 Hal_I2c_Write_Reg(uint8 a,uint8 reg,const uint8 *p,uint8 n) {
  assert(a>=0x50&&a<=0x53&&n<=16&&reg/16==(reg+n-1)/16);
  if(failWrite)return I2C_NACK;
  memcpy(memory+(a-0x50)*256+reg,p,n);return 0;
}
static void settle(void) {int i=0;while(App_Database_Status()==ATT_BUSY) {ticks+=10;App_Database_Tick();assert(++i<1000);} }
static void boot(void) {App_Database_Init();settle();App_Database_Take_Done();}
static uint8 scan[48];
static void card(uint8 mode,uint8 uid) {
  memset(scan,0,sizeof(scan));scan[0]=mode;scan[1]=4;scan[2]=uid;
  scan[40]=26;scan[41]=9;scan[42]=23;scan[43]=12;scan[46]=1;
}
static void commit(uint8 op,const uint8 *p,uint8 n,uint16 tx) {
  assert(App_Database_Execute(op,p,n,123,tx,1)==ATT_BUSY);settle();assert(App_Database_Take_Done());assert(App_Database_Reply()[0]==ATT_OK);
}
int main(void) {
  uint8 a[32],b[32],frame[62],q=0;uint16 generation;int i,j,cuts=0;
  memset(memory,255,sizeof(memory));assert(Hal_Eeprom_Configure(1024,16)==0);
  for(i=0;i<32;i++)a[i]=(uint8)i;
  assert(Hal_Eeprom_Write(250,a,32)==0);while(Hal_Eeprom_Is_Busy()){ticks+=10;Hal_Eeprom_Process();}
  assert(Hal_Eeprom_Read(250,b,32)==0&&!memcmp(a,b,32));
  assert(Hal_Eeprom_Write_Byte(1023,0xA6)==0);while(Hal_Eeprom_Is_Busy()){ticks+=10;Hal_Eeprom_Process();}
  assert(memory[1023]==0xA6);assert(Hal_Eeprom_Write(1023,a,2)==I2C_PARAM);assert(Hal_Eeprom_Read(65535,b,2)==I2C_PARAM);
  memset(memory,255,sizeof(memory));boot();assert(App_Database_Status()==ATT_OK&&App_Database_Count()==0);
  card(0,1);assert(App_Database_Execute(ATT_SCAN,scan,48,123,1,1)==ATT_UNKNOWN);
  card(1,1);commit(ATT_SCAN,scan,48,2);assert(App_Database_Count()==1);generation=App_Database_Generation();
  boot();assert(App_Database_Count()==1&&App_Database_Generation()==generation);assert(App_Database_Last_Scan_Mode()==1);
  assert(App_Database_Execute(ATT_SCAN,scan,48,123,2,1)==ATT_OK&&App_Database_Generation()==generation);
  assert(App_Database_Execute(ATT_SCAN,scan,48,123,3,1)==ATT_EXISTS);
  assert(App_Database_Execute(ATT_USER,&q,1,0,0,0)==0&&App_Database_Reply_Size()==44&&!memcmp(App_Database_Reply()+15,"202600000001",12));
  memcpy(baseline,memory,1024);
  /* 对每个异步步骤截断供电，已有成功注册必须始终可以恢复。 */
  for(i=0;i<110;i++) {
    memcpy(memory,baseline,1024);boot();card(1,2);assert(App_Database_Execute(ATT_SCAN,scan,48,123,4,1)==ATT_BUSY);
    for(j=0;j<i&&App_Database_Status()==ATT_BUSY;j++){ticks+=10;App_Database_Tick();}
    memcpy(snapshot,memory,1024);settle();memcpy(memory,snapshot,1024);boot();
    assert(App_Database_Status()==0&&(App_Database_Count()==1||App_Database_Count()==2));++cuts;
  }
  memcpy(memory,baseline,1024);boot();card(1,2);failWrite=1;
  assert(App_Database_Execute(ATT_SCAN,scan,48,123,4,1)==ATT_BUSY);settle();assert(App_Database_Reply()[0]==ATT_STORAGE&&App_Database_Count()==1);failWrite=0;
  card(1,2);commit(ATT_SCAN,scan,48,4);memcpy(snapshot,memory,1024);
  for(i=512;i<1024;i++) {
    memcpy(memory,snapshot,1024);memory[i]^=1;boot();assert(App_Database_Status()==0&&App_Database_Count()==1);
  }
  memcpy(memory,baseline,1024);boot();
  for(i=2;i<=8;i++){card(1,(uint8)i);commit(ATT_SCAN,scan,48,(uint16)(10+i));}
  assert(App_Database_Count()==8);card(1,9);assert(App_Database_Execute(ATT_SCAN,scan,48,123,30,1)==ATT_FULL);
  for(i=0;i<15;i++){card(0,1);commit(ATT_SCAN,scan,48,(uint16)(40+i));}
  q=0;assert(App_Database_Execute(ATT_LOG,&q,1,0,0,0)==0&&Comm_Protocol_ReadUint16(App_Database_Reply()+18)==15);
  q=9;assert(App_Database_Execute(ATT_LOG,&q,1,0,0,0)==0&&Comm_Protocol_ReadUint16(App_Database_Reply()+18)==6);
  card(2,1);commit(ATT_SCAN,scan,48,70);assert(App_Database_Count()==7);
  card(1,9);assert(App_Database_Execute(ATT_SCAN,scan,48,123,40,1)==ATT_PARAM);
  q=0;assert(App_Database_Execute(ATT_LOG,&q,1,0,0,0)==0);assert(App_Database_Reply()[4]==0x20&&App_Database_Reply()[9]==0x01);
  card(0,1);assert(App_Database_Execute(ATT_SCAN,scan,48,123,71,1)==ATT_UNKNOWN);
  boot();assert(App_Database_Count()==7);failRead=1;boot();assert(App_Database_Status()==ATT_STORAGE);failRead=0;boot();
  memset(memory,0x55,1024);boot();assert(App_Database_Status()==ATT_CORRUPT);assert(App_Database_Execute(ATT_SCAN,scan,48,123,72,1)==ATT_CORRUPT);
  commit(ATT_FORMAT,(const uint8 *)"INIT",4,73);boot();assert(App_Database_Count()==0&&App_Database_Status()==0);
  card(1,1);scan[1]=7;commit(ATT_SCAN,scan,48,74);
  card(1,1);scan[1]=10;commit(ATT_SCAN,scan,48,75);assert(App_Database_Count()==2);
  assert(Comm_Protocol_CalcChecksum((const uint8 *)"123456789",9)==0x29B1);
  assert(Comm_Protocol_PackFrame(frame, sizeof(frame),ATT_SCAN,123,3,scan,48)==58&&Comm_Protocol_ValidateFrame(frame,58)==COMM_OK);
  for(i=0;i<58;i++){frame[i]^=1;assert(Comm_Protocol_ValidateFrame(frame,58)!=COMM_OK);frame[i]^=1;}
  for(i=0;i<58;i++)assert(Comm_Protocol_ValidateFrame(frame,(uint8)i)!=COMM_OK);
  printf("PASS: AT24C08 block/page/bounds; DB reboot, %d power cuts, replay, full/delete/log ring, IO failures; wire CRC/truncation\n",cuts);
  return 0;
}
