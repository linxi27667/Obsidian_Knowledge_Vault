#include "ZComDef.h"
#define BOARD_DEBUG_UART_PORT 0
extern uint8 mock_cs, mock_clk, mock_mosi, P1SEL, P1DIR;
uint8 Mock_Miso(void);
#define BOARD_RC522_CS_PIN mock_cs
#define BOARD_RC522_CLK_PIN mock_clk
#define BOARD_RC522_MOSI_PIN mock_mosi
#define BOARD_RC522_MISO_PIN Mock_Miso()
#define BOARD_RC522_CS_MASK 0x10
#define BOARD_RC522_CLK_MASK 0x20
#define BOARD_RC522_MOSI_MASK 0x40
#define BOARD_RC522_MISO_MASK 0x80
