#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "app_ui.h"
#include "app_font.h"
#include "hal_i2c.h"
static unsigned char screen[1024];
static unsigned char expected[1024];
static uint8 page,column;
uint8 Hal_I2c_Probe(uint8 addr) {return addr==0x3C?0:I2C_NACK;}
uint8 Hal_I2c_Write(uint8 addr,const uint8 *p,uint8 n) {
  uint8 i;assert(addr==0x3C&&n<=32);
  if(p[0]==0 && n==4 && (p[1]&0xF8)==0xB0){page=p[1]&7;column=(p[2]&15)|((p[3]&15)<<4);}
  else if(p[0]==0x40){for(i=1;i<n;i++){assert(page<8&&column<128);screen[page*128+column++]=p[i];}}
  return 0;
}
static void capture(const char *name) {
  unsigned int x,y;char path[160];FILE *f;
  for(x=0;x<100;x++) App_Ui_Tick();
  assert(App_Ui_Error()==0);snprintf(path,sizeof(path),"docs/ui-preview/%s.pgm",name);f=fopen(path,"wb");assert(f);
  fprintf(f,"P5\n128 64\n255\n");
  for(y=0;y<64;y++)for(x=0;x<128;x++)fputc(screen[(y/8)*128+x]&(1<<(y%8))?255:0,f);
  fclose(f);
}
int main(void) {
  rtc_time_t t={56,34,12,3,23,9,26};int i;
  for(i=1;i<ATT_HANZI_COUNT;i++)assert(g_att_hanzi[i-1].code<g_att_hanzi[i].code);
  App_Ui_Init(0);App_Ui_Time(&t,0);App_Ui_Status(1,1,0,2,0,0);capture("01-home");
  App_Ui_Status(1,1,0,2,1,24);capture("02-register");
  App_Ui_Status(1,1,0,2,1,27);capture("09-register-exit");
  App_Ui_Status(1,1,0,2,2,16);capture("03-remove");
  App_Ui_Status(1,1,1,2,0,0);App_Ui_Message("SAVING","DO NOT POWER OFF");capture("04-saving");
  memcpy(expected,screen,sizeof(screen));
  App_Ui_Message(CN_SAVING,CN_DO_NOT_POWER_OFF);
  for(i=0;i<100;i++)App_Ui_Tick();
  assert(memcmp(expected,screen,sizeof(screen))==0);
  App_Ui_Status(1,1,0,3,0,0);App_Ui_Message("ATTENDANCE OK","202600000001");capture("05-success");
  memcpy(expected,screen,sizeof(screen));
  App_Ui_Message(CN_ATTENDANCE_OK,"202600000001");
  for(i=0;i<100;i++)App_Ui_Tick();
  assert(memcmp(expected,screen,sizeof(screen))==0);
  for(i=0;i<5;i++)App_Ui_Second();
  App_Ui_Status(1,0,8,0,0,0);capture("06-offline");
  App_Ui_Message("READER OFFLINE","CARD PROCESSED");capture("10-offline-swipe-05");
  memcpy(expected,screen,sizeof(screen));
  App_Ui_Second();capture("11-offline-swipe-04");
  assert(memcmp(expected+2*128,screen+2*128,2*128)!=0);
  assert(memcmp(expected+6*128,screen+6*128,2*128)==0);
  for(i=0;i<4;i++)App_Ui_Second();
  App_Ui_Time(&t,5);capture("07-clock-invalid");
  App_Ui_Message("DATABASE FULL","REMOVE ONE CARD");capture("08-full");
  App_Ui_Message("CARD ALREADY REGISTERED","CARD PROCESSED");capture("12-already-registered");
  memcpy(expected,screen,sizeof(screen));
  App_Ui_Message(CN_CARD_ALREADY_REGISTERED,CN_CARD_PROCESSED);
  for(i=0;i<100;i++)App_Ui_Tick();
  assert(memcmp(expected,screen,sizeof(screen))==0);
  App_Ui_Message("CARD NOT REGISTERED","CARD PROCESSED");capture("13-card-not-registered");
  App_Ui_Message("ATTENDANCE UNREGISTERED","CARD PROCESSED");capture("14-attendance-unregistered");
  puts("PASS: OLED bounds, countdown, Chinese registration/attendance results, 14 screens");return 0;
}
