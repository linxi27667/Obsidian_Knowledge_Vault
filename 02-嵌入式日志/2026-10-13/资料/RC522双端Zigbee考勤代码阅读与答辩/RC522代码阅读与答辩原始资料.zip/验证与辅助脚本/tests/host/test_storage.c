#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "hal_eeprom.h"
#include "hal_rtc.h"
static uint8 ee[256], rtc[64];
static uint32 now;
static uint8 busyPolls, forceNack, failWrite, pages;
static uint8 pageAddr[8], pageLen[8];
uint32 osal_GetSystemClock(void) { return now; }
uint8 Hal_I2c_Write(uint8 addr, const uint8 *data, uint8 len)
{
  (void)data; (void)len; assert(addr == EEPROM_I2C_ADDR);
  if (forceNack) return I2C_NACK;
  if (busyPolls) { --busyPolls; return I2C_NACK; }
  return I2C_OK;
}
uint8 Hal_I2c_Write_Reg(uint8 addr, uint8 reg, const uint8 *data, uint8 len)
{
  if (failWrite) return I2C_TIMEOUT;
  if (addr == EEPROM_I2C_ADDR)
  {
    assert(len && (reg % 8)+len <= 8);
    assert((uint16)reg+len <= 256);
    pageAddr[pages] = reg; pageLen[pages++] = len;
    memcpy(ee+reg, data, len); busyPolls = 1;
  }
  else { assert(addr == RTC_I2C_ADDR); memcpy(rtc+reg, data, len); }
  return I2C_OK;
}
uint8 Hal_I2c_Read_Reg(uint8 addr, uint8 reg, uint8 *data, uint8 len)
{
  if (!data || len > 32) return I2C_PARAM;
  memcpy(data, addr == EEPROM_I2C_ADDR ? ee+reg : rtc+reg, len);
  return I2C_OK;
}
int main(void)
{
  uint8 input[10] = {1,2,3,4,5,6,7,8,9,10}, out[10], result;
  rtc_time_t t = {59,58,23,4,29,2,24}, got;
  assert(Hal_Eeprom_Init() == I2C_OK);
  assert(Hal_Eeprom_Write(250, input, 10) == I2C_PARAM);
  assert(Hal_Eeprom_Write(7, input, 10) == I2C_OK);
  memset(input, 0, sizeof(input)); /* Writer owns a copy, not caller's buffer. */
  assert(Hal_Eeprom_Read(7, out, 10) == I2C_BUSY);
  assert(Hal_Eeprom_Write_Byte(0, 3) == I2C_BUSY);
  do { now += 10; result = Hal_Eeprom_Process(); } while (result == I2C_BUSY);
  assert(result == I2C_OK && pages == 3);
  assert(pageAddr[0] == 7 && pageLen[0] == 1);
  assert(pageAddr[1] == 8 && pageLen[1] == 8);
  assert(pageAddr[2] == 16 && pageLen[2] == 1);
  assert(Hal_Eeprom_Read(7, out, 10) == I2C_OK && out[0] == 1 && out[9] == 10);
  assert(Hal_Eeprom_Write_Byte(40, 0x55) == I2C_OK);
  assert(Hal_Eeprom_Process() == I2C_BUSY);
  forceNack = 1; now += 30;
  assert(Hal_Eeprom_Process() == I2C_TIMEOUT && !Hal_Eeprom_Is_Busy());
  forceNack = 0; failWrite = 1;
  assert(Hal_Eeprom_Write_Byte(40, 0x55) == I2C_OK);
  assert(Hal_Eeprom_Process() == I2C_TIMEOUT && !Hal_Eeprom_Is_Busy());
  failWrite = 0;
  assert(Hal_Rtc_Set_Time(&t) == I2C_OK);
  assert(Hal_Rtc_Read_Time(&got) == I2C_OK && memcmp(&t,&got,sizeof(t)) == 0);
  t.year = 25;
  assert(Hal_Rtc_Set_Time(&t) == I2C_PARAM); /* Reject nonexistent 2025-02-29. */
  rtc[0x1E] = 2;
  assert(Hal_Rtc_Read_Time(&got) == RTC_TIME_INVALID);
  assert(Hal_Rtc_Seed_Build_Time(&got) == I2C_OK);
  assert(got.year == (__DATE__[9]-'0')*10 + __DATE__[10]-'0');
  assert(Hal_Rtc_Read_Time(&got) == I2C_OK && rtc[0x1E] == 0);
  assert(Hal_Rtc_Seed_Build_Time(NULL) == I2C_PARAM);
  rtc[0x1E] = 0; rtc[0x10] = 0x6A;
  assert(Hal_Rtc_Read_Time(&got) == RTC_TIME_INVALID); /* Invalid BCD. */
  rtc[0x10] = 0; rtc[0x13] = 3;
  assert(Hal_Rtc_Read_Time(&got) == RTC_TIME_INVALID); /* Weekday must be one-hot. */
  puts("PASS: EEPROM page split, copy ownership, busy, timeout; RTC BCD/calendar/VLF");
  return 0;
}
