#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "hal_console_uart.h"
#include "hal_uart.h"
static char rx[300],tx[2000],lines[10][80];
static unsigned pos,len,used,count;
static uint8 blocked;
uint8 osal_set_event(uint8 t,uint16 e){(void)t;(void)e;return 0;}
void HalUARTOpen(uint8 port,halUARTCfg_t *cfg){assert(port==0&&cfg->baudRate==38400&&!cfg->flowControl);}
uint16 HalUARTWrite(uint8 port,uint8 *p,uint16 n){(void)port;if(blocked)return 0;assert(used+n<sizeof(tx));memcpy(tx+used,p,n);used+=n;tx[used]=0;return n;}
uint16 HalUARTRead(uint8 port,uint8 *p,uint16 n){(void)port;assert(n==1);if(pos==len)return 0;*p=rx[pos++];return 1;}
uint16 Hal_UART_RxBufLen(uint8 port){(void)port;return (uint16)(len-pos);}
static void handler(char *line){assert(count<10);strcpy(lines[count++],line);}
static void feed(const char *s){strcpy(rx,s);pos=0;len=(unsigned)strlen(rx);while(pos<len)Hal_Uart_Process_Rx();}
int main(void){
  int i;char b[200];Hal_Uart_Init(1,2);Hal_Uart_Set_Handler(handler);
  feed("#DB UID");assert(count==0);feed("\r\n#STATUS\n#TIME\r");assert(count==3&&!strcmp(lines[0],"#DB UID")&&!strcmp(lines[2],"#TIME"));
  memset(b,'X',120);strcpy(b+120,"\n#DB BEEP\n");feed(b);assert(count==4&&!strcmp(lines[3],"#DB BEEP"));
  feed("#DB REGX\b\r");assert(count==5&&!strcmp(lines[4],"#DB REG"));
  for(i=0;i<20;i++)Hal_Uart_Flush();assert(strstr(tx,"LINE_TOO_LONG"));
  used=0;blocked=1;Hal_Uart_Print("0123456789");for(i=0;i<10;i++)Hal_Uart_Flush();assert(!used&&Hal_Uart_Free()==245);
  blocked=0;Hal_Uart_Flush();assert(!strcmp(tx,"0123456789")&&Hal_Uart_Free()==255);
  for(i=0;i<300;i++)Hal_Uart_Print("x");assert(g_uart_dropped==45&&Hal_Uart_Free()==0);
  for(i=0;i<20;i++)Hal_Uart_Flush();assert(Hal_Uart_Free()==255);
  puts("PASS: console CR/LF, no early UID execution, overflow recovery, backspace, TX backpressure/ring bounds");return 0;
}
