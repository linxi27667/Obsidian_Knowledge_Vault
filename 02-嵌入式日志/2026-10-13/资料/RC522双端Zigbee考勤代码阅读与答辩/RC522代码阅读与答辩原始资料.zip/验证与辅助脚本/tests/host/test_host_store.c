#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "app_host_store.h"
#include "comm_protocol.h"
#include "hal_eeprom.h"

static uint8 memory[256], baseline[256], interrupted[256];
static uint32 ticks;
static uint8 failWrite;

uint32 osal_GetSystemClock(void)
{
    return ticks;
}

uint8 Hal_I2c_Write(uint8 address, const uint8 *data, uint8 length)
{
    (void)data;
    assert(address == 0x50 && length == 0);
    return I2C_OK;
}

uint8 Hal_I2c_Read_Reg(uint8 address, uint8 offset, uint8 *data, uint8 length)
{
    assert(address == 0x50 && (uint16)offset + length <= 256);
    memcpy(data, memory + offset, length);
    return I2C_OK;
}

uint8 Hal_I2c_Write_Reg(uint8 address, uint8 offset, const uint8 *data, uint8 length)
{
    assert(address == 0x50 && length <= 8 && offset / 8 == (offset + length - 1) / 8);
    assert((uint16)offset + length <= 128);
    if (failWrite)
    {
        return I2C_NACK;
    }
    memcpy(memory + offset, data, length);
    return I2C_OK;
}

static void Test_Host_Settle(void)
{
    uint16 steps = 0;

    while (App_Host_Store_Status() == ATT_BUSY)
    {
        ticks += 10;
        App_Host_Store_Process();
        assert(++steps < 1000);
    }
}

static void Test_Host_Boot(void)
{
    App_Host_Store_Init();
    Test_Host_Settle();
}

int main(void)
{
    uint8 uid[10] = {3, 0x26, 0x4D, 5};
    rtc_time_t time = {7, 5, 13, 2, 29, 9, 26};
    int cut, step;

    memset(memory, 0xFF, sizeof(memory));
    Test_Host_Boot();
    assert(App_Host_Store_Status() == ATT_OK && App_Host_Store_Boot_Count() == 1);
    assert(App_Host_Store_Record(0, uid, 4, &time, 0) == ATT_OK);
    assert(App_Host_Store_Record(0, uid, 4, &time, 0) == ATT_BUSY);
    Test_Host_Settle();
    assert(App_Host_Store_Count(0) == 1);
    memcpy(baseline, memory, sizeof(memory));

    /* 在每个提交步骤截断，重启只能看到完整旧计数或完整新计数。 */
    for (cut = 0; cut < 60; ++cut)
    {
        memcpy(memory, baseline, sizeof(memory));
        Test_Host_Boot();
        assert(App_Host_Store_Record(0, uid, 7, &time, 0) == ATT_OK);
        for (step = 0; step < cut && App_Host_Store_Status() == ATT_BUSY; ++step)
        {
            ticks += 10;
            App_Host_Store_Process();
        }
        memcpy(interrupted, memory, sizeof(memory));
        Test_Host_Settle();
        memcpy(memory, interrupted, sizeof(memory));
        Test_Host_Boot();
        assert(App_Host_Store_Status() == ATT_OK);
        assert(App_Host_Store_Count(0) == 1 || App_Host_Store_Count(0) == 2);
        assert(memory[128] == 0xFF && memory[255] == 0xFF);
    }

    memcpy(memory, baseline, sizeof(memory));
    Test_Host_Boot();
    failWrite = 1;
    assert(App_Host_Store_Record(1, uid, 10, &time, 0) == ATT_OK);
    Test_Host_Settle();
    assert(App_Host_Store_Status() == ATT_STORAGE);
    failWrite = 0;
    Test_Host_Boot();
    assert(App_Host_Store_Count(0) == 1 && App_Host_Store_Count(1) == 0);

    assert(App_Host_Store_Record(2, uid, 10, &time, 5) == ATT_OK);
    Test_Host_Settle();
    assert(App_Host_Store_Count(2) == 1);
    assert(App_Host_Store_Record(3, uid, 4, &time, 0) == ATT_PARAM);
    assert(App_Host_Store_Record(0, uid, 5, &time, 0) == ATT_PARAM);

    memset(memory, 0x55, sizeof(memory));
    Test_Host_Boot();
    assert(App_Host_Store_Status() == ATT_CORRUPT);
    assert(memory[0] == 0x55 && memory[127] == 0x55);
    assert(App_Host_Store_Reset() == ATT_BUSY);
    Test_Host_Settle();
    assert(App_Host_Store_Status() == ATT_OK && App_Host_Store_Count(0) == 0);
    assert(memory[128] == 0x55 && memory[255] == 0x55);
    Test_Host_Boot();
    assert(App_Host_Store_Status() == ATT_OK && App_Host_Store_Count(2) == 0);

    puts("PASS: AT24C02 statistics, 60 interrupted commits, reboot, IO failure, UID bounds, explicit reset");
    return 0;
}
