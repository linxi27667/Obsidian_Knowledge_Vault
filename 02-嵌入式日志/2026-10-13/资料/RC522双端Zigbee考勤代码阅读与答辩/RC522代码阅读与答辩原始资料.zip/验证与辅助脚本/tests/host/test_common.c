#include "comm_unicast.h"
#include "comm_broadcast.h"
#include "comm_protocol.h"
#include "device1_uart.h"
#include "hal_console_uart.h"
#include "hal_uart.h"
#include "SampleApp.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

endPointDesc_t SampleApp_epDesc = { SAMPLEAPP_ENDPOINT };
static uint8 afResult, afCalls, lastAfTransaction, receivedCount;
static uint16 lastCluster, receivedSource;
static afAddrType_t lastDestination;
static uint8 lastPayload[80], lastPayloadLength;
static uint8 serialInput[160], serialOutput[600];
static uint16 serialInputLength, serialInputIndex, serialOutputLength;
static uint8 serialOpenCount, commandCount;
static char commandName[20];

afStatus_t AF_DataRequest(afAddrType_t *destination, endPointDesc_t *endpoint,
                         uint16 cluster, uint8 len, uint8 *data,
                         uint8 *transaction, uint8 options, uint8 radius)
{
    assert(endpoint->endPoint == SAMPLEAPP_ENDPOINT);
    assert(options == AF_DISCV_ROUTE && radius == AF_DEFAULT_RADIUS);
    ++afCalls;
    lastDestination = *destination;
    lastCluster = cluster;
    lastAfTransaction = (*transaction)++;
    memcpy(lastPayload, data, len);
    lastPayloadLength = len;
    return afResult;
}

uint8 osal_set_event(uint8 task, uint16 event)
{
    assert(task == 1 && event == 2);
    return 0;
}

void HalUARTOpen(uint8 port, halUARTCfg_t *cfg)
{
    assert(port == 0 && cfg->baudRate == 38400 && !cfg->flowControl);
    ++serialOpenCount;
}

uint16 HalUARTRead(uint8 port, uint8 *data, uint16 len)
{
    assert(port == 0 && len == 1);
    if (serialInputIndex == serialInputLength)
    {
        return 0;
    }
    *data = serialInput[serialInputIndex++];
    return 1;
}

uint16 HalUARTWrite(uint8 port, uint8 *data, uint16 len)
{
    assert(port == 0 && serialOutputLength + len <= sizeof(serialOutput));
    memcpy(serialOutput + serialOutputLength, data, len);
    serialOutputLength += len;
    return len;
}

uint16 Hal_UART_RxBufLen(uint8 port)
{
    assert(port == 0);
    return serialInputLength - serialInputIndex;
}

static void receive(uint16 source, uint8 *data, uint8 len)
{
    ++receivedCount;
    receivedSource = source;
    memcpy(lastPayload, data, len);
    lastPayloadLength = len;
}

static void command(uart_cmd_t *cmd)
{
    ++commandCount;
    assert(strlen(cmd->arguments[0]) < sizeof(commandName));
    strcpy(commandName, cmd->arguments[0]);
}

static void serial_line(char *line)
{
    assert(Device1_UART_ProcessCMD((uint8 *)line, (uint8)strlen(line)));
}

static void feed(const char *text)
{
    serialInputLength = (uint16)strlen(text);
    assert(serialInputLength <= sizeof(serialInput));
    memcpy(serialInput, text, serialInputLength);
    serialInputIndex = 0;
    while (serialInputIndex < serialInputLength)
    {
        Hal_Uart_Process_Rx();
    }
}

static void protocol_test(void)
{
    static const uint8 expected[] =
    {
        0xA7, 2, ATT_TIME, 6, 0x34, 0x12, 0xCD, 0xAB,
        26, 10, 5, 12, 34, 56, 0xC3, 0xF2
    };
    uint8 payload[52] = {26, 10, 5, 12, 34, 56};
    uint8 raw[62];
    uint8 len, i;
    comm_frame_t frame;

    assert(Comm_Protocol_CalcChecksum((const uint8 *)"123456789", 9) == 0x29B1);
    len = Comm_Protocol_PackFrame(raw, sizeof(raw), ATT_TIME, 0x1234, 0xABCD, payload, 6);
    assert(len == sizeof(expected) && memcmp(raw, expected, len) == 0);
    assert(Comm_Protocol_UnpackFrame(&frame, raw, len) == COMM_OK);
    assert(frame.opcode == ATT_TIME && frame.data_len == 6);
    assert(frame.session == 0x1234 && frame.transaction == 0xABCD);
    assert(frame.data == raw + 8 && memcmp(frame.data, payload, 6) == 0);
    for (i = 0; i < len; ++i)
    {
        raw[i] ^= 1;
        assert(Comm_Protocol_UnpackFrame(&frame, raw, len) != COMM_OK);
        raw[i] ^= 1;
        assert(Comm_Protocol_UnpackFrame(&frame, raw, i) != COMM_OK);
    }
    assert(Comm_Protocol_UnpackFrame(NULL, raw, len) == COMM_ERR_PARAM);
    assert(Comm_Protocol_ValidateFrame(NULL, len) == COMM_ERR_PARAM);
    assert(Comm_Protocol_PackFrame(raw, len - 1, ATT_TIME, 1, 2, payload, 6) == 0);
    assert(Comm_Protocol_PackFrame(NULL, 62, ATT_TIME, 1, 2, payload, 6) == 0);
    assert(Comm_Protocol_PackFrame(raw, 62, ATT_TIME, 1, 2, NULL, 1) == 0);
    assert(Comm_Protocol_PackFrame(raw, 62, ATT_TIME, 1, 2, payload, 53) == 0);
    assert(Comm_Protocol_PackFrame(raw, 62, ATT_SCAN, 1, 2, payload, 52) == 62);
    assert(Comm_Protocol_UnpackFrame(&frame, raw, 62) == COMM_OK);
    assert(Comm_Protocol_PackFrame(raw, 62, ATT_HELLO, 1, 2, NULL, 0) == 10);
    assert(Comm_Protocol_UnpackFrame(&frame, raw, 10) == COMM_OK);
}

static void transport_test(void)
{
    uint8 data[] = { 1, 2, 3 };
    afIncomingMSGPacket_t packet;

    Comm_Unicast_Init(1);
    assert(Comm_Unicast_Send(0x1234, NULL, 3) == COMM_ERR_PARAM);
    assert(Comm_Unicast_Send(0x1234, data, 0) == COMM_ERR_PARAM);
    assert(afCalls == 0);
    assert(Comm_Unicast_Send(0x1234, data, 3) == COMM_OK);
    assert(lastDestination.addrMode == Addr16Bit);
    assert(lastDestination.addr.shortAddr == 0x1234 && lastDestination.endPoint == 20);
    assert(lastCluster == SAMPLEAPP_CLUSTERID_UNICAST && lastAfTransaction == 0);
    afResult = 1;
    assert(Comm_Unicast_Send(0x5678, data, 3) == COMM_ERR_FAIL);
    assert(lastAfTransaction == 1 && lastDestination.addr.shortAddr == 0x5678);
    afResult = 0;

    packet.srcAddr.addr.shortAddr = 0x4567;
    packet.cmd.Data = data;
    packet.cmd.DataLength = 3;
    Comm_Unicast_ProcessMSG(&packet);
    assert(receivedCount == 0);
    Comm_Unicast_RegisterCallback(receive);
    Comm_Unicast_ProcessMSG(NULL);
    Comm_Unicast_ProcessMSG(&packet);
    assert(receivedCount == 1 && receivedSource == 0x4567);
    assert(lastPayloadLength == 3 && memcmp(lastPayload, data, 3) == 0);
    Comm_Unicast_RegisterCallback(NULL);
    Comm_Unicast_ProcessMSG(&packet);
    assert(receivedCount == 1);

    Comm_Broadcast_Init(1);
    assert(Comm_Broadcast_Send(NULL, 3) == COMM_ERR_PARAM);
    assert(Comm_Broadcast_Send(data, 0) == COMM_ERR_PARAM);
    assert(Comm_Broadcast_Send(data, 3) == COMM_OK);
    assert(lastDestination.addrMode == AddrBroadcast && lastDestination.addr.shortAddr == 0xFFFF);
    assert(lastCluster == SAMPLEAPP_CLUSTERID_BROADCAST && lastAfTransaction == 0);
    afResult = 1;
    assert(Comm_Broadcast_Send(data, 3) == COMM_ERR_FAIL);
    Comm_Broadcast_RegisterCallback(receive);
    Comm_Broadcast_ProcessMSG(NULL);
    Comm_Broadcast_ProcessMSG(&packet);
    assert(receivedCount == 2 && receivedSource == 0x4567);
}

static void serial_test(void)
{
    uint8 exact[] = { '#', 'T', 'I', 'M', 'E' };
    uint8 binary[] = { 'A', 0, 'B' };
    char manyArguments[] = "#DB SET 0 202612345678 Alice Extra";
    char identity[] = "prefix#DB REG:202612345678:Alice\r\n";
    char overflow[130];
    uart_cmd_t parsed;

    assert(Device1_UART_ParseCMD(exact, sizeof(exact), &parsed));
    assert(parsed.cmd_type == UART_CMD_RTC && parsed.argument_count == 1);
    assert(memcmp(exact, "#TIME", 5) == 0);
    assert(Device1_UART_ParseCMD((uint8 *)identity, (uint8)strlen(identity), &parsed));
    assert(parsed.cmd_type == UART_CMD_REGISTER && parsed.argument_count == 3);
    assert(strcmp(parsed.arguments[1], "202612345678") == 0 && strcmp(parsed.arguments[2], "Alice") == 0);
    assert(!Device1_UART_ParseCMD((uint8 *)manyArguments, (uint8)strlen(manyArguments), &parsed));
    Hal_Uart_Init(1, 2);
    Device1_UART_Init(1);
    Device1_UART_RegisterCallback(command);
    Hal_Uart_Set_Handler(serial_line);
    assert(serialOpenCount == 1);
    feed("#DB RE");
    feed("G\r\n#TIME\n");
    assert(commandCount == 2 && strcmp(commandName, "#TIME") == 0);
    memset(overflow, 'X', 120);
    strcpy(overflow + 120, "\n#DB UID\n");
    feed(overflow);
    assert(commandCount == 3 && strcmp(commandName, "#DB") == 0);
    while (Hal_Uart_Free() < 255)
    {
        Hal_Uart_Flush();
    }
    serialOutputLength = 0;
    Device1_UART_SendData(binary, sizeof(binary));
    Device1_UART_SendString((uint8 *)"OK", 2);
    Hal_Uart_Flush();
    assert(serialOutputLength == 5 && memcmp(serialOutput, binary, 3) == 0);
    assert(memcmp(serialOutput + 3, "OK", 2) == 0);
}

static void grouped_commands_test(void)
{
    static const struct
    {
        const char *text;
        uart_cmd_type_t type;
        uint8 count;
    } cases[] =
    {
        {"#HELP", UART_CMD_HELP, 1},
        {"#HELP DB", UART_CMD_HELP, 2},
        {"#HELP TIME", UART_CMD_HELP, 2},
        {"#STATUS", UART_CMD_STATUS, 1},
        {"#LIST", UART_CMD_LIST, 1},
        {"#LIST 7", UART_CMD_GET, 2},
        {"#LOG", UART_CMD_LOG, 1},
        {"#LOG 9", UART_CMD_LOG, 2},
        {"#LOG CSV", UART_CMD_EXPORT, 1},
        {"#TIME", UART_CMD_RTC, 1},
        {"#TIME 261008123456", UART_CMD_TIME_SET, 2},
        {"#TIME SYNC", UART_CMD_SYNC, 1},
        {"#DB STATUS", UART_CMD_DATABASE, 2},
        {"#DB INIT CONFIRM", UART_CMD_DATABASE, 3},
        {"#DB SET 7 202612345678 Alice", UART_CMD_USER, 5},
        {"#DB DEL 7", UART_CMD_USER, 3},
        {"#DB FIND 01020304", UART_CMD_FIND, 2},
        {"#DB REG", UART_CMD_REGISTER, 1},
        {"#DB:REG:202612345678:Alice", UART_CMD_REGISTER, 3},
        {"#DB UNREG", UART_CMD_UNREGISTER, 1},
        {"#DB CANCEL", UART_CMD_CANCEL, 1},
        {"#DB UID", UART_CMD_UID, 1},
        {"#DB BEEP", UART_CMD_BEEP, 1},
        {"#DB STATS", UART_CMD_STATS, 1},
        {"#DB STATS RESET CONFIRM", UART_CMD_STATS, 3},
        {"#RTC", UART_CMD_UNKNOWN, 1},
        {"#REG", UART_CMD_UNKNOWN, 1},
        {"#GET 0", UART_CMD_UNKNOWN, 2},
        {"#TIME=261008123456", UART_CMD_UNKNOWN, 1},
        {"#DB BAD", UART_CMD_UNKNOWN, 2}
    };
    uart_cmd_t parsed;
    unsigned int index;

    for (index = 0; index < sizeof(cases) / sizeof(cases[0]); ++index)
    {
        assert(Device1_UART_ParseCMD((uint8 *)cases[index].text,
                                    (uint8)strlen(cases[index].text), &parsed));
        assert(parsed.cmd_type == cases[index].type);
        assert(parsed.argument_count == cases[index].count);
    }
    assert(!Device1_UART_ParseCMD((uint8 *)"#DB SET 0 202612345678 Alice Extra", 33, &parsed));
    puts("PASS: six public command groups, maintenance actions, argument normalization and retired command rejection");
}

int main(void)
{
    protocol_test();
    transport_test();
    serial_test();
    grouped_commands_test();
    puts("PASS: actual Common AF routing/callbacks, ATT2 byte compatibility/CRC/bounds, old UART parser and HAL integration");
    return 0;
}
