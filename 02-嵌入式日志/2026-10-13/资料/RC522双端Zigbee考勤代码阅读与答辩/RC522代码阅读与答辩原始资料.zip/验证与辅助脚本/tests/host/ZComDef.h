#ifndef HOST_ZCOMDEF_H
#define HOST_ZCOMDEF_H
#include <stdint.h>
#include <stddef.h>
typedef uint8_t uint8;
typedef uint16_t uint16;
typedef uint16_t UINT16;
typedef uint32_t uint32;
typedef uint8_t bool;
#define TRUE 1
#define FALSE 0
#endif
