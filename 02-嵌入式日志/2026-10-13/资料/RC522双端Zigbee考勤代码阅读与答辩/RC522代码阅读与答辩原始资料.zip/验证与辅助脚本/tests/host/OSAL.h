#include "ZComDef.h"
#include <string.h>
#define osal_memcpy memcpy
#define osal_memset memset
uint32 osal_GetSystemClock(void);
uint8 osal_set_event(uint8 task,uint16 event);
