#ifndef TEST_HAL_UART_H
#define TEST_HAL_UART_H
#include "ZComDef.h"
#define HAL_UART_BR_38400 38400
typedef struct {uint8 configured;uint16 baudRate;uint8 flowControl;struct {uint16 maxBufSize;} rx,tx;uint8 idleTimeout,intEnable;void (*callBackFunc)(uint8,uint8);} halUARTCfg_t;
void HalUARTOpen(uint8 port,halUARTCfg_t *cfg);
uint16 HalUARTWrite(uint8 port,uint8 *p,uint16 len);
uint16 HalUARTRead(uint8 port,uint8 *p,uint16 len);
uint16 Hal_UART_RxBufLen(uint8 port);
#endif
