#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "hal_rc522.h"
uint8 mock_cs, mock_clk, mock_mosi, P1SEL, P1DIR;
static uint8 regs[64], tx[64], rx[64], txlen, rxlen, rxpos;
static uint8 bitpos, address, incoming, outgoing;
static uint8 uidSize = 4, noCard, badBcc, badCrc, stuckReset;
static unsigned int transfers;
static uint16 ReferenceCRC(const uint8 *p, uint8 len)
{
  uint16 crc = 0x6363;
  uint8 i;
  while (len--)
  {
    crc ^= *p++;
    for (i = 0; i < 8; ++i) crc = (crc & 1) ? (crc >> 1)^0x8408 : crc >> 1;
  }
  return crc;
}
static void Respond(void)
{
  uint8 level, i, base;
  uint16 crc;
  rxlen = rxpos = 0;
  if (noCard || tx[0] == 0x50) { regs[4] = 1; return; }
  regs[4] = 0x20; regs[6] = regs[0x0C] = 0;
  if (tx[0] == 0x52) { rx[0] = 4; rx[1] = 0; rxlen = 2; return; }
  assert(tx[0] == 0x93 || tx[0] == 0x95 || tx[0] == 0x97);
  level = (tx[0]-0x93)/2;
  if (tx[1] == 0x20)
  {
    base = level*3;
    if (uidSize > base+4)
    { rx[0] = 0x88; for (i = 1; i < 4; ++i) rx[i] = base+i; }
    else for (i = 0; i < 4; ++i) rx[i] = base+i+1;
    rx[4] = rx[0]^rx[1]^rx[2]^rx[3];
    if (badBcc) rx[4] ^= 1;
    rxlen = 5;
  }
  else
  {
    assert(txlen == 9 && tx[1] == 0x70);
    crc = ReferenceCRC(tx, 7);
    assert(tx[7] == (uint8)crc && tx[8] == (uint8)(crc >> 8));
    rx[0] = uidSize > level*3+4 ? 4 : 8;
    crc = ReferenceCRC(rx, 1); rx[1] = (uint8)crc; rx[2] = crc >> 8;
    if (badCrc) rx[2] ^= 1;
    rxlen = 3;
  }
}
static uint8 ReadReg(uint8 reg)
{
  if (reg == 9) { assert(rxpos < rxlen); return rx[rxpos++]; }
  if (reg == 10) return rxlen;
  return regs[reg];
}
static void WriteReg(uint8 reg, uint8 value)
{
  if (reg == 9) { tx[txlen++] = value; return; }
  if (reg == 10 && (value & 0x80)) { txlen = 0; return; }
  if (reg == 4) { regs[4] = 0; return; }
  if (reg == 1 && value == 15) { regs[1] = stuckReset ? 0x1F : 0; return; }
  regs[reg] = value;
  if (reg == 13 && (value & 0x80)) Respond();
}
uint8 Mock_Miso(void)
{
  uint8 result = 0;
  assert(mock_cs == 0 && mock_clk == 1);
  incoming = (incoming << 1) | mock_mosi;
  if (bitpos >= 8) result = (outgoing >> (15-bitpos)) & 1;
  ++bitpos;
  if (bitpos == 8)
  { address = incoming; incoming = 0; outgoing = (address & 0x80) ? ReadReg((address & 0x7E)>>1) : 0; }
  if (bitpos == 16)
  {
    if (!(address & 0x80)) WriteReg((address & 0x7E)>>1, incoming);
    incoming = bitpos = 0; ++transfers;
  }
  return result;
}
int main(void)
{
  uint8 buf[12], len, i;
  unsigned int before;
  regs[0x37] = 0x92;
  assert(Hal_Rc522_Init());
  for (uidSize = 4; uidSize <= 10; uidSize += 3)
  {
    memset(buf, 0xAA, sizeof(buf));
    assert(Hal_Rc522_Read_Uid(buf+1, &len) && len == uidSize);
    assert(buf[0] == 0xAA && buf[11] == 0xAA);
    for (i = 0; i < len; ++i) assert(buf[i+1] == i+1);
  }
  uidSize = 4; badBcc = 1;
  assert(!Hal_Rc522_Read_Uid(buf, &len) && len == 0 && g_rc522_last_error == RC522_PROTOCOL_ERROR);
  badBcc = 0; badCrc = 1;
  assert(!Hal_Rc522_Read_Uid(buf, &len) && len == 0);
  badCrc = 0; noCard = 1; before = transfers;
  assert(!Hal_Rc522_Read_Uid(buf, &len) && g_rc522_last_error == RC522_NO_RESPONSE);
  assert(transfers-before < 50);
  stuckReset = 1; before = transfers;
  assert(!Hal_Rc522_Reset() && transfers-before <= 401);
  regs[0x37] = 0xFF;
  assert(!Hal_Rc522_Init() && g_rc522_last_error == RC522_NOT_READY);
  puts("PASS: RC522 SPI register framing, UID 4/7/10, BCC/CRC, absent card, reset timeout");
  return 0;
}
