#include <assert.h>
#include <stdio.h>
#include "hal_buzzer.h"
#include "hal_board_key.h"
#include "hal_key.h"
uint8 Test_Buzzer_Pin = 1;
uint8 P0SEL = 255;
uint8 P0DIR;
static uint8 rawKey;
static uint8 timerFailure;
static uint8 stopped;
static uint8 cleared;
static uint16 duration;
uint8 HalKeyRead(void)
{
    return rawKey;
}
uint8 osal_start_timerEx(uint8 task,uint16 event,uint32 ms)
{
    assert(task==1 && event==0x200);
    duration=ms;
    return timerFailure;
}
uint8 osal_stop_timerEx(uint8 task,uint16 event)
{
    assert(task==1 && event==0x200);
    ++stopped;
    return 0;
}
uint8 osal_clear_event(uint8 task,uint16 event)
{
    assert(task==1 && event==0x200);
    ++cleared;
    return 0;
}
int main(void)
{
    uint8 index;
    Hal_Buzzer_Init();
    assert(!Test_Buzzer_Pin && !(P0SEL&1) && (P0DIR&1));
    Hal_Buzzer_Beep(50);
    assert(!Test_Buzzer_Pin && !duration);
    Hal_Buzzer_Bind(1,0x200);
    Hal_Buzzer_Beep(60);
    assert(Test_Buzzer_Pin && duration==60 && stopped==1 && cleared==1);
    Hal_Buzzer_Beep(80);
    assert(Test_Buzzer_Pin && duration==80 && stopped==2 && cleared==2);
    Hal_Buzzer_Off();
    assert(!Test_Buzzer_Pin);
    timerFailure=1;
    Hal_Buzzer_Beep(180);
    assert(!Test_Buzzer_Pin);
    timerFailure=0;
    Hal_Buzzer_Beep(0);
    assert(!Test_Buzzer_Pin);
    Hal_Key_Init();
    rawKey=HAL_KEY_SW_6;
    assert(!Hal_Key_Poll());
    rawKey=0;
    assert(!Hal_Key_Poll());
    rawKey=HAL_KEY_SW_6;
    assert(!Hal_Key_Poll() && !Hal_Key_Poll());
    assert(Hal_Key_Poll()==KEY0_PRESS);
    for(index=0;index<50;++index)
    {
        assert(!Hal_Key_Poll());
    }
    rawKey=0;
    for(index=0;index<3;++index)
    {
        assert(!Hal_Key_Poll());
    }
    rawKey=HAL_KEY_SW_6|HAL_KEY_SW_7;
    assert(!Hal_Key_Poll() && !Hal_Key_Poll());
    assert(Hal_Key_Poll()==(KEY0_PRESS|KEY1_PRESS));
    puts("PASS: split buzzer safe GPIO, timer failure/rearm/stop; SDK key sampling, 30ms debounce, held key and both-key edges");
    return 0;
}
