#include "ZComDef.h"
extern uint8 Test_Buzzer_Pin;
extern uint8 P0SEL;
extern uint8 P0DIR;
#define BOARD_BUZZER_PIN Test_Buzzer_Pin
#define BOARD_BUZZER_MASK 1
