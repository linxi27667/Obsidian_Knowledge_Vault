#include "ZComDef.h"
#define HAL_KEY_SW_6 0x40
#define HAL_KEY_SW_7 0x80
uint8 HalKeyRead(void);
