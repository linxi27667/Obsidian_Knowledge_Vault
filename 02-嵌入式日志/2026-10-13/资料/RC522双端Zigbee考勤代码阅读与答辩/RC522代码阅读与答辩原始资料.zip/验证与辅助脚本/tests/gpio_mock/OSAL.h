#include "ZComDef.h"
#define SUCCESS 0
uint8 osal_start_timerEx(uint8 task,uint16 event,uint32 ms);
uint8 osal_stop_timerEx(uint8 task,uint16 event);
uint8 osal_clear_event(uint8 task,uint16 event);
