#include "ZComDef.h"
#define HAL_LED_1 1
#define HAL_LED_MODE_OFF 0
#define HAL_LED_MODE_ON 1
#define HAL_LED_MODE_TOGGLE 4
uint8 HalLedSet(uint8 id,uint8 mode);
