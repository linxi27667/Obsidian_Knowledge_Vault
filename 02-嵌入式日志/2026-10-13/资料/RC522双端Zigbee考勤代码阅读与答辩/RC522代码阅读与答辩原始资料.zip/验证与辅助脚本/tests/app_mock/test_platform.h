#ifndef TEST_PLATFORM_H
#define TEST_PLATFORM_H
#include "ZComDef.h"
#include <string.h>
#define osal_memcpy memcpy
#define osal_memset memset
#define osal_strlen strlen
#define SYS_EVENT_MSG 0x8000
#define ZDO_STATE_CHANGE 1
#define AF_INCOMING_MSG_CMD 2
#define KEY_CHANGE 3
#define ZDO_CB_MSG 4
#define Device_annce 0x0013
#define SAMPLEAPP_INIT_EVT 0x0001
#define SAMPLEAPP_KEY_SCAN_EVT 0x0002
#define SAMPLEAPP_UART_RX_EVT 0x0004
#define SAMPLEAPP_DATABASE_EVT 0x0008
#define SAMPLEAPP_CONSOLE_EVT 0x0010
#define SAMPLEAPP_OLED_EVT 0x0020
#define SAMPLEAPP_CARD_EVT 0x0040
#define SAMPLEAPP_SECOND_EVT 0x0080
#define SAMPLEAPP_RETRY_EVT 0x0100
#define SAMPLEAPP_BUZZER_EVT 0x0200
#define SAMPLEAPP_INIT_DELAY 1000
#define SAMPLEAPP_INIT_STEP_DELAY 100
#define SAMPLEAPP_KEY_SCAN_INTERVAL 10
#define SAMPLEAPP_CONSOLE_INTERVAL 10
#define SAMPLEAPP_OLED_INTERVAL 10
#define SAMPLEAPP_DATABASE_INTERVAL 10
#define SAMPLEAPP_CARD_INTERVAL 200
#define SAMPLEAPP_SECOND_INTERVAL 1000
#define SAMPLEAPP_RETRY_INTERVAL 2000
#define SAMPLEAPP_RETRY_LIMIT 4
#define SAMPLEAPP_PEER_TIMEOUT_SECONDS 15
#define SAMPLEAPP_MODE_TIMEOUT_SECONDS 30
#define SAMPLEAPP_HELLO_INTERVAL_SECONDS 5
#define SAMPLEAPP_TIME_SYNC_INTERVAL_SECONDS 60
#define SAMPLEAPP_MAX_CLUSTERS 4
#define SAMPLEAPP_PERIODIC_CLUSTERID 1
#define SAMPLEAPP_FLASH_CLUSTERID 2
#define SAMPLEAPP_CLUSTERID_UNICAST 3
#define SAMPLEAPP_CLUSTERID_BROADCAST 4
#define SAMPLEAPP_ENDPOINT 20
#define SAMPLEAPP_PROFID 0x0F08
#define SAMPLEAPP_DEVICEID 0x0001
#define SAMPLEAPP_DEVICE_VERSION 0
#define SAMPLEAPP_FLAGS 0
#define noLatencyReqs 0
typedef uint16 cId_t;
typedef enum {DEV_INIT=0,DEV_END_DEVICE=6,DEV_ZB_COORD=9} devStates_t;
typedef struct {uint8 endPoint;uint16 profile,device;uint8 version,flags,inCount;cId_t *in;uint8 outCount;cId_t *out;} SimpleDescriptionFormat_t;
typedef struct {uint8 endPoint,*task_id;SimpleDescriptionFormat_t *simpleDesc;uint8 latencyReq;} endPointDesc_t;
typedef struct {uint8 unused;} afAddrType_t;
typedef struct {struct {uint8 event,status;} hdr;uint16 clusterId;} afIncomingMSGPacket_t;
typedef struct {struct {uint8 event,status;} hdr;uint16 clusterID;} zdoIncomingMsg_t;
typedef struct {struct {uint8 event,status;} hdr;uint8 state,keys;} keyChange_t;
extern struct TestNib {uint16 nwkPanId;uint8 nwkLogicalChannel;} _NIB;
uint32 osal_GetSystemClock(void);
uint16 osal_rand(void);
uint8 osal_start_reload_timer(uint8 task,uint16 evt,uint32 delay);
uint8 osal_start_timerEx(uint8 task,uint16 evt,uint32 delay);
uint8 osal_stop_timerEx(uint8 task,uint16 evt);
uint8 *osal_msg_receive(uint8 task);
void osal_msg_deallocate(uint8 *msg);
void osal_set_event(uint8 task,uint16 event);
uint8 osal_clear_event(uint8 task,uint16 event);
void afRegister(endPointDesc_t *ep);
uint8 ZDO_RegisterForZDOMsg(uint8 task,uint16 cluster);
uint16 NLME_GetShortAddr(void);
void SampleApp_Init(uint8 task);
uint16 SampleApp_ProcessEvent(uint8 task,uint16 events);
#endif
