#include "test_platform.h"
#include "comm_protocol.h"
#include "app_database.h"
#include "app_ui.h"
#include "hal_console_uart.h"
#include "hal_buzzer.h"
#include "hal_board_key.h"
#include "hal_led.h"
#include "hal_rc522.h"
#include "hal_i2c.h"
#include "comm_unicast.h"
#include "comm_broadcast.h"
#include "device1_uart.h"
#ifdef APP_TEST_REAL_UART
#include "hal_uart.h"
#endif
#include <assert.h>
#include <stdio.h>
#include <stdarg.h>
struct TestNib _NIB={0x2B2B,25};
static uint32 ticks;
typedef struct
{
  uint16 event;
  uint32 remaining;
  uint32 period;
  uint8 reload;
  uint8 active;
} TestTimer;
static TestTimer timers[16];
#ifndef APP_TEST_REAL_UART
static void (*handler)(char *);
#endif
static Comm_Unicast_RecvCallback receiver;
static uint8 packet[62],packetLen,keys,cardOn,uid=1;
static uint8 lastReply[62],lastReplyLength;
static uint8 uiReady,deallocations,broadcastMessages;
static uint8 eeprom[1024];
static uint16 destination;
static afIncomingMSGPacket_t message;
static uint8 hasMessage;
static rtc_time_t clockTime={0,0,12,3,23,9,26};
static uint8 rtcInvalid=1, rtcSeedCalls;
static char output[20000],lastTitle[40];static size_t used;
#ifndef APP_TEST_REAL_UART
uint16 g_uart_dropped;
#endif
uint8 g_rc522_version=0x92,g_rc522_last_error;
uint32 osal_GetSystemClock(void){return ticks;}
uint16 osal_rand(void){return 1234;}
static uint8 start_timer(uint16 event, uint32 delay, uint8 reload)
{
  uint8 i;
  uint8 freeSlot = 255;

  for (i = 0; i < 16; ++i)
  {
    if (timers[i].active && timers[i].event == event)
    {
      freeSlot = i;
      break;
    }
    if (!timers[i].active && freeSlot == 255)
    {
      freeSlot = i;
    }
  }

  assert(freeSlot != 255);
  timers[freeSlot].event = event;
  timers[freeSlot].remaining = delay;
  timers[freeSlot].period = delay;
  timers[freeSlot].reload = reload;
  timers[freeSlot].active = 1;
  return 0;
}
uint8 osal_start_reload_timer(uint8 t,uint16 e,uint32 d){(void)t;return start_timer(e,d,1);}
uint8 osal_start_timerEx(uint8 t,uint16 e,uint32 d){(void)t;return start_timer(e,d,0);}
uint8 osal_stop_timerEx(uint8 t,uint16 e)
{
  uint8 i;
  (void)t;
  for (i = 0; i < 16; ++i)
  {
    if (timers[i].active && timers[i].event == e)
    {
      timers[i].active = 0;
    }
  }
  return 0;
}
uint8 *osal_msg_receive(uint8 t){(void)t;if(hasMessage){hasMessage=0;return (uint8 *)&message;}return NULL;}
void osal_msg_deallocate(uint8 *p){(void)p;++deallocations;}
void osal_set_event(uint8 task,uint16 event){(void)task;(void)event;}
uint8 osal_clear_event(uint8 task,uint16 event){(void)task;(void)event;return 0;}
void afRegister(endPointDesc_t *p){assert(p->endPoint==20);}
uint8 ZDO_RegisterForZDOMsg(uint8 task,uint16 cluster){assert(task==1&&cluster==Device_annce);return 0;}
uint16 NLME_GetShortAddr(void){return 0;}
void Comm_Unicast_Init(uint8 t){(void)t;}
void Comm_Unicast_RegisterCallback(Comm_Unicast_RecvCallback r){receiver=r;}
void Comm_Unicast_ProcessMSG(afIncomingMSGPacket_t *p){(void)p;}
uint8 Comm_Unicast_Send(uint16 d,uint8 *p,uint8 n){assert(Comm_Protocol_ValidateFrame(p,n)==COMM_OK);destination=d;memcpy(packet,p,n);packetLen=n;if(p[2]&ATT_REPLY){memcpy(lastReply,p,n);lastReplyLength=n;}return 0;}
void Comm_Broadcast_Init(uint8 t){(void)t;}
void Comm_Broadcast_ProcessMSG(afIncomingMSGPacket_t *p){(void)p;++broadcastMessages;}
#ifndef APP_TEST_REAL_UART
void Hal_Uart_Write(const uint8 *data,uint8 len){uint8 i;for(i=0;i<len;++i){char text[2]={(char)data[i],0};Hal_Uart_Print(text);}}
void Hal_Uart_Init(uint8 t,uint16 e){(void)t;(void)e;}
void Hal_Uart_Set_Handler(void (*h)(char *)){handler=h;}
void Hal_Uart_Print(char *s){size_t n=strlen(s);assert(used+n<sizeof(output));memcpy(output+used,s,n+1);used+=n;}
void Hal_Uart_Printf(char *fmt,...){char b[256];va_list a;va_start(a,fmt);vsnprintf(b,sizeof(b),fmt,a);va_end(a);Hal_Uart_Print(b);}
uint8 Hal_Uart_Free(void){return 255;}
void Hal_Uart_Flush(void){}
uint8 Hal_Uart_Process_Rx(void){return 0;}
#else
static char serialInput[100];
static uint8 serialInputLength,serialInputIndex;
void HalUARTOpen(uint8 port,halUARTCfg_t *cfg)
{
  assert(port==0 && cfg->baudRate==38400 && !cfg->flowControl);
}
uint16 HalUARTWrite(uint8 port,uint8 *data,uint16 len)
{
  assert(port==0 && len<=32 && used+len<sizeof(output));
  memcpy(output+used,data,len);used+=len;output[used]=0;
  return len;
}
uint16 HalUARTRead(uint8 port,uint8 *data,uint16 len)
{
  assert(port==0 && len==1);
  if(serialInputIndex==serialInputLength){return 0;}
  *data=(uint8)serialInput[serialInputIndex++];return 1;
}
uint16 Hal_UART_RxBufLen(uint8 port)
{
  assert(port==0);return serialInputLength-serialInputIndex;
}
static void drain_uart(void)
{
  uint8 i;
  for(i=0;i<8;++i){Hal_Uart_Flush();}
}
#endif
uint8 HalLedSet(uint8 id,uint8 mode){assert(id==HAL_LED_1);(void)mode;return 0;}
void Hal_Key_Init(void){}
uint8 Hal_Key_Poll(void){uint8 v=keys;keys=0;return v;}
void Hal_Buzzer_Init(void){}
void Hal_Buzzer_Bind(uint8 t,uint16 e){(void)t;(void)e;}
void Hal_Buzzer_Beep(uint16 ms){assert(ms<=250);}
void Hal_Buzzer_Off(void){}
uint8 Hal_I2c_Init(void){return 0;}
uint8 Hal_I2c_Write(uint8 a,const uint8 *p,uint8 n){(void)a;(void)p;(void)n;return 0;}
uint8 Hal_I2c_Read_Reg(uint8 a,uint8 r,uint8 *p,uint8 n){memcpy(p,eeprom+(a-0x50)*256+r,n);return 0;}
uint8 Hal_I2c_Write_Reg(uint8 a,uint8 r,const uint8 *p,uint8 n){memcpy(eeprom+(a-0x50)*256+r,p,n);return 0;}
uint8 Hal_Rtc_Init(uint8 *f){*f=0;return 0;}
uint8 Hal_Rtc_Read_Time(rtc_time_t *t){if(rtcInvalid)return RTC_TIME_INVALID;*t=clockTime;return 0;}
uint8 Hal_Rtc_Set_Time(const rtc_time_t *t){clockTime=*t;rtcInvalid=0;return 0;}
uint8 Hal_Rtc_Seed_Build_Time(rtc_time_t *t){++rtcSeedCalls;rtcInvalid=0;*t=clockTime;return 0;}
uint8 Hal_Rc522_Init(void){return 1;}
bool Hal_Rc522_Read_Uid(uint8 p[RC522_UID_MAX],uint8 *n){if(!cardOn){g_rc522_last_error=RC522_NO_RESPONSE;return 0;}memset(p,0,10);p[0]=uid;*n=4;return 1;}
void App_Ui_Init(uint8 r){(void)r;uiReady=1;}
void App_Ui_Time(const rtc_time_t *t,uint8 s){assert(uiReady);(void)t;(void)s;}
void App_Ui_Status(uint8 n,uint8 p,uint8 d,uint8 u,uint8 m,uint8 s){assert(uiReady);(void)n;(void)p;(void)d;(void)u;(void)m;(void)s;}
void App_Ui_Message(const char *a,const char *b){(void)b;strcpy(lastTitle,a);}
void App_Ui_Second(void){assert(uiReady);}
void App_Ui_Tick(void){assert(uiReady);}
uint8 App_Ui_Error(void){return 0;}
static uint8 run_events(uint16 events)
{
  uint8 passes = 0;
  while (events != 0 && passes < 16)
  {
    events = SampleApp_ProcessEvent(1, events);
    ++passes;
  }
  assert(events == 0);
  return passes;
}
static void tick(int count)
{
  while (count--)
  {
    uint8 i;
    uint16 events = 0;

    ticks += 10;
    for (i = 0; i < 16; ++i)
    {
      if (!timers[i].active)
      {
        continue;
      }
      if (timers[i].remaining <= 10)
      {
        events |= timers[i].event;
        if (timers[i].reload)
        {
          timers[i].remaining = timers[i].period;
        }
        else
        {
          timers[i].active = 0;
        }
      }
      else
      {
        timers[i].remaining -= 10;
      }
    }

    run_events(events);
  }
}
static void command(const char *s)
{
#ifdef APP_TEST_REAL_UART
  drain_uart();
  assert(strlen(s)+1<sizeof(serialInput));
  strcpy(serialInput,s);strcat(serialInput,"\n");
  serialInputLength=(uint8)strlen(serialInput);serialInputIndex=0;
  while(serialInputIndex<serialInputLength){Hal_Uart_Process_Rx();}
  drain_uart();
#else
  char b[100];
  assert(strlen(s) < sizeof(b));
  strcpy(b, s);
  handler(b);
#endif
}
static void uart_parser_test(void)
{
  char raw[] = " \t#DB:SET:0:202612345678:Alice\r\n";
  char prefixed[] = "old-prefix#HELP\r\n";
  char tooLong[UART_CMD_MAX_LEN + 2];
  uart_cmd_t parsed;

  assert(Device1_UART_ParseCMD((uint8 *)raw, (uint8)strlen(raw), &parsed));
  assert(parsed.cmd_type == UART_CMD_USER);
  assert(parsed.argument_count == 5);
  assert(strcmp(parsed.arguments[0], "#DB") == 0);
  assert(strcmp(parsed.arguments[1], "SET") == 0);
  assert(strcmp(parsed.arguments[2], "0") == 0);
  assert(strcmp(parsed.arguments[3], "202612345678") == 0);
  assert(strcmp(parsed.arguments[4], "Alice") == 0);

  /* 旧解析器会在整行中搜索首个 #，保留此前缀兼容行为。 */
  assert(Device1_UART_ParseCMD((uint8 *)prefixed, (uint8)strlen(prefixed), &parsed));
  assert(parsed.cmd_type == UART_CMD_HELP);
  assert(parsed.argument_count == 1);

  tooLong[0] = '#';
  memset(tooLong + 1, 'A', UART_CMD_MAX_LEN);
  tooLong[UART_CMD_MAX_LEN + 1] = '\0';
  assert(!Device1_UART_ParseCMD((uint8 *)tooLong, UART_CMD_MAX_LEN + 1, &parsed));
}
static void rx(uint16 src,uint8 op,uint16 session,uint16 tx,const uint8 *p,uint8 n)
{
  uint8 f[62];uint8 len=Comm_Protocol_PackFrame(f,sizeof(f),op,session,tx,p,n);
#ifdef APP_TEST_REAL_UART
  drain_uart();
#endif
  receiver(src,f,len);
#ifdef APP_TEST_REAL_UART
  drain_uart();
#endif
}
static void card(uint8 value)
{
#ifdef APP_TEST_REAL_UART
  drain_uart();
#endif
  cardOn=0;SampleApp_ProcessEvent(1,SAMPLEAPP_CARD_EVT);uid=value;cardOn=1;SampleApp_ProcessEvent(1,SAMPLEAPP_CARD_EVT);
#ifdef APP_TEST_REAL_UART
  drain_uart();
#endif
}
static void console_help_test(void)
{
  used=0;output[0]=0;
  command("#HELP");tick(20);
#ifdef APP_TEST_REAL_UART
  drain_uart();
#endif
  assert(strstr(output,"#HELP #STATUS #LIST") && strstr(output,"SAME/BOTH=EXIT"));
  assert(!strstr(output,"#DB SET"));
  used=0;output[0]=0;
  command("#HELP DB");tick(40);
#ifdef APP_TEST_REAL_UART
  drain_uart();
#endif
  assert(strstr(output,"#DB SET") && strstr(output,"INIT CONFIRM"));
  used=0;output[0]=0;
  command("#HELP TIME");tick(15);
#ifdef APP_TEST_REAL_UART
  drain_uart();
#endif
  assert(strstr(output,"YYMMDDhhmmss") && strstr(output,"#TIME SYNC"));
  used=0;output[0]=0;
  command("#STATUS");tick(15);
#ifdef APP_TEST_REAL_UART
  drain_uart();
#endif
  assert(strstr(output,"[STATUS] role=") && strstr(output,"[STATUS] db="));
}

static void console_end_test(void)
{
  uint8 reply[44]={0};
  uint16 request_session,request_transaction;
#ifdef APP_TEST_REAL_UART
  uint16 drops_before=g_uart_dropped;
  uint8 fill_count,index;
  drain_uart();
#ifdef ATTENDANCE_ESP12F
  assert(Hal_Uart_Free()==127);
#else
  assert(Hal_Uart_Free()==255);
#endif
#endif
#ifdef ATT_TERMINAL
  (void)reply;(void)request_session;(void)request_transaction;
  assert(!rtcInvalid);
  command("#TIME SYNC");
  assert(packet[2]==ATT_HELLO && packet[12]==RTC_TIME_INVALID && !rtcInvalid);
#else
  /* 请求在途时暂停状态输出，完整LOG到达后再恢复，覆盖127容量交错。 */
  command("#LOG 0");
  assert(packet[2]==ATT_LOG);
  request_session=Comm_Protocol_ReadUint16(packet+4);
  request_transaction=Comm_Protocol_ReadUint16(packet+6);
  used=0;output[0]=0;
  command("#STATUS");tick(1);
  assert(!strstr(output,"[STATUS]"));
  reply[1]=9;reply[2]=reply[3]=255;
  memset(reply+4,0x99,6);memset(reply+10,255,8);
  reply[18]=reply[19]=255;
  rx(0xABCD,ATT_LOG|ATT_REPLY,request_session,request_transaction,reply,20);
  tick(20);
#ifdef APP_TEST_REAL_UART
  drain_uart();
#endif
  assert(strstr(output,"LOG index=9 seq=65535"));
  assert(strstr(output,"origin=255 gen=65535\r\n"));
  assert(strstr(output,"[STATUS] role=") && strstr(output,"[STATUS] db="));
  command("#TIME SYNC");assert(packet[2]==ATT_TIME && packet[3]==6);
  memset(reply,0,4);
  rx(0xABCD,ATT_TIME|ATT_REPLY,request_session,Comm_Protocol_ReadUint16(packet+6),reply,4);
#endif
#ifdef APP_TEST_REAL_UART
  drain_uart();
  assert(g_uart_dropped==drops_before);
  /* 有发送积压时返回忙；清空后帮助继续输出，不额外分配缓冲。 */
  fill_count=Hal_Uart_Free()-30;
  for(index=0;index<fill_count;++index){Hal_Uart_Write((const uint8 *)"~",1);}
  strcpy(serialInput,"#HELP\n");serialInputLength=6;serialInputIndex=0;
  Hal_Uart_Process_Rx();drain_uart();
  assert(strstr(output,"ERR OUTPUT_BUSY"));
  assert(g_uart_dropped==drops_before);
  used=0;output[0]=0;
  command("#HELP");tick(20);drain_uart();
  assert(strstr(output,"#HELP #STATUS #LIST"));
  assert(g_uart_dropped==drops_before);
  puts("PASS: actual UART capacity, split STATUS/help, query/status interleaving, complete worst-size log, output backpressure and recovery");
#endif
}
int main(void){
#ifdef ATT_TERMINAL
  int i;
#endif
  uint8 p[48]={0};uint16 tx,session;
  uart_parser_test();
  memset(eeprom,255,sizeof(eeprom));SampleApp_Init(1);command("#DB REG");assert(strstr(output,"INITIALIZING"));
  message.hdr.event=ZDO_STATE_CHANGE;
#ifdef ATT_TERMINAL
  message.hdr.status=DEV_END_DEVICE;
#else
  message.hdr.status=DEV_ZB_COORD;
#endif
  hasMessage=1;
  assert(run_events(SYS_EVENT_MSG|SAMPLEAPP_UART_RX_EVT|SAMPLEAPP_CONSOLE_EVT|SAMPLEAPP_OLED_EVT)==4);
  assert(deallocations==1);
  hasMessage=1;
  assert(SampleApp_ProcessEvent(1,SYS_EVENT_MSG)==0);
  assert(deallocations==2);
  message.hdr.event=AF_INCOMING_MSG_CMD;
  message.clusterId=SAMPLEAPP_CLUSTERID_BROADCAST;
  hasMessage=1;
  assert(SampleApp_ProcessEvent(1,SYS_EVENT_MSG)==0);
  assert(broadcastMessages==1&&deallocations==3);
#ifndef ATT_TERMINAL
  message.hdr.event=ZDO_CB_MSG;
  message.clusterId=Device_annce;
  hasMessage=1;
  assert(SampleApp_ProcessEvent(1,SYS_EVENT_MSG)==0);
#ifdef APP_TEST_REAL_UART
  drain_uart();
#endif
  assert(strstr(output,"Device announce received")&&deallocations==4);
#endif
  tick(150);
  console_help_test();
#ifdef ATT_TERMINAL
  assert(rtcSeedCalls==0 && rtcInvalid);
  command("#TIME 260923223344");
  assert(rtcInvalid && strstr(output,"TIME_SOURCE_COORDINATOR"));
  p[0]=26;p[1]=9;p[2]=23;p[3]=22;p[4]=33;p[5]=44;
  rx(0,ATT_TIME,300,1,p,6);
  assert(!rtcInvalid && rtcSeedCalls==0);
  memset(p,0,sizeof(p));
#else
  assert(rtcSeedCalls==1 && !rtcInvalid);
  command("#TIME 260923223344");
  tick(100); /* 等待协调器统计镜像初始化和首次提交 */
  command("#DB STATS");
  assert(strstr(output,"HOST status=0 boots=1"));
#endif
  assert(clockTime.hour==22&&clockTime.minute==33&&clockTime.weekday==3);
#ifdef ATT_TERMINAL
  tick(50); /* 等待 AT24C08 双镜像扫描结束 */
#endif
#ifdef ATT_TERMINAL
  keys=1;tick(1);assert(strcmp(lastTitle,"REGISTER MODE")==0);
  keys=1;tick(1);assert(strcmp(lastTitle,"ATTENDANCE MODE")==0);
  keys=1;tick(1);card(1);tick(150);assert(App_Database_Count()==1);
  /* 等待上报ACK期间，注册/取消仍应立即生效，不阻塞本机操作。 */
  command("#DB REG");assert(strcmp(lastTitle,"REGISTER MODE")==0);
  command("#DB CANCEL");assert(strcmp(lastTitle,"ATTENDANCE MODE")==0);
  session=Comm_Protocol_ReadUint16(packet+4);tx=Comm_Protocol_ReadUint16(packet+6);(void)session;(void)tx;
  /* 本地提交生成事件后HELLO可能覆盖发送观察值，ACK使用本地递增事务号。 */
  rx(0,ATT_EVENT|ATT_REPLY,1234,2,NULL,0);
  cardOn=0;SampleApp_ProcessEvent(1,SAMPLEAPP_CARD_EVT);tick(900);
  card(1);tick(150);assert(App_Database_Generation()==2);
  p[0]=0;assert(App_Database_Execute(ATT_LOG,p,1,0,0,0)==ATT_OK);
  assert(App_Database_Reply()[10]==26&&App_Database_Reply()[11]==9&&App_Database_Reply()[12]==23);
  assert(App_Database_Reply()[13]==22&&App_Database_Reply()[14]==33&&App_Database_Reply()[15]==44&&App_Database_Reply()[16]==1);
  for(i=0;i<10;i++)SampleApp_ProcessEvent(1,SAMPLEAPP_CARD_EVT);assert(App_Database_Generation()==2);
  tick(900);command("#LIST");tick(15);assert(strstr(output,"202600000001"));
  command("#DB FIND 01000000");assert(strstr(output,"USER slot=0"));
  command("#DB SET 0 202612345678 Alice");tick(150);assert(!memcmp(App_Database_User(0)+11,"202612345678",12));tick(900);
  p[0]=1;rx(0,ATT_MODE,300,40,p,29);
  memset(p,0,sizeof(p));p[1]=4;p[2]=2;rx(0,ATT_SCAN,300,41,p,48);tick(150);assert(App_Database_Count()==2);
  assert(lastReplyLength==55 && lastReply[3]==45 && lastReply[52]==1);
  tx=App_Database_Generation();rx(0,ATT_SCAN,300,41,p,48);tick(5);assert(App_Database_Generation()==tx&&App_Database_Count()==2);
  assert(lastReply[3]==5 && lastReply[12]==1);
  memset(p,0,sizeof(p));p[0]=2;rx(0,ATT_MODE,300,50,p,29);
  p[1]=4;p[2]=2;rx(0,ATT_SCAN,300,41,p,48);
  card(2);tick(150);assert(App_Database_Count()==1);
  puts("PASS: terminal buttons, registration, attendance, held-card gating, serial queries/update, remote registration and replay");
#else
  p[0]=0;p[1]=2;p[5]=p[6]=0;rx(0xABCD,ATT_HELLO,300,0,p,7);
  keys=1;tick(1);assert(packet[2]==ATT_MODE&&packet[8]==1);
  keys=1;tick(1);assert(packet[2]==ATT_MODE&&packet[8]==0);
  session=Comm_Protocol_ReadUint16(packet+4);tx=Comm_Protocol_ReadUint16(packet+6);memset(p,0,4);
  rx(0xABCD,ATT_MODE|ATT_REPLY,session,tx,p,4);
  command("#DB REG 202612345678 Alice");assert(packet[2]==ATT_MODE&&destination==0xABCD);
  session=Comm_Protocol_ReadUint16(packet+4);tx=Comm_Protocol_ReadUint16(packet+6);memset(p,0,4);rx(0xABCD,ATT_MODE|ATT_REPLY,session,tx,p,4);
  card(1);assert(packet[2]==ATT_SCAN&&packet[8]==1&&packet[9]==4);
  tx=Comm_Protocol_ReadUint16(packet+6);tick(201);assert(Comm_Protocol_ReadUint16(packet+6)==tx&&packet[2]==ATT_SCAN);
  /* 错误来源不能确认请求。 */
  rx(0xABCE,ATT_SCAN|ATT_REPLY,session,tx,p,4);command("#LIST 0");assert(strstr(output,"ERR BUSY"));
  /* 另一个终端事件不能改变本机在途扫描的结果类型。 */
  p[0]=ATT_SCAN;p[1]=ATT_OK;p[2]=0;p[3]=0;p[4]=0;p[5]=2;p[6]=2;
  rx(0xABCD,ATT_EVENT,300,90,p,7);
  memset(p,0,sizeof(p));p[4]=1;
  rx(0xABCD,ATT_SCAN|ATT_REPLY,session,tx,p,5);
  assert(strcmp(lastTitle,"REGISTER OK")==0);
  tick(100);command("#DB STATS");assert(strstr(output,"register=1 remove=0"));
  if(packet[2]==ATT_TIME)
  {
    memset(p,0,sizeof(p));
    rx(0xABCD,ATT_TIME|ATT_REPLY,session,Comm_Protocol_ReadUint16(packet+6),p,4);
  }
  command("#LIST 0");assert(packet[2]==ATT_USER);
  tx=Comm_Protocol_ReadUint16(packet+6);rx(0xABCD,ATT_USER|ATT_REPLY,session,tx,p,4);
  command("#DB FIND 01000000");assert(packet[2]==ATT_FIND&&packet[8]==4);
  tx=Comm_Protocol_ReadUint16(packet+6);rx(0xABCD,ATT_FIND|ATT_REPLY,session,tx,p,4);
  command("#DB DEL 8");assert(strstr(output,"ERR SYNTAX"));
  /* 响应中的实际执行模式优先于请求时看到的旧模式。 */
  card(2);assert(packet[2]==ATT_SCAN && packet[8]==0);
  tx=Comm_Protocol_ReadUint16(packet+6);memset(p,0,sizeof(p));p[4]=1;
  rx(0xABCD,ATT_SCAN|ATT_REPLY,session,tx,p,5);
  assert(strcmp(lastTitle,"REGISTER OK")==0);
  tick(100);command("#DB STATS");assert(strstr(output,"register=2 remove=0"));
  puts("PASS: coordinator dispatch, RPC/retry/source checks, concurrent event/mode results, persistent statistics");
#endif
  console_end_test();
  assert(packetLen<=62);return 0;
}
