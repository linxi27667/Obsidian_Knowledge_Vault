/**
 * @file SampleApp.h
 * @brief 应用层配置头文件
 *
 * 定义了端点号、Cluster ID、定时器周期、事件标志等。
 * 协调器和终端设备共用此文件。
 */

#ifndef SAMPLEAPP_H
#define SAMPLEAPP_H

#ifdef __cplusplus
extern "C"
{
#endif

#include "ZComDef.h"

/* ==================== 端点配置 ==================== */

/**
 * 端点号：两个设备必须使用相同的端点号才能通信
 * 范围：1-240
 */
#define SAMPLEAPP_ENDPOINT           20

/**
 * Profile ID和Device ID，用于ZigBee设备描述
 */
#define SAMPLEAPP_PROFID             0x0F08   /* Profile ID */
#define SAMPLEAPP_DEVICEID           0x0001   /* 设备ID */
#define SAMPLEAPP_DEVICE_VERSION     0        /* 设备版本 */
#define SAMPLEAPP_FLAGS              0        /* 标志位 */

/* ==================== Cluster ID定义 ==================== */

/**
 * Cluster ID = 消息分类标签
 * 发送和接收使用相同的Cluster ID来匹配
 */
#define SAMPLEAPP_MAX_CLUSTERS              4   /* 最大Cluster数量 */
#define SAMPLEAPP_PERIODIC_CLUSTERID        1   /* 周期消息 */
#define SAMPLEAPP_FLASH_CLUSTERID           2   /* Flash消息 */
#define SAMPLEAPP_CLUSTERID_UNICAST         3   /* 单播消息 */
#define SAMPLEAPP_CLUSTERID_BROADCAST       4   /* 广播消息 */

/* ==================== 定时器周期定义 ==================== */

/**
 * 各种周期任务的时间间隔（毫秒）
 */
#define SAMPLEAPP_INIT_DELAY                1000
#define SAMPLEAPP_INIT_STEP_DELAY           100
#define SAMPLEAPP_KEY_SCAN_INTERVAL          10
#define SAMPLEAPP_CONSOLE_INTERVAL           10
#define SAMPLEAPP_OLED_INTERVAL              10
#define SAMPLEAPP_DATABASE_INTERVAL          10
#define SAMPLEAPP_CARD_INTERVAL              200
#define SAMPLEAPP_SECOND_INTERVAL            1000
#define SAMPLEAPP_RETRY_INTERVAL             2000
#define SAMPLEAPP_RETRY_LIMIT                4
#define SAMPLEAPP_PEER_TIMEOUT_SECONDS       15
#define SAMPLEAPP_MODE_TIMEOUT_SECONDS       30
#define SAMPLEAPP_HELLO_INTERVAL_SECONDS     5
#define SAMPLEAPP_TIME_SYNC_INTERVAL_SECONDS 60

/* OSAL 事件位按业务分开，SYS_EVENT_MSG 使用 0x8000。 */
#define SAMPLEAPP_INIT_EVT                   0x0001
#define SAMPLEAPP_KEY_SCAN_EVT               0x0002
#define SAMPLEAPP_UART_RX_EVT                0x0004
#define SAMPLEAPP_DATABASE_EVT               0x0008
#define SAMPLEAPP_CONSOLE_EVT                0x0010
#define SAMPLEAPP_OLED_EVT                   0x0020
#define SAMPLEAPP_CARD_EVT                   0x0040
#define SAMPLEAPP_SECOND_EVT                 0x0080
#define SAMPLEAPP_RETRY_EVT                  0x0100
#define SAMPLEAPP_BUZZER_EVT                 0x0200

/* ==================== Flash组定义 ==================== */

#define SAMPLEAPP_FLASH_GROUP               0x0001  /* Flash组ID */
#define SAMPLEAPP_FLASH_DURATION            1000    /* Flash持续时间 */

/* ==================== 函数声明 ==================== */

/**
 * @brief 应用层初始化函数
 * @param task_id 任务ID
 */
extern void SampleApp_Init( uint8 task_id );

/**
 * @brief 应用层事件处理函数
 * @param task_id 任务ID
 * @param events 事件标志
 * @return 处理后的事件标志
 */
extern UINT16 SampleApp_ProcessEvent( uint8 task_id, uint16 events );

#ifdef __cplusplus
}
#endif

#endif /* SAMPLEAPP_H */
