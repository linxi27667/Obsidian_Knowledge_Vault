#include "OSAL.h"
#include "hal_rtc.h"
#define RTC_REG_SECONDS 0x10
#define RTC_REG_FLAGS 0x1E
#define RTC_REG_CONTROL 0x1F
#define RTC_REG_OFFSET 0x30
#define RTC_FLAG_VLF 0x02
#define RTC_CTRL_STOP 0x40
#define RTC_RESERVED17 0xD8
#define RTC_RESERVED31 0x08
#define RTC_EXTENSION_DEFAULT 0x04

static uint8 Hal_Rtc_Bcd(uint8 n)
{
    return ((n / 10) << 4) | (n % 10);
}
static uint8 Hal_Rtc_Decimal(uint8 n)
{
    if ((n & 15) > 9 || (n >> 4) > 9)
    {
        return 0xFF;
    }
    return (n >> 4) * 10 + (n & 15);
}
static uint8 Hal_Rtc_Valid(const rtc_time_t *t)
{
    uint8 days;
    if (!t || t->second > 59 || t->minute > 59 || t->hour > 23 || t->weekday > 6 || !t->month ||
    t->month > 12 || t->year > 99 || !t->day)
    {
        return 0;
    }
    days = 31;
    if (t->month == 4 || t->month == 6 || t->month == 9 || t->month == 11)
    {
        days = 30;
    }
    if (t->month == 2)
    {
        days = (t->year % 4) ? 28 : 29;
    }
    return t->day <= days;
}
uint8 Hal_Rtc_Init(uint8 *flags)
{
    if (!flags)
    {
        return I2C_PARAM;
    }
    return Hal_I2c_Read_Reg(RTC_I2C_ADDR, RTC_REG_FLAGS, flags, 1);
}
uint8 Hal_Rtc_Read_Time(rtc_time_t *time)
{
    uint8 flags, status, raw[7], daybit;
    rtc_time_t t;
    if (!time)
    {
        return I2C_PARAM;
    }
    status = Hal_Rtc_Init(&flags);
    if (status)
    {
        return status;
    }
    if (flags & RTC_FLAG_VLF)
    {
        return RTC_TIME_INVALID;
    }
    status = Hal_I2c_Read_Reg(RTC_I2C_ADDR, RTC_REG_CONTROL, &flags, 1);
    if (status)
    {
        return status;
    }
    if (flags & RTC_CTRL_STOP)
    {
        return RTC_TIME_INVALID;
    }
    status = Hal_I2c_Read_Reg(RTC_I2C_ADDR, RTC_REG_SECONDS, raw, sizeof(raw));
    if (status)
    {
        return status;
    }
    t.second = Hal_Rtc_Decimal(raw[0] & 0x7F);
    t.minute = Hal_Rtc_Decimal(raw[1] & 0x7F);
    t.hour = Hal_Rtc_Decimal(raw[2] & 0x3F);
    t.day = Hal_Rtc_Decimal(raw[4] & 0x3F);
    t.month = Hal_Rtc_Decimal(raw[5] & 0x1F);
    t.year = Hal_Rtc_Decimal(raw[6]);
    daybit = raw[3] & 0x7F;
    if (!daybit || (daybit & (daybit - 1)))
    {
        return RTC_TIME_INVALID;
    }
    t.weekday = 0;
    while ((daybit >>= 1) != 0)
    {
        ++t.weekday;
    }
    if (!Hal_Rtc_Valid(&t))
    {
        return RTC_TIME_INVALID;
    }
    *time = t;
    return I2C_OK;
}
uint8 Hal_Rtc_Set_Time(const rtc_time_t *t)
{
    uint8 raw[16], aux[3], status, release, stop = RTC_CTRL_STOP;
    if (!Hal_Rtc_Valid(t))
    {
        return I2C_PARAM;
    }
    /* ʱ��ר�ó�ʼ�����رո澯/��ʱ�������ñ���λ����α���ϵ�ʱ�䡣 */
    osal_memset(raw, 0, sizeof(raw));
    raw[0] = Hal_Rtc_Bcd(t->second);
    raw[1] = Hal_Rtc_Bcd(t->minute);
    raw[2] = Hal_Rtc_Bcd(t->hour);
    raw[3] = 1 << t->weekday;
    raw[4] = Hal_Rtc_Bcd(t->day);
    raw[5] = Hal_Rtc_Bcd(t->month);
    raw[6] = Hal_Rtc_Bcd(t->year);
    raw[7] = RTC_RESERVED17;
    raw[13] = RTC_EXTENSION_DEFAULT;
    raw[15] = RTC_CTRL_STOP;
    aux[0] = 0;
    aux[1] = RTC_RESERVED31;
    aux[2] = 0;
    status = Hal_I2c_Write_Reg(RTC_I2C_ADDR, RTC_REG_CONTROL, &stop, 1);
    if (status)
    {
        return status;
    }
    status = Hal_I2c_Write_Reg(RTC_I2C_ADDR, RTC_REG_SECONDS, raw, sizeof(raw));
    if (!status)
    {
        status = Hal_I2c_Write_Reg(RTC_I2C_ADDR, RTC_REG_OFFSET, aux, sizeof(aux));
    }
    stop = 0;
    release = Hal_I2c_Write_Reg(RTC_I2C_ADDR, RTC_REG_CONTROL, &stop, 1);
    return status ? status : release;
}
/* RTC ����ʱ�ù̼��ı��ر���ʱ��Уʱ�������̱����ʱ��Ϊ����ʱ�䡣 */
uint8 Hal_Rtc_Seed_Build_Time(rtc_time_t *time)
{
    static const char months[12][4] = {
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    static const uint8 month_days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    const char *date = __DATE__;
    const char *clock = __TIME__;
    rtc_time_t build;
    uint16 days = 6;
    uint8 month;
    uint8 index;
    uint8 status;

    if (!time || date[7] != '2' || date[8] != '0')
    {
        return I2C_PARAM;
    }
    for (month = 0; month < 12; ++month)
    {
        if (date[0] == months[month][0] && date[1] == months[month][1] &&
        date[2] == months[month][2])
        {
            break;
        }
    }
    if (month == 12)
    {
        return I2C_PARAM;
    }
    build.year = (date[9] - '0') * 10 + date[10] - '0';
    build.month = month + 1;
    build.day = (date[4] == ' ' ? 0 : date[4] - '0') * 10 + date[5] - '0';
    build.hour = (clock[0] - '0') * 10 + clock[1] - '0';
    build.minute = (clock[3] - '0') * 10 + clock[4] - '0';
    build.second = (clock[6] - '0') * 10 + clock[7] - '0';
    for (index = 0; index < build.year; ++index)
    {
        days += (index % 4 == 0) ? 366 : 365;
    }
    for (index = 1; index < build.month; ++index)
    {
        days += month_days[index - 1];
        if (index == 2 && build.year % 4 == 0)
        {
            ++days;
        }
    }
    build.weekday = (uint8)((days + build.day - 1) % 7);
    status = Hal_Rtc_Set_Time(&build);
    if (status)
    {
        return status;
    }
    return Hal_Rtc_Read_Time(time);
}
