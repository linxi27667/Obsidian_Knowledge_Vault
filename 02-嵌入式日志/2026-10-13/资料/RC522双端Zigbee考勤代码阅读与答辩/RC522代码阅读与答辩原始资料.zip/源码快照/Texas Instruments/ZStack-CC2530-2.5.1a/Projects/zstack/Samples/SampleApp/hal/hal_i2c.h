#ifndef HAL_I2C_H
#define HAL_I2C_H
#include "ZComDef.h"
#define I2C_OK 0
#define I2C_NACK 1
#define I2C_TIMEOUT 2
#define I2C_PARAM 3
#define I2C_BUSY 4
#define I2C_MAX_TRANSFER 32
uint8 Hal_I2c_Init(void);
uint8 Hal_I2c_Probe(uint8 addr);
uint8 Hal_I2c_Start(void);
uint8 Hal_I2c_Stop(void);
uint8 Hal_I2c_Write_Byte(uint8 value);
uint8 Hal_I2c_Read_Byte(uint8 *value, uint8 ack);
uint8 Hal_I2c_Write(uint8 addr, const uint8 *data, uint8 len);
uint8 Hal_I2c_Read(uint8 addr, uint8 *data, uint8 len);
uint8 Hal_I2c_Write_Reg(uint8 addr, uint8 reg, const uint8 *data, uint8 len);
uint8 Hal_I2c_Read_Reg(uint8 addr, uint8 reg, uint8 *data, uint8 len);
#endif
