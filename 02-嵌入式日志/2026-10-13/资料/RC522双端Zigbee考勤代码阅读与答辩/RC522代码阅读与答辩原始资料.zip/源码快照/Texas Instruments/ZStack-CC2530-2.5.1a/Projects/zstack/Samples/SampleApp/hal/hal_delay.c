#include "hal_delay.h"

void Hal_Delay_Us(uint16 us)
{
    while (us--)
    {
        asm("NOP");
        asm("NOP");
        asm("NOP");
        asm("NOP");
        asm("NOP");
        asm("NOP");
        asm("NOP");
        asm("NOP");
        asm("NOP");
        asm("NOP");
    }
}

void Hal_Delay_Ms(uint16 ms)
{
    while (ms--)
    {
        Hal_Delay_Us(1000);
    }
}
