#ifndef HAL_OLED_H
#define HAL_OLED_H

#include "ZComDef.h"

#define OLED_I2C_ADDR_0 0x3C
#define OLED_I2C_ADDR_1 0x3D

uint8 Hal_Oled_Init(void);
uint8 Hal_Oled_Get_Address(void);
uint8 Hal_Oled_Show_Line(uint8 page, const char *text);

void Hal_Oled_Glyph(uint8 c, uint8 glyph[6]);
uint8 Hal_Oled_Write_Chunk(uint8 page, uint8 x, const uint8 *data, uint8 len);
#endif
