#include "OnBoard.h"
#include "board_config.h"
#include "hal_i2c.h"
#define I2C_HALF_US 5
#define I2C_STRETCH_POLLS 100
#define SCL_LOW() (P1DIR |= BOARD_I2C_SCL_MASK)
#define SDA_LOW() (P1DIR |= BOARD_I2C_SDA_MASK)
#define SDA_RELEASE() (P1DIR &= ~BOARD_I2C_SDA_MASK)

static uint8 g_initialized;
static void Hal_I2c_Delay(void)
{
    MicroWait(I2C_HALF_US);
}
static uint8 Hal_I2c_Scl_Release(void)
{
    uint8 n;
    P1DIR &= ~BOARD_I2C_SCL_MASK;
    /* ���������ʼ��Ϊ0�����뷽���ʾ�ͷ����ߣ���������ʱ����չ�� */
    for (n = 0; n < I2C_STRETCH_POLLS; ++n)
    {
        if (BOARD_I2C_SCL_PIN)
        {
            Hal_I2c_Delay();
            return I2C_OK;
        }
        Hal_I2c_Delay();
    }
    return I2C_TIMEOUT;
}
uint8 Hal_I2c_Stop(void)
{
    uint8 status;
    if (!g_initialized)
    {
        return I2C_BUSY;
    }
    SCL_LOW();
    SDA_LOW();
    Hal_I2c_Delay();
    status = Hal_I2c_Scl_Release();
    SDA_RELEASE();
    Hal_I2c_Delay();
    return status;
}
uint8 Hal_I2c_Init(void)
{
    uint8 i, status;
    /* ���ͷ�������������P1.1���������ⲿ������ */
    P1DIR &= ~(BOARD_I2C_SCL_MASK | BOARD_I2C_SDA_MASK);
    P1SEL &= ~(BOARD_I2C_SCL_MASK | BOARD_I2C_SDA_MASK);
    BOARD_I2C_SCL_PIN = 0;
    BOARD_I2C_SDA_PIN = 0;
    /* P1.2 is high-impedance when released; external R81/R82 pull-ups are required. */
    P1INP |= BOARD_I2C_SCL_MASK;
    g_initialized = 1;
    for (i = 0; i < 9; ++i)
    {
        if ((status = Hal_I2c_Scl_Release()) != I2C_OK)
        {
            return status;
        }
        if (BOARD_I2C_SDA_PIN)
        {
            break;
        }
        SCL_LOW();
        Hal_I2c_Delay();
    }
    status = Hal_I2c_Stop();
    return status ? status : (BOARD_I2C_SDA_PIN ? I2C_OK : I2C_BUSY);
}
uint8 Hal_I2c_Start(void)
{
    uint8 status;
    if (!g_initialized)
    {
        return I2C_BUSY;
    }
    SDA_RELEASE();
    Hal_I2c_Delay();
    status = Hal_I2c_Scl_Release();
    if (status)
    {
        return status;
    }
    if (!BOARD_I2C_SDA_PIN)
    {
        return I2C_BUSY;
    }
    SDA_LOW();
    Hal_I2c_Delay();
    SCL_LOW();
    return I2C_OK;
}
uint8 Hal_I2c_Write_Byte(uint8 value)
{
    uint8 i, status;
    if (!g_initialized)
    {
        return I2C_BUSY;
    }
    for (i = 0; i < 8; ++i)
    {
        if (value & 0x80)
        {
            SDA_RELEASE();
        }
        else
        {
            SDA_LOW();
        }
        Hal_I2c_Delay();
        if ((status = Hal_I2c_Scl_Release()) != I2C_OK)
        {
            return status;
        }
        SCL_LOW();
        value <<= 1;
    }
    SDA_RELEASE();
    Hal_I2c_Delay();
    if ((status = Hal_I2c_Scl_Release()) != I2C_OK)
    {
        return status;
    }
    status = BOARD_I2C_SDA_PIN ? I2C_NACK : I2C_OK;
    SCL_LOW();
    return status;
}
uint8 Hal_I2c_Read_Byte(uint8 *value, uint8 ack)
{
    uint8 i, v = 0, status;
    if (!value)
    {
        return I2C_PARAM;
    }
    if (!g_initialized)
    {
        return I2C_BUSY;
    }
    SDA_RELEASE();
    for (i = 0; i < 8; ++i)
    {
        Hal_I2c_Delay();
        if ((status = Hal_I2c_Scl_Release()) != I2C_OK)
        {
            return status;
        }
        v = (v << 1) | (BOARD_I2C_SDA_PIN ? 1 : 0);
        SCL_LOW();
    }
    if (ack)
    {
        SDA_LOW();
    }
    else
    {
        SDA_RELEASE();
    }
    Hal_I2c_Delay();
    status = Hal_I2c_Scl_Release();
    SCL_LOW();
    SDA_RELEASE();
    if (!status)
    {
        *value = v;
    }
    return status;
}
static uint8 Hal_I2c_Finish(uint8 status)
{
    uint8 stop = Hal_I2c_Stop();
    return status ? status : stop;
}
static uint8 Hal_I2c_Address(uint8 addr, uint8 read)
{
    uint8 status = Hal_I2c_Start();
    return status ? status : Hal_I2c_Write_Byte((addr << 1) | read);
}
uint8 Hal_I2c_Probe(uint8 addr)
{
    uint8 status;
    if (addr > 0x7F)
    {
        return I2C_PARAM;
    }
    status = Hal_I2c_Address(addr, 0);
    return Hal_I2c_Finish(status);
}
uint8 Hal_I2c_Write(uint8 addr, const uint8 *data, uint8 len)
{
    uint8 status, i;
    if (addr > 0x7F || len > I2C_MAX_TRANSFER || (!data && len))
    {
        return I2C_PARAM;
    }
    status = Hal_I2c_Address(addr, 0);
    for (i = 0; !status && i < len; ++i)
    {
        status = Hal_I2c_Write_Byte(data[i]);
    }
    return Hal_I2c_Finish(status);
}
uint8 Hal_I2c_Read(uint8 addr, uint8 *data, uint8 len)
{
    uint8 status, i;
    if (addr > 0x7F || !data || !len || len > I2C_MAX_TRANSFER)
    {
        return I2C_PARAM;
    }
    status = Hal_I2c_Address(addr, 1);
    for (i = 0; !status && i < len; ++i)
    {
        status = Hal_I2c_Read_Byte(data + i, i + 1 < len);
    }
    return Hal_I2c_Finish(status);
}
uint8 Hal_I2c_Write_Reg(uint8 addr, uint8 reg, const uint8 *data, uint8 len)
{
    uint8 status, i;
    if (addr > 0x7F || len > I2C_MAX_TRANSFER || (!data && len))
    {
        return I2C_PARAM;
    }
    status = Hal_I2c_Address(addr, 0);
    if (!status)
    {
        status = Hal_I2c_Write_Byte(reg);
    }
    for (i = 0; !status && i < len; ++i)
    {
        status = Hal_I2c_Write_Byte(data[i]);
    }
    return Hal_I2c_Finish(status);
}
uint8 Hal_I2c_Read_Reg(uint8 addr, uint8 reg, uint8 *data, uint8 len)
{
    uint8 status, i;
    if (addr > 0x7F || !data || !len || len > I2C_MAX_TRANSFER)
    {
        return I2C_PARAM;
    }
    status = Hal_I2c_Address(addr, 0);
    if (!status)
    {
        status = Hal_I2c_Write_Byte(reg);
    }
    if (!status)
    {
        status = Hal_I2c_Address(addr, 1);
    }
    for (i = 0; !status && i < len; ++i)
    {
        status = Hal_I2c_Read_Byte(data + i, i + 1 < len);
    }
    return Hal_I2c_Finish(status);
}
