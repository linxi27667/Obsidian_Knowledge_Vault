/* ����ҵ��ʵ�֡��ɽ�ɫ���ļ��� OSAL �¼�������ȣ������д����������� */
#include "AF.h"
#include "OSAL.h"
#include "ZDApp.h"
#include "ZDProfile.h"
#include "ZGlobals.h"
#include "app_ui.h"
#include "comm_protocol.h"
#include "SampleApp.h"
#include "NLMEDE.h"
#include "OnBoard.h"
#include "comm_broadcast.h"
#include "comm_unicast.h"
#include "device1_uart.h"
#include "hal_buzzer.h"
#include "hal_board_key.h"
#include "hal_led.h"
#include "hal_console_uart.h"
#include "hal_eeprom.h"
#include "hal_i2c.h"
#include "hal_rc522.h"
#include "hal_rtc.h"
#include "nwk.h"
#include <string.h>

#include "app_coordinator.h"
#include "app_host_store.h"

extern uint8 SampleApp_TaskID;
extern devStates_t SampleApp_NwkState;

static uint8 g_network_joined;
static uint8 g_peripherals_ready;
static uint8 g_peripheral_init_step;
static uint8 g_reader_ready;
static uint8 g_card_held_near_reader;
static uint8 g_attendance_mode;
static uint8 g_mode_timeout_seconds;
static uint8 g_rtc_read_status = 5;
static uint8 g_database_status = ATT_OFFLINE;
static uint8 g_database_user_count;
static uint8 g_terminal_age_seconds = 255;
static uint8 g_console_output_step;
static uint8 g_list_command_type;
static uint8 g_export_csv;
static uint8 g_list_command_index;
static uint8 g_list_waiting_for_response;
static uint8 g_pending_command_type;
static uint16 g_terminal_short_address = 0xFFFF;
static uint16 g_session_id;
static uint16 g_transaction_counter;
static uint16 g_terminal_session_id;
static uint8 g_time_sync_pending;
static uint8 g_mode_cancel_deferred;
static uint8 g_last_scan_mode;

static rtc_time_t g_rtc_time;
static uint8 g_registered_identity[28];
static uint8 g_last_card_uid[10];
static uint8 g_last_card_uid_length;
static uint8 g_pending_frame[ATT_FRAME_MAX];
static uint8 g_pending_frame_length;
static uint8 g_retry_count;
static uint8 g_transmit_frame[ATT_FRAME_MAX];

void App_Coordinator_Command_Process(uart_cmd_t *command);
static const char *App_Coordinator_Result_Text(uint8 s);
static void App_Coordinator_Send(uint16 dst, uint8 op, uint16 s, uint16 tx, const uint8 *p, uint8 n);
static void App_Coordinator_Hex(const uint8 *p, uint8 n, char *out);
static void App_Coordinator_Show_Result(uint8 op, const uint8 *p, uint8 n);
static void App_Coordinator_Set_Mode(uint8 value, const uint8 *id);
static void App_Coordinator_Time_Payload(uint8 *p);
static uint8 App_Coordinator_Set_Time(const uint8 *p);
static void App_Coordinator_Request(uint8 op, const uint8 *p, uint8 n);
void App_Coordinator_Unicast_Receive(uint16 src, uint8 *f, uint8 len);
static void App_Coordinator_Network_Status(uint8 line);
static void App_Coordinator_Begin_Mode(uint8 m, const uint8 *id);
static uint8 App_Coordinator_Parse_Index(const char *s, uint8 limit, uint8 *value);
static uint8 App_Coordinator_Parse_Identity(char *id, char *name, uint8 *out);
static uint8 App_Coordinator_Hex_Digit(char c);
static uint8 App_Coordinator_Parse_Uid(const char *s, uint8 *out);

/* ==================== Ӧ����װ���������� ==================== */
void App_Coordinator_Init(uint8 task_id)
{
    g_session_id = osal_rand();
    if (g_session_id == 0)
    {
        g_session_id = 1;
    }


    /* LED��ʼ����Э��ջHalDriverInit��ɣ�Ӧ��ֻ����״̬�� */
    HalLedSet(HAL_LED_1, HAL_LED_MODE_OFF);
    Hal_Key_Init();
    Hal_Buzzer_Init();
    Hal_Buzzer_Bind(task_id, SAMPLEAPP_BUZZER_EVT);

    Hal_Uart_Print("[BOOT] ATT2 COORDINATOR\r\n");

}

uint8 App_Coordinator_Peripherals_Process(void)
{
    uint8 driver_status;
    uint8 driver_flags;

    if (g_peripherals_ready)
    {
        return 1;
    }
    switch (g_peripheral_init_step++)
    {
    case 0:
        driver_status = Hal_I2c_Init();
        Hal_Uart_Printf("[DRV] I2C=%u\r\n", (unsigned int)driver_status);
        break;

    case 1:
        driver_flags = 0;
        driver_status = Hal_Rtc_Init(&driver_flags);
        Hal_Uart_Printf("[DRV] RTC=%u flags=%x\r\n", (unsigned int)driver_status,
        (unsigned int)driver_flags);
        break;

    case 2:
        g_reader_ready = Hal_Rc522_Init();
        Hal_Uart_Printf("[DRV] RC522=%x error=%u\r\n", (unsigned int)g_rc522_version,
        (unsigned int)g_rc522_last_error);
        break;

    case 3:
        /* Э����24C02ֻ����ͳ�ƣ��ն�24C08����Ȩ�����ڿ⡣ */
        App_Host_Store_Init();
        Hal_Uart_Printf("[DRV] EEPROM=%u\r\n", (unsigned int)Hal_Eeprom_Init());
        App_Ui_Init(0);
        Hal_Uart_Printf("[DRV] OLED=%u\r\n", (unsigned int)App_Ui_Error());
        g_rtc_read_status = Hal_Rtc_Read_Time(&g_rtc_time);
        if (g_rtc_read_status == RTC_TIME_INVALID)
        {
            g_rtc_read_status = Hal_Rtc_Seed_Build_Time(&g_rtc_time);
            Hal_Uart_Printf("[RTC] build-time seed status=%u\r\n",
            (unsigned int)g_rtc_read_status);
        }
        App_Ui_Time(&g_rtc_time, g_rtc_read_status);
        g_peripherals_ready = 1;
        Hal_Uart_Print("[READY] #HELP IDLE=ATTEND KEY1=REG KEY2=REMOVE SAME=EXIT\r\n");
        break;

    default:
        break;
    }

    return g_peripherals_ready;
}

void App_Coordinator_Network_Update(uint8 joined)
{
    g_network_joined = joined;
    if (g_network_joined)
    {
        Hal_Uart_Print("[ZB] Coordinator network started\r\n");
    }
    else
    {
        Hal_Uart_Print("[ZB] Coordinator starting\r\n");
    }
}

void App_Coordinator_Database_Process(void)
{
    App_Host_Store_Process();
}

void App_Coordinator_Display_Process(void)
{

    if (g_peripherals_ready)
    {
        App_Ui_Status(g_network_joined, g_terminal_age_seconds <= SAMPLEAPP_PEER_TIMEOUT_SECONDS, g_database_status,
        g_database_user_count, g_attendance_mode, g_mode_timeout_seconds);
        App_Ui_Tick();
    }
}

void App_Coordinator_Retry_Process(void)
{
    uint8 result[4];

    if (g_pending_frame_length != 0)
    {
        if (g_retry_count < SAMPLEAPP_RETRY_LIMIT && g_network_joined)
        {
            ++g_retry_count;
            Comm_Unicast_Send(g_terminal_short_address, g_pending_frame, g_pending_frame_length);
            osal_start_timerEx(SampleApp_TaskID, SAMPLEAPP_RETRY_EVT, SAMPLEAPP_RETRY_INTERVAL);
        }
        else
        {
            result[0] = ATT_TIMEOUT;
            result[1] = 255;
            result[2] = 0;
            result[3] = 0;
            g_pending_frame_length = 0;
            g_list_waiting_for_response = 0;
            g_list_command_type = 0;
            App_Coordinator_Show_Result(g_pending_command_type, result, 4);
        }
    }
}

/* ==================== �����봮����� ==================== */
void App_Coordinator_Key_Process(uint8 shift, uint8 keys)
{
    (void)shift;
    if (!g_peripherals_ready || keys == 0)
    {
        return;
    }

    /* ��ǰģʽ���ٰ�һ�������˳�����һ������ֱ���л�ģʽ�� */
    if (keys == (KEY0_PRESS | KEY1_PRESS))
    {
        App_Coordinator_Begin_Mode(0, NULL);
    }
    else if (keys & KEY0_PRESS)
    {
        App_Coordinator_Begin_Mode(g_attendance_mode == 1 ? 0 : 1, NULL);
    }
    else if (keys & KEY1_PRESS)
    {
        App_Coordinator_Begin_Mode(g_attendance_mode == 2 ? 0 : 2, NULL);
    }
}

void App_Coordinator_Command_Process(uart_cmd_t *command)
{
    char uid_text[21];
    uint8 argument_count;
    uint8 payload[32];
    uint8 i;
    uint8 value;

    if (command == NULL)
    {
        return;
    }

    argument_count = command->argument_count;

    if (!g_peripherals_ready)
    {
        Hal_Uart_Print("ERR INITIALIZING\r\n");
        return;
    }
    if (Hal_Uart_Free() < 120)
    {
        Hal_Uart_Print("ERR OUTPUT_BUSY\r\n");
        return;
    }

    switch (command->cmd_type)
    {
    case UART_CMD_HELP:
        if (argument_count == 1)
        {
            g_console_output_step = 1;
            return;
        }
        if (argument_count == 2 && strcmp(command->arguments[1], "TIME") == 0)
        {
            g_console_output_step = 10;
            return;
        }
        if (argument_count == 2 && strcmp(command->arguments[1], "DB") == 0)
        {
            g_console_output_step = 20;
            return;
        }
        break;

    case UART_CMD_STATUS:
        if (argument_count == 1)
        {
            g_console_output_step = 40;
            return;
        }
        break;

    case UART_CMD_RTC:
        if (argument_count == 1)
        {
            Hal_Uart_Printf("RTC status=%u time=20%u-%u-%u %u:%u:%u\r\n", (unsigned int)g_rtc_read_status,
            (unsigned int)g_rtc_time.year, (unsigned int)g_rtc_time.month, (unsigned int)g_rtc_time.day,
            (unsigned int)g_rtc_time.hour, (unsigned int)g_rtc_time.minute,
            (unsigned int)g_rtc_time.second);
            return;
        }
        break;

    case UART_CMD_TIME_SET:
        if (argument_count == 2 && strlen(command->arguments[1]) == 12)
        {
            for (i = 0; i < 6; ++i)
            {
                char *digit_pair = command->arguments[1] + i * 2;
                if (digit_pair[0] < '0' || digit_pair[0] > '9' || digit_pair[1] < '0' || digit_pair[1] > '9')
                {
                    break;
                }
                payload[i] = (digit_pair[0] - '0') * 10 + digit_pair[1] - '0';
            }

            if (i == 6)
            {
                value = App_Coordinator_Set_Time(payload);
                Hal_Uart_Printf("RTC SET status=%u\r\n", (unsigned int)value);

                if (value == 0)
                {
                    App_Coordinator_Request(ATT_TIME, payload, ATT_TIME_PAYLOAD_LENGTH);
                }
                return;
            }
        }
        break;

    case UART_CMD_UID:
        if (argument_count == 1)
        {
            App_Coordinator_Hex(g_last_card_uid, g_last_card_uid_length, uid_text);
            Hal_Uart_Printf("UID %s\r\n", uid_text);
            return;
        }
        break;

    case UART_CMD_BEEP:
        if (argument_count == 1)
        {
            Hal_Buzzer_Beep(80);
            Hal_Uart_Print("OK BEEP\r\n");
            return;
        }
        break;

    case UART_CMD_STATS:
        if (argument_count == 1)
        {
            Hal_Uart_Printf("HOST status=%u boots=%u attendance=%u register=%u remove=%u\r\n",
            (unsigned int)App_Host_Store_Status(),
            (unsigned int)App_Host_Store_Boot_Count(),
            (unsigned int)App_Host_Store_Count(0),
            (unsigned int)App_Host_Store_Count(1),
            (unsigned int)App_Host_Store_Count(2));
            return;
        }
        if (argument_count == 3 && strcmp(command->arguments[1], "RESET") == 0 &&
        strcmp(command->arguments[2], "CONFIRM") == 0)
        {
            if (g_pending_frame_length != 0)
            {
                Hal_Uart_Print("ERR BUSY\r\n");
                return;
            }
            Hal_Uart_Printf("HOST RESET status=%u\r\n", (unsigned int)App_Host_Store_Reset());
            return;
        }
        break;

    case UART_CMD_CANCEL:
        if (argument_count == 1)
        {
            App_Coordinator_Begin_Mode(0, NULL);
            return;
        }
        break;

    case UART_CMD_REGISTER:
        if (argument_count == 1)
        {
            App_Coordinator_Begin_Mode(1, NULL);
            return;
        }
        if (argument_count == 3 && App_Coordinator_Parse_Identity(command->arguments[1], command->arguments[2], payload))
        {
            App_Coordinator_Begin_Mode(1, payload);
            return;
        }
        break;

    case UART_CMD_UNREGISTER:
        if (argument_count == 1)
        {
            App_Coordinator_Begin_Mode(2, NULL);
            return;
        }
        break;

    default:
        break;
    }

    if (g_pending_frame_length || g_list_command_type)
    {
        Hal_Uart_Print("ERR BUSY\r\n");
        return;
    }

    switch (command->cmd_type)
    {
    case UART_CMD_LIST:
        if (argument_count == 1)
        {
            g_list_command_type = ATT_USER;
            g_list_command_index = 0;
            g_list_waiting_for_response = 0;
            return;
        }
        break;

    case UART_CMD_EXPORT:
        if (argument_count == 1)
        {
            g_export_csv = 1;
            g_list_command_type = ATT_LOG;
            g_list_command_index = 0;
            g_list_waiting_for_response = 0;
            Hal_Uart_Print("seq,id,date,time,valid,origin\r\n");
            return;
        }
        break;

    case UART_CMD_LOG:
        g_export_csv = 0;
        if (argument_count == 1 || (argument_count == 2 && strcmp(command->arguments[1], "ALL") == 0))
        {
            g_list_command_type = ATT_LOG;
            g_list_command_index = 0;
            g_list_waiting_for_response = 0;
            return;
        }
        if (argument_count == 2 && App_Coordinator_Parse_Index(command->arguments[1], 10, payload))
        {
            App_Coordinator_Request(ATT_LOG, payload, 1);
            return;
        }
        break;

    case UART_CMD_GET:
        if (argument_count == 2 && App_Coordinator_Parse_Index(command->arguments[1], 8, payload))
        {
            App_Coordinator_Request(ATT_USER, payload, 1);
            return;
        }
        break;

    case UART_CMD_FIND:
        if (argument_count == 2 && App_Coordinator_Parse_Uid(command->arguments[1], payload))
        {
            App_Coordinator_Request(ATT_FIND, payload, 11);
            return;
        }
        break;

    case UART_CMD_USER:
        if (argument_count == 5 && strcmp(command->arguments[1], "SET") == 0 &&
        App_Coordinator_Parse_Index(command->arguments[2], 8, payload) &&
        App_Coordinator_Parse_Identity(command->arguments[3], command->arguments[4], payload + 1))
        {
            App_Coordinator_Request(ATT_SET, payload, ATT_MODE_PAYLOAD_LENGTH);
            return;
        }
        if (argument_count == 3 && strcmp(command->arguments[1], "DEL") == 0 &&
        App_Coordinator_Parse_Index(command->arguments[2], 8, payload))
        {
            App_Coordinator_Request(ATT_DELETE, payload, 1);
            return;
        }
        break;

    case UART_CMD_DATABASE:
        if (argument_count == 2 && strcmp(command->arguments[1], "STATUS") == 0)
        {
            App_Coordinator_Request(ATT_META, NULL, 0);
            return;
        }
        if (argument_count == 3 && strcmp(command->arguments[1], "INIT") == 0 &&
        strcmp(command->arguments[2], "CONFIRM") == 0)
        {
            App_Coordinator_Request(ATT_FORMAT, (const uint8 *)"INIT", 4);
            return;
        }
        break;

    case UART_CMD_SYNC:
        if (argument_count == 1)
        {
            g_rtc_read_status = Hal_Rtc_Read_Time(&g_rtc_time);
            if (g_rtc_read_status != 0)
            {
                Hal_Uart_Print("ERR TIME_INVALID\r\n");
                return;
            }
            App_Coordinator_Time_Payload(payload);
            App_Coordinator_Request(ATT_TIME, payload, ATT_TIME_PAYLOAD_LENGTH);
            return;
        }
        break;

    default:
        break;
    }

    Hal_Uart_Print("ERR SYNTAX - #HELP\r\n");
}

/* ==================== �����ʾ��ҵ��ģʽ ==================== */
static const char *App_Coordinator_Result_Text(uint8 status)
{
    switch (status)
    {
    case ATT_OK:
        return "OK";
    case ATT_BUSY:
        return "BUSY";
    case ATT_PARAM:
        return "BAD PARAMETER";
    case ATT_UNKNOWN:
        return "UNKNOWN CARD";
    case ATT_FULL:
        return "DATABASE FULL";
    case ATT_EXISTS:
        return "ALREADY EXISTS";
    case ATT_STORAGE:
        return "STORAGE ERROR";
    case ATT_CORRUPT:
        return "DATABASE CORRUPT";
    case ATT_OFFLINE:
        return "READER OFFLINE";
    case ATT_TIMEOUT:
        return "ACK TIMEOUT";
    default:
        return "PROTOCOL ERROR";
    }
}

static void App_Coordinator_Send(uint16 destination, uint8 opcode, uint16 session, uint16 transaction, const uint8 *payload, uint8 payload_length)
{
    uint8 frame_length = Comm_Protocol_PackFrame(g_transmit_frame, sizeof(g_transmit_frame), opcode, session, transaction, payload, payload_length);
    if (frame_length && g_network_joined)
    {
        Comm_Unicast_Send(destination, g_transmit_frame, frame_length);
    }
}

static void App_Coordinator_Hex(const uint8 *uid, uint8 uid_length, char *text)
{
    static const char digits[] = "0123456789ABCDEF";
    uint8 index;
    for (index = 0; index < uid_length; index++)
    {
        text[index * 2] = digits[uid[index] >> 4];
        text[index * 2 + 1] = digits[uid[index] & 15];
    }
    text[uid_length * 2] = 0;
}

static void App_Coordinator_Show_Result(uint8 opcode, const uint8 *payload, uint8 payload_length)
{
    char student_id[13], student_name[17], uid_text[21];
    uint8 index;
    if (payload_length < 4)
    {
        return;
    }
    if (opcode == ATT_SCAN && (payload_length == 5 || payload_length == 45) && payload[payload_length - 1] <= 2)
    {
        g_last_scan_mode = payload[payload_length - 1];
        --payload_length;
    }
    if (opcode == ATT_SCAN)
    {
        g_attendance_mode = 0;
        g_mode_timeout_seconds = 0;
        osal_memset(g_registered_identity, 0, sizeof(g_registered_identity));
    }
    /* ��ѯ����������κţ������������ESP��127�ֽ�TX��������� */
    if (payload[0] != ATT_OK ||
        (opcode != ATT_USER && opcode != ATT_FIND && opcode != ATT_LOG && opcode != ATT_META))
    {
        Hal_Uart_Printf("RSP op=%u status=%u slot=%u gen=%u\r\n", (unsigned int)opcode, (unsigned int)payload[0],
        (unsigned int)payload[1], (unsigned int)Comm_Protocol_ReadUint16(payload + 2));
    }
    if (opcode == ATT_META && payload_length == 8)
    {
        g_database_status = payload[0];
        g_database_user_count = payload[4];
        Hal_Uart_Printf("DB users=%u capacity=8 logs=%u capacity=10 gen=%u\r\n", (unsigned int)payload[4],
        (unsigned int)payload[5], (unsigned int)Comm_Protocol_ReadUint16(payload + 2));
    }
    else if ((opcode == ATT_USER || opcode == ATT_FIND) && !payload[0] && payload_length == 44)
    {
        if (payload[4] != 4 && payload[4] != 7 && payload[4] != 10)
        {
            return;
        }
        App_Coordinator_Hex(payload + 5, payload[4], uid_text);
        osal_memcpy(student_id, payload + 15, 12);
        student_id[12] = 0;
        osal_memcpy(student_name, payload + 27, 16);
        student_name[16] = 0;
        Hal_Uart_Printf("USER slot=%u uid=%s id=%s name=%s gen=%u\r\n", (unsigned int)payload[1], uid_text, student_id, student_name, (unsigned int)Comm_Protocol_ReadUint16(payload + 2));
    }
    else if (opcode == ATT_LOG && !payload[0] && payload_length == 20)
    {
        for (index = 0; index < 6; index++)
        {
            student_id[index * 2] = '0' + (payload[4 + index] >> 4);
            student_id[index * 2 + 1] = '0' + (payload[4 + index] & 15);
        }
        student_id[12] = 0;
        if (g_export_csv)
        {
            Hal_Uart_Printf("%u,%s,20%u-%u-%u,%u:%u:%u,%u,%u\r\n",
            (unsigned int)Comm_Protocol_ReadUint16(payload + 18), student_id,
            (unsigned int)payload[10], (unsigned int)payload[11], (unsigned int)payload[12],
            (unsigned int)payload[13], (unsigned int)payload[14], (unsigned int)payload[15],
            (unsigned int)payload[16], (unsigned int)payload[17]);
        }
        else
        {
            Hal_Uart_Printf("LOG index=%u seq=%u id=%s time=20%u-%u-%u %u:%u:%u valid=%u origin=%u gen=%u\r\n",
            (unsigned int)payload[1], (unsigned int)Comm_Protocol_ReadUint16(payload + 18), student_id, (unsigned int)payload[10],
            (unsigned int)payload[11], (unsigned int)payload[12], (unsigned int)payload[13], (unsigned int)payload[14],
            (unsigned int)payload[15], (unsigned int)payload[16], (unsigned int)payload[17],
            (unsigned int)Comm_Protocol_ReadUint16(payload + 2));
        }
    }
    else if (opcode != ATT_TIME && opcode != ATT_MODE)
    {
        if (opcode == ATT_SCAN && payload[0] == ATT_OK)
        {
            const char *heading;
            if (g_last_scan_mode == 1)
            {
                heading = "REGISTER OK";
            }
            else if (g_last_scan_mode == 2)
            {
                heading = "REMOVE OK";
            }
            else if (g_last_scan_mode == 0)
            {
                heading = "ATTENDANCE OK";
            }
            else
            {
                heading = "CARD PROCESSED";
            }
            if (payload_length == 44)
            {
                osal_memcpy(student_id, payload + 15, 12);
                student_id[12] = 0;
                osal_memcpy(student_name, payload + 27, 16);
                student_name[16] = 0;
                App_Ui_Message(heading, student_id);
                Hal_Uart_Printf("CARD id=%s name=%s\r\n", student_id, student_name);
            }
            else
            {
                App_Ui_Message(heading, "CARD PROCESSED");
            }
        }
        else
        {
            const char *heading = App_Coordinator_Result_Text(payload[0]);
            if (opcode == ATT_SCAN)
            {
                if (g_last_scan_mode == 1 && payload[0] == ATT_EXISTS)
                {
                    heading = "CARD ALREADY REGISTERED";
                }
                else if (g_last_scan_mode == 2 && payload[0] == ATT_UNKNOWN)
                {
                    heading = "CARD NOT REGISTERED";
                }
                else if (g_last_scan_mode == 0 && payload[0] == ATT_UNKNOWN)
                {
                    heading = "ATTENDANCE UNREGISTERED";
                }
            }
            App_Ui_Message(heading, opcode == ATT_SCAN ? "CARD PROCESSED" : "DATABASE COMMAND");
        }
        Hal_Buzzer_Beep(payload[0] ? 180 : 60);
    }
    if (g_list_waiting_for_response && opcode == g_list_command_type)
    {
        g_list_waiting_for_response = 0;
        if ((payload[0] && payload[0] != ATT_UNKNOWN) || (opcode == ATT_LOG && payload[0] == ATT_UNKNOWN))
        {
            g_list_command_type = 0;
            Hal_Uart_Print("END\r\n");
        }
        else
        {
            ++g_list_command_index;
        }
    }
}

static void App_Coordinator_Set_Mode(uint8 new_mode, const uint8 *identity)
{
    g_attendance_mode = new_mode;
    g_mode_timeout_seconds = new_mode ? 30 : 0;
    osal_memset(g_registered_identity, 0, sizeof(g_registered_identity));
    if (identity)
    {
        osal_memcpy(g_registered_identity, identity, 28);
    }
    if (new_mode == 1)
    {
        App_Ui_Message("REGISTER MODE", "SCAN WITHIN 30 SEC");
    }
    else if (new_mode == 2)
    {
        App_Ui_Message("REMOVE MODE", "SCAN WITHIN 30 SEC");
    }
    else
    {
        App_Ui_Message("ATTENDANCE MODE", "SCAN REGISTERED CARD");
    }
    Hal_Uart_Printf("MODE value=%u timeout=%u\r\n", (unsigned int)g_attendance_mode,
    (unsigned int)g_mode_timeout_seconds);
}

static void App_Coordinator_Time_Payload(uint8 *payload)
{
    payload[0] = g_rtc_time.year;
    payload[1] = g_rtc_time.month;
    payload[2] = g_rtc_time.day;
    payload[3] = g_rtc_time.hour;
    payload[4] = g_rtc_time.minute;
    payload[5] = g_rtc_time.second;
}

static uint8 App_Coordinator_Set_Time(const uint8 *payload)
{
    rtc_time_t new_time;
    uint16 elapsed_days = 6;
    uint8 index;
    static const uint8 month_days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (payload[0] > 99 || payload[1] < 1 || payload[1] > 12 || payload[2] < 1 || payload[2] > 31)
    {
        return I2C_PARAM;
    }
    new_time.year = payload[0];
    new_time.month = payload[1];
    new_time.day = payload[2];
    new_time.hour = payload[3];
    new_time.minute = payload[4];
    new_time.second = payload[5];
    new_time.weekday = 0;
    for (index = 0; index < new_time.year; index++)
    {
        elapsed_days += index % 4 ? 365 : 366;
    }
    for (index = 1; index < new_time.month; index++)
    {
        elapsed_days += month_days[index - 1];
        if (index == 2 && new_time.year % 4 == 0)
        {
            ++elapsed_days;
        }
    }
    new_time.weekday = (elapsed_days + new_time.day - 1) % 7;
    /* RTC������������/�����飻д��ǰ���޸ĵ�ǰ��ʾֵ�� */
    return Hal_Rtc_Set_Time(&new_time);
}

static void App_Coordinator_Request(uint8 opcode, const uint8 *payload, uint8 payload_length)
{
    /* ͬһ��ڷ��񴮿ں�ˢ�����ն�ִ�б�������Э������Զ������ */
    uint8 result[4] = {ATT_OFFLINE, 255, 0, 0};
    if (g_pending_frame_length)
    {
        result[0] = ATT_BUSY;
        App_Coordinator_Show_Result(opcode, result, 4);
        return;
    }
    if (g_terminal_age_seconds > 15 || !g_network_joined)
    {
        App_Coordinator_Show_Result(opcode, result, 4);
        return;
    }
    g_pending_frame_length = Comm_Protocol_PackFrame(g_pending_frame, sizeof(g_pending_frame), opcode, g_session_id, ++g_transaction_counter, payload, payload_length);
    if (g_pending_frame_length == 0)
    {
        result[0] = ATT_PARAM;
        App_Coordinator_Show_Result(opcode, result, 4);
        return;
    }

    g_pending_command_type = opcode;
    g_retry_count = 1;
    osal_start_timerEx(SampleApp_TaskID, SAMPLEAPP_RETRY_EVT, SAMPLEAPP_RETRY_INTERVAL);
    Comm_Unicast_Send(g_terminal_short_address, g_pending_frame, g_pending_frame_length);
}

/* ==================== ������Ϣ���� ==================== */
void App_Coordinator_Unicast_Receive(uint16 source, uint8 *raw, uint8 frame_length)
{
    comm_frame_t frame;
    uint8 opcode, payload_length;
    const uint8 *payload;
    uint16 session, transaction;
    if (!g_peripherals_ready || Comm_Protocol_UnpackFrame(&frame, raw, frame_length) != COMM_OK)
    {
        return;
    }
    opcode = frame.opcode;
    payload_length = frame.data_len;
    payload = frame.data;
    session = frame.session;
    transaction = frame.transaction;
    if (opcode == ATT_HELLO && payload_length == 7 && source != 0 && source < 0xFFF8 && payload[1] <= 8 && payload[5] <= 2 && payload[6] <= 30)
    {
        /* ����Ŀһ̨�նˣ������ڼ䲻������һ�̵�ַ��ռ�� */
        if (g_terminal_short_address != 0xFFFF && source != g_terminal_short_address && g_terminal_age_seconds <= 15)
        {
            return;
        }
        if (g_terminal_session_id != session || g_terminal_short_address != source || g_terminal_age_seconds > 15 || payload[4] != 0)
        {
            g_terminal_session_id = session;
            g_time_sync_pending = 1;
            Hal_Uart_Printf("[LINK] reader=%x sessionId=%x\r\n", (unsigned int)source, (unsigned int)session);
        }
        g_terminal_short_address = source;
        g_terminal_age_seconds = 0;
        g_database_status = payload[0];
        g_database_user_count = payload[1];
        if (!g_mode_cancel_deferred &&
        (!g_pending_frame_length || (g_pending_command_type != ATT_MODE && g_pending_command_type != ATT_SCAN)))
        {
            g_attendance_mode = payload[5];
            g_mode_timeout_seconds = payload[6];
        }
        App_Coordinator_Send(g_terminal_short_address, ATT_HELLO, g_session_id, 0, NULL, 0);
        return;
    }
    if (source != g_terminal_short_address || g_terminal_age_seconds > 15)
    {
        return;
    }
    g_terminal_age_seconds = 0;
    if (opcode == ATT_EVENT && (payload_length == 6 || payload_length == 46 || payload_length == 7 || payload_length == 47) && session == g_terminal_session_id)
    {
        /* �¼��ش�ֻ��ʾһ�Σ��������߼�¼�Դ��ն���־��ȡ�� */
        static uint16 event_session, event_tx;
        App_Coordinator_Send(source, ATT_EVENT | ATT_REPLY, session, transaction, NULL, 0);
        if (event_session != session || event_tx != transaction)
        {
            event_session = session;
            event_tx = transaction;
            if (payload_length == 7 || payload_length == 47)
            {
                g_last_scan_mode = payload[payload_length - 1];
                App_Coordinator_Show_Result(payload[0], payload + 1, payload_length - 3);
                g_database_user_count = payload[payload_length - 2];
            }
            else
            {
                g_last_scan_mode = 3;
                App_Coordinator_Show_Result(payload[0], payload + 1, payload_length - 2);
                g_database_user_count = payload[payload_length - 1];
            }
        }
        return;
    }
    if ((opcode & ATT_REPLY) && g_pending_frame_length && opcode == (g_pending_command_type | ATT_REPLY) &&
    session == g_session_id && transaction == Comm_Protocol_ReadUint16(g_pending_frame + 6) && payload_length >= 4)
    {
        if (payload[0] == ATT_BUSY)
        {
            return;
        }
        g_pending_frame_length = 0;
        osal_stop_timerEx(SampleApp_TaskID, SAMPLEAPP_RETRY_EVT);
        if (g_pending_command_type == ATT_SCAN)
        {
            /* ʹ�ñ������ִ��ģʽ�����ܱ�ͬʱ�յ����ն��¼����ǡ� */
            if ((payload_length == 5 || payload_length == 45) && payload[payload_length - 1] <= 2)
            {
                g_last_scan_mode = payload[payload_length - 1];
            }
            else
            {
                g_last_scan_mode = g_pending_frame[ATT_FRAME_DATA_OFFSET];
            }
        }
        if (g_pending_command_type == ATT_SCAN && payload[0] == ATT_OK)
        {
            rtc_time_t captured_time;
            uint8 record_status;
            const uint8 *scan_payload = g_pending_frame + ATT_FRAME_DATA_OFFSET;

            captured_time.year = scan_payload[40];
            captured_time.month = scan_payload[41];
            captured_time.day = scan_payload[42];
            captured_time.hour = scan_payload[43];
            captured_time.minute = scan_payload[44];
            captured_time.second = scan_payload[45];
            captured_time.weekday = 0;
            record_status = App_Host_Store_Record(g_last_scan_mode, scan_payload + 2, scan_payload[1], &captured_time,
            scan_payload[46] ? 0 : RTC_TIME_INVALID);
            if (record_status != ATT_OK)
            {
                Hal_Uart_Printf("[HOST] statistics status=%u\r\n", (unsigned int)record_status);
            }
        }
        App_Coordinator_Show_Result(g_pending_command_type, payload, payload_length);
    }
}

/* ==================== ˢ���ɼ��뿼������ ==================== */
void App_Coordinator_Card_Process(void)
{
    uint8 uid[10], uid_length, scan_payload[ATT_SCAN_PAYLOAD_LENGTH];
    char uid_text[21];
    if (!g_reader_ready)
    {
        return;
    }
    if (!Hal_Rc522_Read_Uid(uid, &uid_length))
    {
        if (g_rc522_last_error == RC522_NO_RESPONSE)
        {
            g_card_held_near_reader = 0;
        }
        return;
    }
    if (g_card_held_near_reader)
    {
        return;
    }
    g_card_held_near_reader = 1;
    g_last_card_uid_length = uid_length;
    osal_memcpy(g_last_card_uid, uid, uid_length);
    App_Coordinator_Hex(uid, uid_length, uid_text);
    Hal_Uart_Printf("[CARD] uid=%s\r\n", uid_text);
    if (g_pending_frame_length || App_Host_Store_Status() == ATT_BUSY)
    {
        App_Ui_Message("BUSY", "REMOVE AND RESCAN");
        return;
    }
    osal_memset(scan_payload, 0, sizeof(scan_payload));
    scan_payload[0] = g_attendance_mode;
    g_last_scan_mode = g_attendance_mode;
    scan_payload[1] = uid_length;
    osal_memcpy(scan_payload + 2, uid, uid_length);
    osal_memcpy(scan_payload + 12, g_registered_identity, 28);
    g_rtc_read_status = Hal_Rtc_Read_Time(&g_rtc_time);
    App_Coordinator_Time_Payload(scan_payload + 40);
    scan_payload[46] = g_rtc_read_status == 0;
    scan_payload[47] = 0;
    App_Coordinator_Set_Mode(0, NULL);
    App_Coordinator_Request(ATT_SCAN, scan_payload, ATT_SCAN_PAYLOAD_LENGTH);
}

static void App_Coordinator_Network_Status(uint8 line)
{
    if (line == 0)
    {
        Hal_Uart_Printf("[STATUS] role=%u state=%u PAN=%x CH=%u short=%x terminalShortAddress=%x\r\n",
        (unsigned int)0, (unsigned int)SampleApp_NwkState, (unsigned int)_NIB.nwkPanId,
        (unsigned int)_NIB.nwkLogicalChannel, (unsigned int)NLME_GetShortAddr(),
        (unsigned int)g_terminal_short_address);
    }
    else
    {
        Hal_Uart_Printf("[STATUS] db=%u users=%u rtc=%u oled=%u drop=%u\r\n", (unsigned int)g_database_status,
        (unsigned int)g_database_user_count, (unsigned int)g_rtc_read_status, (unsigned int)App_Ui_Error(),
        (unsigned int)g_uart_dropped);
    }
}

static void App_Coordinator_Begin_Mode(uint8 new_mode, const uint8 *identity)
{
    uint8 payload[ATT_MODE_PAYLOAD_LENGTH];
    if (new_mode == 0)
    {
        /* �˳����ڱ�����Ч������һ��ģʽ�����Ե�Ӧ���ø������񸲸����� */
        App_Coordinator_Set_Mode(0, NULL);
        if (g_pending_frame_length && g_pending_command_type == ATT_MODE)
        {
            g_pending_frame_length = 0;
            osal_stop_timerEx(SampleApp_TaskID, SAMPLEAPP_RETRY_EVT);
            osal_clear_event(SampleApp_TaskID, SAMPLEAPP_RETRY_EVT);
        }
    }
    if (g_pending_frame_length)
    {
        if (new_mode == 0)
        {
            g_mode_cancel_deferred = 1;
        }
        else
        {
            Hal_Uart_Print("ERR BUSY\r\n");
        }
        return;
    }
    g_mode_cancel_deferred = 0;
    if (new_mode != 0)
    {
        App_Coordinator_Set_Mode(new_mode, identity);
    }
    payload[0] = new_mode;
    osal_memset(payload + 1, 0, 28);
    if (identity)
    {
        osal_memcpy(payload + 1, identity, 28);
    }
    if (new_mode == 0 && (!g_network_joined || g_terminal_age_seconds > SAMPLEAPP_PEER_TIMEOUT_SECONDS))
    {
        g_mode_cancel_deferred = 1;
        return;
    }
    App_Coordinator_Request(ATT_MODE, payload, ATT_MODE_PAYLOAD_LENGTH);
}

static uint8 App_Coordinator_Parse_Index(const char *text, uint8 limit, uint8 *output_value)
{
    uint16 number = 0;
    if (!text || !*text || !output_value)
    {
        return 0;
    }
    while (*text)
    {
        uint8 digit;
        if (*text < '0' || *text > '9')
        {
            return 0;
        }
        digit = (uint8)(*text++ - '0');
        if (digit >= limit || number > ((uint16)limit - 1 - digit) / 10)
        {
            return 0;
        }
        number = number * 10 + digit;
    }
    *output_value = (uint8)number;
    return 1;
}

static uint8 App_Coordinator_Parse_Identity(char *student_id, char *student_name, uint8 *identity)
{
    uint8 index, name_length;
    if (!student_id || !student_name || !identity || strlen(student_id) != 12)
    {
        return 0;
    }
    name_length = (uint8)strlen(student_name);
    if (!name_length || name_length > 15)
    {
        return 0;
    }
    for (index = 0; index < 12; index++)
    {
        if (student_id[index] < '0' || student_id[index] > '9')
        {
            return 0;
        }
    }
    osal_memset(identity, 0, 28);
    osal_memcpy(identity, student_id, 12);
    osal_memcpy(identity + 12, student_name, name_length);
    return 1;
}

static uint8 App_Coordinator_Hex_Digit(char character)
{
    if (character >= '0' && character <= '9')
    {
        return character - '0';
    }
    if (character >= 'A' && character <= 'F')
    {
        return character - 'A' + 10;
    }
    if (character >= 'a' && character <= 'f')
    {
        return character - 'a' + 10;
    }
    return 255;
}

static uint8 App_Coordinator_Parse_Uid(const char *text, uint8 *uid)
{
    uint8 index, text_length, high_nibble, low_nibble;
    if (!text || !uid)
    {
        return 0;
    }
    text_length = (uint8)strlen(text);
    if (text_length != 8 && text_length != 14 && text_length != 20)
    {
        return 0;
    }
    osal_memset(uid, 0, 11);
    uid[0] = text_length / 2;
    for (index = 0; index < text_length / 2; index++)
    {
        high_nibble = App_Coordinator_Hex_Digit(text[index * 2]);
        low_nibble = App_Coordinator_Hex_Digit(text[index * 2 + 1]);
        if (high_nibble == 255 || low_nibble == 255)
        {
            return 0;
        }
        uid[index + 1] = (high_nibble << 4) | low_nibble;
    }
    return 1;
}

void App_Coordinator_Console_Process(void)
{
    uint8 index;

    /* ESP��TX���ճ�127�ֽڣ�ÿ��ֻ���һ�У���Ԥ��һ��������ѯ��Ӧ�� */
    if (Hal_Uart_Free() < 120)
    {
        return;
    }
    if (g_console_output_step)
    {
        /* ��;Ӧ����Ҫ���пռ䣻����/״̬�ȴ�����������������ѯ��������� */
        if (g_pending_frame_length)
        {
            return;
        }
        switch (g_console_output_step++)
        {
        case 1:
            Hal_Uart_Print("#HELP #STATUS #LIST [slot] #LOG [index|CSV]\r\n");
            break;
        case 2:
            Hal_Uart_Print("KEY1=REG KEY2=REMOVE SAME/BOTH=EXIT\r\n");
            break;
        case 3:
            Hal_Uart_Print("#HELP TIME / #HELP DB : maintenance\r\n");
            g_console_output_step = 0;
            break;
        case 10:
            Hal_Uart_Print("#TIME : clock; #TIME YYMMDDhhmmss : set (CO)\r\n");
            break;
        case 11:
            Hal_Uart_Print("#TIME SYNC : coordinator -> terminal\r\n");
            g_console_output_step = 0;
            break;
        case 20:
            Hal_Uart_Print("#DB STATUS | #DB FIND UIDhex\r\n");
            break;
        case 21:
            Hal_Uart_Print("#DB SET slot 12digitID Name | #DB DEL slot\r\n");
            break;
        case 22:
            Hal_Uart_Print("#DB REG [12digitID Name] | #DB UNREG | #DB CANCEL\r\n");
            break;
        case 23:
            Hal_Uart_Print("#DB INIT CONFIRM : erase users/logs\r\n");
            break;
        case 24:
            Hal_Uart_Print("#DB UID | #DB BEEP | #DB STATS (CO)\r\n");
            break;
        case 25:
            Hal_Uart_Print("#DB STATS RESET CONFIRM : reset CO statistics\r\n");
            break;
        case 26:
            Hal_Uart_Print("Slots 0..7; UID 8/14/20 hex; Name ASCII 1..15\r\n");
            g_console_output_step = 0;
            break;
        case 40:
            App_Coordinator_Network_Status(0);
            break;
        case 41:
            App_Coordinator_Network_Status(1);
            g_console_output_step = 0;
            break;
        default:
            g_console_output_step = 0;
            break;
        }
        return;
    }
    /* һ���ظ���������������һ�ۣ�����ѭ���������������ű��� */
    if (g_list_command_type && !g_list_waiting_for_response && !g_pending_frame_length)
    {
        if (g_list_command_index >= (g_list_command_type == ATT_USER ? 8 : 10))
        {
            g_list_command_type = 0;
            Hal_Uart_Print("END\r\n");
            return;
        }
        index = g_list_command_index;
        g_list_waiting_for_response = 1;
        App_Coordinator_Request(g_list_command_type, &index, 1);
    }
}

/* ==================== ������ʱ�ӡ���ʱ������ά�� ==================== */
void App_Coordinator_Second_Process(void)
{
    static uint8 seconds;
    uint8 payload[ATT_TIME_PAYLOAD_LENGTH];

    if (g_terminal_age_seconds < 255)
    {
        ++g_terminal_age_seconds;
    }
    if (g_terminal_age_seconds > SAMPLEAPP_PEER_TIMEOUT_SECONDS)
    {
        g_database_status = ATT_OFFLINE;
        g_database_user_count = 0;
    }
    if (g_mode_timeout_seconds != 0)
    {
        --g_mode_timeout_seconds;
        if (g_mode_timeout_seconds == 0)
        {
            App_Coordinator_Set_Mode(0, NULL);
        }
    }

    if (g_peripherals_ready)
    {
        g_rtc_read_status = Hal_Rtc_Read_Time(&g_rtc_time);
        App_Ui_Time(&g_rtc_time, g_rtc_read_status);
        App_Ui_Second();
    }

    if (g_network_joined && g_terminal_age_seconds <= SAMPLEAPP_PEER_TIMEOUT_SECONDS)
    {
        HalLedSet(HAL_LED_1, HAL_LED_MODE_ON);
    }
    else
    {
        HalLedSet(HAL_LED_1, HAL_LED_MODE_TOGGLE);
    }

    ++seconds;
    if (g_mode_cancel_deferred && g_pending_frame_length == 0 && g_network_joined &&
    g_terminal_age_seconds <= SAMPLEAPP_PEER_TIMEOUT_SECONDS)
    {
        App_Coordinator_Begin_Mode(0, NULL);
    }

    if (g_rtc_read_status == 0 && g_pending_frame_length == 0 &&
    g_terminal_age_seconds <= SAMPLEAPP_PEER_TIMEOUT_SECONDS &&
    (g_time_sync_pending || seconds % SAMPLEAPP_TIME_SYNC_INTERVAL_SECONDS == 0))
    {
        g_time_sync_pending = 0;
        App_Coordinator_Time_Payload(payload);
        App_Coordinator_Request(ATT_TIME, payload, ATT_TIME_PAYLOAD_LENGTH);
    }
    if (seconds == 240)
    {
        seconds = 0;
    }
}
