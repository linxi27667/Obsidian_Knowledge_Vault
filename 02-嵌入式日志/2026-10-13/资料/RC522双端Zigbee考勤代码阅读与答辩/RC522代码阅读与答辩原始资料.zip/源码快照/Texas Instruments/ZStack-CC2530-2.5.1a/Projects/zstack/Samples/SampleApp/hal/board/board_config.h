#ifndef GAOCHANG_BOARD_CONFIG_H
#define GAOCHANG_BOARD_CONFIG_H

#include "hal_types.h"
#include <ioCC2530.h>

/* ������ֻ�����ļ���LED/������SDK hal_board_cfg.h���䣬��������ֱ�����á�
 * SDK������Components/hal/target/CC2530EB/hal_led.c��hal_key.c��
 * P0.2/RX��P0.3/TX=USB���ڣ�P0.4/TX��P0.5/RX=ESP UART1��
 * P1.2/P1.1��I2C����OLED��RX8010��AT24C02/AT24C08��
 */

/* ������Դ��SCH_ZIGBEE-RC522_2026-09-21.pdf ��1ҳ�� */
#define BOARD_LED_PIN P1_0
#define BOARD_LED_MASK BV(0)
#define BOARD_LED_DIR P1DIR
#define BOARD_LED_ACTIVE_LEVEL 1
#define BOARD_BUZZER_PIN P0_0
#define BOARD_BUZZER_MASK BV(0)
#define BOARD_KEY0_PIN P0_1
#define BOARD_KEY0_MASK BV(1)
#define BOARD_KEY1_PIN P2_0
#define BOARD_KEY1_MASK BV(0)
#define BOARD_KEY_ACTIVE_LEVEL 0
#define BOARD_PULLUP_P0_P2 (BV(5) | BV(7))
#define BOARD_UNUSED_ESP_MASK (BV(4) | BV(5) | BV(6))
#define BOARD_I2C_SCL_PIN P1_2
#define BOARD_I2C_SDA_PIN P1_1
#define BOARD_I2C_SCL_MASK BV(2)
#define BOARD_I2C_SDA_MASK BV(1)
#define BOARD_RC522_CS_PIN P1_4
#define BOARD_RC522_CLK_PIN P1_5
#define BOARD_RC522_MOSI_PIN P1_6
#define BOARD_RC522_MISO_PIN P1_7
#define BOARD_RC522_CS_MASK BV(4)
#define BOARD_RC522_CLK_MASK BV(5)
#define BOARD_RC522_MOSI_MASK BV(6)
#define BOARD_RC522_MISO_MASK BV(7)
/* RST/REST ����δ֤ʵ��ͨ�������� P1.3��ʹ��оƬ����λ�� */
#define BOARD_RC522_HW_RESET_CONNECTED 0
/* UART0 Alt1��SDK UART������ʼ����UART1 Alt1��ESP������ʼ���� */
#define BOARD_DEBUG_UART_PORT 0
#define BOARD_DEBUG_UART_RX_PIN P0_2
#define BOARD_DEBUG_UART_TX_PIN P0_3
#define BOARD_DEBUG_UART_RX_MASK BV(2)
#define BOARD_DEBUG_UART_TX_MASK BV(3)
#define BOARD_ESP_UART_PORT 1
#define BOARD_ESP_UART_PERCFG_MASK BV(1)
#define BOARD_ESP_UART_TX_PIN P0_4
#define BOARD_ESP_UART_RX_PIN P0_5
#define BOARD_ESP_UART_TX_MASK BV(4)
#define BOARD_ESP_UART_RX_MASK BV(5)
#define BOARD_ESP_RESET_PIN P0_6
#define BOARD_ESP_RESET_MASK BV(6)
#define BOARD_ESP_ENABLED 0

/* ��д�رյ�ƽ��������������ʼ�����壻���������������š� */
#define BOARD_EARLY_INIT()                                                                         \
  do                                                                                               \
  {                                                                                                \
    BOARD_BUZZER_PIN = 0;                                                                          \
    P0SEL &= ~BOARD_BUZZER_MASK;                                                                   \
    P0DIR |= BOARD_BUZZER_MASK;                                                                    \
    BOARD_LED_PIN = 0;                                                                             \
    P1SEL &= ~BOARD_LED_MASK;                                                                      \
    P1DIR |= BOARD_LED_MASK;                                                                       \
    P0SEL &= ~(BOARD_KEY0_MASK | BOARD_UNUSED_ESP_MASK);                                           \
    P0DIR &= ~(BOARD_KEY0_MASK | BOARD_UNUSED_ESP_MASK);                                           \
    P0INP &= ~BOARD_KEY0_MASK;                                                                     \
    P2SEL &= ~BOARD_KEY1_MASK;                                                                     \
    P2DIR &= ~BOARD_KEY1_MASK;                                                                     \
    P2INP &= ~(BOARD_KEY1_MASK | BOARD_PULLUP_P0_P2);                                              \
  } while (0)

#endif
