#ifndef HAL_DELAY_H
#define HAL_DELAY_H

#include "ZComDef.h"

void Hal_Delay_Us(uint16 us);
void Hal_Delay_Ms(uint16 ms);

#endif
