/**
 * @file comm_protocol.c
 * @brief �� Common �ġ�У�顢�������֤�������˳���������п���֡��
 */
#include "comm_protocol.h"
#include "OSAL.h"

/* ==================== С���ֶ� ==================== */
uint16 Comm_Protocol_ReadUint16(const uint8 *data)
{
    return (uint16)data[0] | ((uint16)data[1] << 8);
}

void Comm_Protocol_WriteUint16(uint8 *data, uint16 value)
{
    data[0] = (uint8)value;
    data[1] = (uint8)(value >> 8);
}

/* ==================== ����У�� ==================== */
uint16 Comm_Protocol_CalcChecksum(const uint8 *data, uint16 len)
{
    uint16 crc = 0xFFFF;
    uint8 bit;

    while (len > 0)
    {
        crc ^= (uint16)*data++ << 8;
        --len;
        for (bit = 0; bit < 8; ++bit)
        {
            if (crc & 0x8000)
            {
                crc = (uint16)((crc << 1) ^ 0x1021);
            }
            else
            {
                crc = (uint16)(crc << 1);
            }
        }
    }
    return crc;
}

/* ==================== ����ǰ��� ==================== */
uint8 Comm_Protocol_PackFrame(uint8 *buf, uint8 buf_len, uint8 opcode,
                            uint16 session, uint16 transaction,
                            const uint8 *data, uint8 data_len)
{
    uint8 frame_len;
    uint16 checksum;

    /* ��1�����������������ȼ�����ݳ��ȣ����ⳤ����ӻ��ơ� */
    if (buf == NULL || data_len > COMM_FRAME_MAX_DATA_LEN)
    {
        return 0;
    }
    if (data == NULL && data_len > 0)
    {
        return 0;
    }
    frame_len = data_len + COMM_FRAME_MIN_LEN;
    if (frame_len > buf_len)
    {
        return 0;
    }

    /* ��2���������� ATT2 ���ֽ�λ����дͷ���� */
    buf[0] = COMM_FRAME_HEADER;
    buf[1] = COMM_FRAME_VERSION;
    buf[ATT_FRAME_OPCODE_OFFSET] = opcode;
    buf[ATT_FRAME_LENGTH_OFFSET] = data_len;
    Comm_Protocol_WriteUint16(buf + ATT_FRAME_SESSION_OFFSET, session);
    Comm_Protocol_WriteUint16(buf + ATT_FRAME_TRANSACTION_OFFSET, transaction);

    /* ��3��������ҵ�����ݡ� */
    if (data_len > 0)
    {
        osal_memcpy(buf + ATT_FRAME_DATA_OFFSET, data, data_len);
    }

    /* ��4����CRC ��������֮�󣬷��ط��ͳ��ȡ� */
    checksum = Comm_Protocol_CalcChecksum(buf, ATT_FRAME_DATA_OFFSET + data_len);
    Comm_Protocol_WriteUint16(buf + ATT_FRAME_DATA_OFFSET + data_len, checksum);
    return frame_len;
}

/* ==================== ���պ���֤ ==================== */
uint8 Comm_Protocol_ValidateFrame(const uint8 *raw, uint8 raw_len)
{
    uint8 data_len;
    uint16 checksum;

    if (raw == NULL)
    {
        return COMM_ERR_PARAM;
    }
    if (raw_len < COMM_FRAME_MIN_LEN || raw_len > COMM_FRAME_MAX_LEN)
    {
        return COMM_ERR_LEN;
    }
    if (raw[0] != COMM_FRAME_HEADER || raw[1] != COMM_FRAME_VERSION)
    {
        return COMM_ERR_FAIL;
    }
    data_len = raw[ATT_FRAME_LENGTH_OFFSET];
    if (data_len > COMM_FRAME_MAX_DATA_LEN || raw_len != data_len + COMM_FRAME_MIN_LEN)
    {
        return COMM_ERR_LEN;
    }
    checksum = Comm_Protocol_CalcChecksum(raw, raw_len - 2);
    if (checksum != Comm_Protocol_ReadUint16(raw + raw_len - 2))
    {
        return COMM_ERR_CRC;
    }
    return COMM_OK;
}

/* ==================== �������ɫҵ�� ==================== */
uint8 Comm_Protocol_UnpackFrame(comm_frame_t *frame, const uint8 *raw, uint8 raw_len)
{
    uint8 result;

    if (frame == NULL)
    {
        return COMM_ERR_PARAM;
    }
    result = Comm_Protocol_ValidateFrame(raw, raw_len);
    if (result != COMM_OK)
    {
        return result;
    }

    /* ��֤��ɲŹ�������ָ�룬ҵ�����ظ����֡ͷ�� CRC�� */
    frame->opcode = raw[ATT_FRAME_OPCODE_OFFSET];
    frame->data_len = raw[ATT_FRAME_LENGTH_OFFSET];
    frame->session = Comm_Protocol_ReadUint16(raw + ATT_FRAME_SESSION_OFFSET);
    frame->transaction = Comm_Protocol_ReadUint16(raw + ATT_FRAME_TRANSACTION_OFFSET);
    frame->data = raw + ATT_FRAME_DATA_OFFSET;
    return COMM_OK;
}
