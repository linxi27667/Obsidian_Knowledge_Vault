#include "OSAL.h"
#include "OnBoard.h"
#include "board_config.h"
#include "hal_rc522.h"

#define REG_COMMAND 0x01
#define REG_COM_IRQ 0x04
#define REG_ERROR 0x06
#define REG_FIFO_DATA 0x09
#define REG_FIFO_LEVEL 0x0A
#define REG_CONTROL 0x0C
#define REG_BIT_FRAMING 0x0D
#define REG_MODE 0x11
#define REG_TX_MODE 0x12
#define REG_RX_MODE 0x13
#define REG_TX_CONTROL 0x14
#define REG_TX_ASK 0x15
#define REG_MOD_WIDTH 0x24
#define REG_T_MODE 0x2A
#define REG_T_PRESCALER 0x2B
#define REG_T_RELOAD_H 0x2C
#define REG_T_RELOAD_L 0x2D
#define REG_VERSION 0x37
#define CMD_IDLE 0x00
#define CMD_TRANSCEIVE 0x0C
#define CMD_SOFT_RESET 0x0F
#define CMD_POWER_DOWN 0x10
#define IRQ_TIMER 0x01
#define IRQ_RX 0x20
#define IRQ_CLEAR_ALL 0x7F
#define ERROR_RX_MASK 0x1B
#define FIFO_FLUSH 0x80
#define START_SEND 0x80
#define LAST_BITS_MASK 0x07
#define ANTENNA_ENABLE 0x03
#define PICC_WUPA 0x52
#define PICC_CASCADE_TAG 0x88
#define PICC_SELECT_CL1 0x93
#define PICC_SELECT_CL2 0x95
#define PICC_SELECT_CL3 0x97
#define PICC_ANTICOLL_NVB 0x20
#define PICC_SELECT_NVB 0x70
#define PICC_SAK_CASCADE 0x04
#define PICC_HALT 0x50
#define RC522_POLL_LIMIT 400
#define RC522_SPI_HALF_US 1
#define RC522_POLL_US 10
static uint8 g_ready;
uint8 g_rc522_last_error;
uint8 g_rc522_version;

static uint8 Hal_Rc522_Spi_Byte(uint8 value)
{
    uint8 i, result = 0;
    for (i = 0; i < 8; ++i)
    {
        BOARD_RC522_MOSI_PIN = (value & 0x80) != 0;
        MicroWait(RC522_SPI_HALF_US);
        BOARD_RC522_CLK_PIN = 1;
        MicroWait(RC522_SPI_HALF_US);
        result = (result << 1) | (BOARD_RC522_MISO_PIN ? 1 : 0);
        BOARD_RC522_CLK_PIN = 0;
        value <<= 1;
    }
    return result;
}
uint8 Hal_Rc522_Read_Reg(uint8 reg)
{
    uint8 value;
    BOARD_RC522_CS_PIN = 0;
    Hal_Rc522_Spi_Byte(((reg << 1) & 0x7E) | 0x80);
    value = Hal_Rc522_Spi_Byte(0);
    BOARD_RC522_CS_PIN = 1;
    return value;
}
void Hal_Rc522_Write_Reg(uint8 reg, uint8 value)
{
    BOARD_RC522_CS_PIN = 0;
    Hal_Rc522_Spi_Byte((reg << 1) & 0x7E);
    Hal_Rc522_Spi_Byte(value);
    BOARD_RC522_CS_PIN = 1;
}
static bool Hal_Rc522_Fail(uint8 error)
{
    g_rc522_last_error = error;
    return FALSE;
}
bool Hal_Rc522_Reset(void)
{
    uint16 n;
    g_ready = 0;
    /* RST����δȷ�ϣ�����Ϊ���룬��ͨ���Ѻ˶Ե�SPIִ������λ�� */
    Hal_Rc522_Write_Reg(REG_COMMAND, CMD_SOFT_RESET);
    for (n = 0; n < RC522_POLL_LIMIT; ++n)
    {
        MicroWait(RC522_POLL_US);
        if ((Hal_Rc522_Read_Reg(REG_COMMAND) & (CMD_POWER_DOWN | CMD_SOFT_RESET)) == CMD_IDLE)
        {
            g_rc522_last_error = RC522_OK;
            return TRUE;
        }
    }
    return Hal_Rc522_Fail(RC522_NO_RESPONSE);
}
bool Hal_Rc522_Init(void)
{
    uint8 mask = BOARD_RC522_CS_MASK | BOARD_RC522_CLK_MASK | BOARD_RC522_MOSI_MASK;
    BOARD_RC522_CS_PIN = 1;
    BOARD_RC522_CLK_PIN = 0;
    BOARD_RC522_MOSI_PIN = 0;
    P1SEL &= ~(mask | BOARD_RC522_MISO_MASK);
    P1DIR &= ~BOARD_RC522_MISO_MASK;
    P1DIR |= mask;
    g_ready = 0;
    g_rc522_version = Hal_Rc522_Read_Reg(REG_VERSION);
    if (g_rc522_version != 0x91 && g_rc522_version != 0x92 && g_rc522_version != 0x88)
    {
        return Hal_Rc522_Fail(RC522_NOT_READY);
    }
    if (!Hal_Rc522_Reset())
    {
        return FALSE;
    }
    Hal_Rc522_Write_Reg(REG_TX_MODE, 0);
    Hal_Rc522_Write_Reg(REG_RX_MODE, 0);
    Hal_Rc522_Write_Reg(REG_MOD_WIDTH, 0x26);
    /* 13.56MHz/(2*169+1)������200Լ5ms��ͬʱ��������������ѯ�� */
    Hal_Rc522_Write_Reg(REG_T_MODE, 0x80);
    Hal_Rc522_Write_Reg(REG_T_PRESCALER, 0xA9);
    Hal_Rc522_Write_Reg(REG_T_RELOAD_H, 0);
    Hal_Rc522_Write_Reg(REG_T_RELOAD_L, 200);
    Hal_Rc522_Write_Reg(REG_TX_ASK, 0x40);
    Hal_Rc522_Write_Reg(REG_MODE, 0x3D);
    Hal_Rc522_Write_Reg(REG_TX_CONTROL, Hal_Rc522_Read_Reg(REG_TX_CONTROL) | ANTENNA_ENABLE);
    g_ready = 1;
    g_rc522_last_error = RC522_OK;
    return TRUE;
}
static void Hal_Rc522_Crc_A(const uint8 *data, uint8 len, uint8 *result)
{
    uint16 crc = 0x6363;
    uint8 b;
    while (len--)
    {
        b = *data++ ^ (uint8)crc;
        b ^= b << 4;
        crc = (crc >> 8) ^ ((uint16)b << 8) ^ ((uint16)b << 3) ^ (b >> 4);
    }
    result[0] = (uint8)crc;
    result[1] = (uint8)(crc >> 8);
}
static bool Hal_Rc522_Exchange(const uint8 *send, uint8 send_len, uint8 bits, uint8 *recv, uint8 expected)
{
    uint16 n;
    uint8 irq = 0, count, i;
    if (!g_ready)
    {
        return Hal_Rc522_Fail(RC522_NOT_READY);
    }
    Hal_Rc522_Write_Reg(REG_COMMAND, CMD_IDLE);
    Hal_Rc522_Write_Reg(REG_COM_IRQ, IRQ_CLEAR_ALL);
    Hal_Rc522_Write_Reg(REG_FIFO_LEVEL, FIFO_FLUSH);
    for (i = 0; i < send_len; ++i)
    {
        Hal_Rc522_Write_Reg(REG_FIFO_DATA, send[i]);
    }
    Hal_Rc522_Write_Reg(REG_BIT_FRAMING, bits);
    Hal_Rc522_Write_Reg(REG_COMMAND, CMD_TRANSCEIVE);
    Hal_Rc522_Write_Reg(REG_BIT_FRAMING, bits | START_SEND);
    for (n = 0; n < RC522_POLL_LIMIT; ++n)
    {
        irq = Hal_Rc522_Read_Reg(REG_COM_IRQ);
        if (irq & (IRQ_RX | IRQ_TIMER))
        {
            break;
        }
        MicroWait(RC522_POLL_US);
    }
    Hal_Rc522_Write_Reg(REG_BIT_FRAMING, bits);
    Hal_Rc522_Write_Reg(REG_COMMAND, CMD_IDLE);
    if (!(irq & IRQ_RX))
    {
        return Hal_Rc522_Fail(RC522_NO_RESPONSE);
    }
    if (Hal_Rc522_Read_Reg(REG_ERROR) & ERROR_RX_MASK)
    {
        return Hal_Rc522_Fail(RC522_PROTOCOL_ERROR);
    }
    count = Hal_Rc522_Read_Reg(REG_FIFO_LEVEL);
    if (count != expected || (Hal_Rc522_Read_Reg(REG_CONTROL) & LAST_BITS_MASK))
    {
        return Hal_Rc522_Fail(RC522_PROTOCOL_ERROR);
    }
    for (i = 0; i < count; ++i)
    {
        recv[i] = Hal_Rc522_Read_Reg(REG_FIFO_DATA);
    }
    g_rc522_last_error = RC522_OK;
    return TRUE;
}
static uint8 Hal_Rc522_Select_Command(uint8 level)
{
    return level == 1 ? PICC_SELECT_CL1 : (level == 2 ? PICC_SELECT_CL2 : PICC_SELECT_CL3);
}
bool Hal_Rc522_Request(uint8 atqa[2])
{
    uint8 cmd = PICC_WUPA;
    if (!atqa)
    {
        return Hal_Rc522_Fail(RC522_BAD_PARAM);
    }
    return Hal_Rc522_Exchange(&cmd, 1, 7, atqa, 2);
}
bool Hal_Rc522_Anticoll(uint8 level, uint8 block[5])
{
    uint8 cmd[2];
    if (!block || level < 1 || level > 3)
    {
        return Hal_Rc522_Fail(RC522_BAD_PARAM);
    }
    cmd[0] = Hal_Rc522_Select_Command(level);
    cmd[1] = PICC_ANTICOLL_NVB;
    if (!Hal_Rc522_Exchange(cmd, 2, 0, block, 5))
    {
        return FALSE;
    }
    if ((block[0] ^ block[1] ^ block[2] ^ block[3]) != block[4])
    {
        return Hal_Rc522_Fail(RC522_PROTOCOL_ERROR);
    }
    return TRUE;
}
bool Hal_Rc522_Select(uint8 level, const uint8 block[5], uint8 *sak)
{
    uint8 cmd[9], reply[3], crc[2];
    if (!block || !sak || level < 1 || level > 3)
    {
        return Hal_Rc522_Fail(RC522_BAD_PARAM);
    }
    cmd[0] = Hal_Rc522_Select_Command(level);
    cmd[1] = PICC_SELECT_NVB;
    osal_memcpy(cmd + 2, block, 5);
    Hal_Rc522_Crc_A(cmd, 7, cmd + 7);
    if (!Hal_Rc522_Exchange(cmd, sizeof(cmd), 0, reply, sizeof(reply)))
    {
        return FALSE;
    }
    Hal_Rc522_Crc_A(reply, 1, crc);
    if (crc[0] != reply[1] || crc[1] != reply[2])
    {
        return Hal_Rc522_Fail(RC522_PROTOCOL_ERROR);
    }
    *sak = reply[0];
    return TRUE;
}
bool Hal_Rc522_Read_Uid(uint8 uid[RC522_UID_MAX], uint8 *len)
{
    uint8 atqa[2], block[5], sak, level, used = 0, count, start, halt[4];
    if (!uid || !len)
    {
        return Hal_Rc522_Fail(RC522_BAD_PARAM);
    }
    *len = 0;
    if (!Hal_Rc522_Request(atqa))
    {
        return FALSE;
    }
    for (level = 1; level <= 3; ++level)
    {
        if (!Hal_Rc522_Anticoll(level, block) || !Hal_Rc522_Select(level, block, &sak))
        {
            return FALSE;
        }
        start = block[0] == PICC_CASCADE_TAG ? 1 : 0;
        if ((start && (level == 3 || !(sak & PICC_SAK_CASCADE))) ||
        (!start && (sak & PICC_SAK_CASCADE)))
        {
            return Hal_Rc522_Fail(RC522_PROTOCOL_ERROR);
        }
        count = start ? 3 : 4;
        osal_memcpy(uid + used, block + start, count);
        used += count;
        if (!(sak & PICC_SAK_CASCADE))
        {
            *len = used;
            /* HALT������Ӧ���´�WUPA���ٴζ�ȡͬһ�ſ��� */
            halt[0] = PICC_HALT;
            halt[1] = 0;
            Hal_Rc522_Crc_A(halt, 2, halt + 2);
            Hal_Rc522_Exchange(halt, 4, 0, atqa, 2);
            g_rc522_last_error = RC522_OK;
            return TRUE;
        }
    }
    return Hal_Rc522_Fail(RC522_PROTOCOL_ERROR);
}
