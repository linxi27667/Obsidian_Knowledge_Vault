/* ����ҵ��ʵ�֡��ɽ�ɫ���ļ��� OSAL �¼�������ȣ������д����������� */
#include "AF.h"
#include "OSAL.h"
#include "ZDApp.h"
#include "ZGlobals.h"
#include "app_database.h"
#include "app_ui.h"
#include "comm_protocol.h"
#include "SampleApp.h"
#include "NLMEDE.h"
#include "OnBoard.h"
#include "comm_broadcast.h"
#include "comm_unicast.h"
#include "device1_uart.h"
#include "hal_buzzer.h"
#include "hal_board_key.h"
#include "hal_led.h"
#include "hal_console_uart.h"
#include "hal_eeprom.h"
#include "hal_i2c.h"
#include "hal_rc522.h"
#include "hal_rtc.h"
#include "nwk.h"
#include <string.h>

#include "app_terminal.h"

extern uint8 SampleApp_TaskID;
extern devStates_t SampleApp_NwkState;

static uint8 g_network_joined;
static uint8 g_peripherals_ready;
static uint8 g_peripheral_init_step;
static uint8 g_reader_ready;
static uint8 g_card_held_near_reader;
static uint8 g_attendance_mode;
static uint8 g_last_scan_mode;
static uint8 g_mode_timeout_seconds;
static uint8 g_rtc_read_status = 5;
static uint8 g_database_status = ATT_OFFLINE;
static uint8 g_database_user_count;
static uint8 g_terminal_age_seconds = 255;
static uint8 g_console_output_step;
static uint8 g_list_command_type;
static uint8 g_export_csv;
static uint8 g_list_command_index;
static uint8 g_list_waiting_for_response;
static uint16 g_terminal_short_address = 0xFFFF;
static uint16 g_session_id;
static uint16 g_transaction_counter;
static uint8 g_database_mutation_pending;
static uint8 g_database_mutation_command_type;
static uint8 g_database_mutation_is_remote;
static uint16 g_database_mutation_session_id;
static uint16 g_database_mutation_transaction_id;
static uint16 g_cached_session_id;
static uint16 g_cached_transaction_id;
static uint8 g_cached_command_type;
static uint8 g_cached_result_code;
static uint8 g_cached_slot;
static uint8 g_cached_scan_mode;

static rtc_time_t g_rtc_time;
static uint8 g_registered_identity[28];
static uint8 g_last_card_uid[10];
static uint8 g_last_card_uid_length;
static uint8 g_pending_frame[ATT_FRAME_MAX];
static uint8 g_pending_frame_length;
static uint8 g_retry_count;
static uint8 g_transmit_frame[ATT_FRAME_MAX];

void App_Terminal_Command_Process(uart_cmd_t *command);
static const char *App_Terminal_Result_Text(uint8 s);
static void App_Terminal_Send(uint16 dst, uint8 op, uint16 s, uint16 tx, const uint8 *p, uint8 n);
static void App_Terminal_Hex(const uint8 *p, uint8 n, char *out);
static void App_Terminal_Show_Result(uint8 op, const uint8 *p, uint8 n);
static void App_Terminal_Set_Mode(uint8 value, const uint8 *id);
static void App_Terminal_Time_Payload(uint8 *p);
static uint8 App_Terminal_Set_Time(const uint8 *p);
static void App_Terminal_Hello(uint8 time_sync_request);
static uint8 App_Terminal_Complete_Reply(uint8 op, uint8 *out);
static void App_Terminal_Execute(uint8 op, const uint8 *p, uint8 n, uint16 s, uint16 tx, uint8 remote);
static void App_Terminal_Request(uint8 op, const uint8 *p, uint8 n);
void App_Terminal_Unicast_Receive(uint16 src, uint8 *f, uint8 len);
static void App_Terminal_Network_Status(uint8 line);
static void App_Terminal_Begin_Mode(uint8 m, const uint8 *id);
static uint8 App_Terminal_Number(const char *s, uint8 limit, uint8 *v);
static uint8 App_Terminal_Parse_Identity(char *id, char *name, uint8 *out);
static uint8 App_Terminal_Hex_Digit(char c);
static uint8 App_Terminal_Parse_Uid(const char *s, uint8 *out);

/* ==================== Ӧ����װ���������� ==================== */
void App_Terminal_Init(uint8 task_id)
{
    g_session_id = osal_rand();
    if (g_session_id == 0)
    {
        g_session_id = 1;
    }


    /* LED��ʼ����Э��ջHalDriverInit��ɣ�Ӧ��ֻ����״̬�� */
    HalLedSet(HAL_LED_1, HAL_LED_MODE_OFF);
    Hal_Key_Init();
    Hal_Buzzer_Init();
    Hal_Buzzer_Bind(task_id, SAMPLEAPP_BUZZER_EVT);

    Hal_Uart_Print("[BOOT] ATT2 END DEVICE\r\n");

}

uint8 App_Terminal_Peripherals_Process(void)
{
    uint8 driver_status;
    uint8 driver_flags;

    if (g_peripherals_ready)
    {
        return 1;
    }
    switch (g_peripheral_init_step++)
    {
    case 0:
        driver_status = Hal_I2c_Init();
        Hal_Uart_Printf("[DRV] I2C=%u\r\n", (unsigned int)driver_status);
        break;

    case 1:
        driver_flags = 0;
        driver_status = Hal_Rtc_Init(&driver_flags);
        Hal_Uart_Printf("[DRV] RTC=%u flags=%x\r\n", (unsigned int)driver_status,
        (unsigned int)driver_flags);
        break;

    case 2:
        g_reader_ready = Hal_Rc522_Init();
        Hal_Uart_Printf("[DRV] RC522=%x error=%u\r\n", (unsigned int)g_rc522_version,
        (unsigned int)g_rc522_last_error);
        break;
    case 3:
        App_Ui_Init(1);
        Hal_Uart_Printf("[DRV] OLED=%u\r\n", (unsigned int)App_Ui_Error());
        break;

    case 4:
        App_Database_Init();
        App_Database_Tick();
        g_database_status = App_Database_Status();
        g_database_user_count = App_Database_Count();
        g_rtc_read_status = Hal_Rtc_Read_Time(&g_rtc_time);
        if (g_rtc_read_status == RTC_TIME_INVALID)
        {
            /* �ն˲�ʹ�ñ���ʱ������Уʱ���ȴ�Э�����·�Ȩ��ʱ�䡣 */
            Hal_Uart_Print("[RTC] invalid; waiting coordinator time\r\n");
        }
        App_Ui_Time(&g_rtc_time, g_rtc_read_status);
        g_peripherals_ready = 1;
        if (g_network_joined)
        {
            /* �������������������׼����ɺ�������Э��������ȡʱ�� */
            App_Terminal_Hello(0);
        }
        Hal_Uart_Print("[READY] #HELP IDLE=ATTEND KEY1=REG KEY2=REMOVE SAME=EXIT\r\n");
        break;

    default:
        break;
    }

    return g_peripherals_ready;
}

void App_Terminal_Network_Update(uint8 joined)
{
    g_network_joined = joined;
    if (g_network_joined)
    {
        Hal_Uart_Print("[ZB] End device joined\r\n");
        if (g_peripherals_ready)
        {
            App_Ui_Message("NETWORK READY", "ATTENDANCE ONLINE");
            /* �������� HELLO��Э�������ͨ�� ATT_TIME �·���ǰʱ�䡣 */
            App_Terminal_Hello(0);
        }
    }
    else
    {
        Hal_Uart_Print("[ZB] End device offline\r\n");
        if (g_peripherals_ready)
        {
            App_Ui_Message("NETWORK WAIT", "LOCAL ATTENDANCE READY");
        }
    }
}

void App_Terminal_Database_Process(void)
{

    uint8 reply[47];
    uint8 reply_length;

    App_Database_Tick();
    if (App_Database_Take_Done() && g_database_mutation_pending)
    {
        reply_length = App_Terminal_Complete_Reply(g_database_mutation_command_type, reply + 1);
        reply[0] = g_database_mutation_command_type;

        if (g_database_mutation_is_remote)
        {
            App_Terminal_Send(0, g_database_mutation_command_type | ATT_REPLY, g_database_mutation_session_id,
            g_database_mutation_transaction_id, reply + 1, reply_length);
            g_cached_session_id = g_database_mutation_session_id;
            g_cached_transaction_id = g_database_mutation_transaction_id;
            g_cached_command_type = g_database_mutation_command_type;
            g_cached_result_code = reply[1];
            g_cached_slot = reply[2];
            g_cached_scan_mode = g_last_scan_mode;
        }

        App_Terminal_Show_Result(g_database_mutation_command_type, reply + 1, reply_length);

        /* ֪ͨʧ��ʱ�����־û���¼���������ԿɴӴ��ڲ�ѯ�� */
        if (!g_database_mutation_is_remote && g_network_joined && !g_pending_frame_length)
        {
            if (g_database_mutation_command_type == ATT_SCAN)
            {
                --reply_length;
            }
            reply[reply_length + 1] = App_Database_Count();
            reply[reply_length + 2] = g_last_scan_mode;
            g_pending_frame_length = Comm_Protocol_PackFrame(g_pending_frame, sizeof(g_pending_frame), ATT_EVENT, g_session_id, ++g_transaction_counter,
            reply, reply_length + 3);
            if (g_pending_frame_length != 0)
            {
                g_retry_count = 1;
                osal_start_timerEx(SampleApp_TaskID, SAMPLEAPP_RETRY_EVT, SAMPLEAPP_RETRY_INTERVAL);
                Comm_Unicast_Send(0, g_pending_frame, g_pending_frame_length);
            }
        }

        g_database_mutation_pending = 0;
        App_Terminal_Hello(0);
    }

    g_database_status = App_Database_Status();
    g_database_user_count = App_Database_Count();
}

void App_Terminal_Display_Process(void)
{

    if (g_peripherals_ready)
    {
        App_Ui_Status(g_network_joined, g_terminal_age_seconds <= SAMPLEAPP_PEER_TIMEOUT_SECONDS, g_database_status,
        g_database_user_count, g_attendance_mode, g_mode_timeout_seconds);
        App_Ui_Tick();
    }
}

void App_Terminal_Retry_Process(void)
{

    if (g_pending_frame_length != 0)
    {
        if (g_retry_count < SAMPLEAPP_RETRY_LIMIT && g_network_joined)
        {
            ++g_retry_count;
            Comm_Unicast_Send(0, g_pending_frame, g_pending_frame_length);
            osal_start_timerEx(SampleApp_TaskID, SAMPLEAPP_RETRY_EVT, SAMPLEAPP_RETRY_INTERVAL);
        }
        else
        {
            g_pending_frame_length = 0;
            /* �����Ѿ���⣻֪ͨ��ʱ����ʾ������ʧ�ܡ���Ҳ��ȡ�����ز�ѯ�� */
            Hal_Uart_Print("[LINK] event not acknowledged; attendance remains stored\r\n");
        }
    }
}

/* ==================== �����봮����� ==================== */
void App_Terminal_Key_Process(uint8 shift, uint8 keys)
{
    (void)shift;
    if (!g_peripherals_ready || keys == 0)
    {
        return;
    }

    /* ��ǰģʽ���ٰ�һ�������˳�����һ������ֱ���л�ģʽ�� */
    if (keys == (KEY0_PRESS | KEY1_PRESS))
    {
        App_Terminal_Begin_Mode(0, NULL);
    }
    else if (keys & KEY0_PRESS)
    {
        App_Terminal_Begin_Mode(g_attendance_mode == 1 ? 0 : 1, NULL);
    }
    else if (keys & KEY1_PRESS)
    {
        App_Terminal_Begin_Mode(g_attendance_mode == 2 ? 0 : 2, NULL);
    }
}

void App_Terminal_Command_Process(uart_cmd_t *command)
{
    char uid_text[21];
    uint8 argument_count;
    uint8 payload[32];

    if (command == NULL)
    {
        return;
    }

    argument_count = command->argument_count;

    if (!g_peripherals_ready)
    {
        Hal_Uart_Print("ERR INITIALIZING\r\n");
        return;
    }
    if (Hal_Uart_Free() < 120)
    {
        Hal_Uart_Print("ERR OUTPUT_BUSY\r\n");
        return;
    }

    switch (command->cmd_type)
    {
    case UART_CMD_HELP:
        if (argument_count == 1)
        {
            g_console_output_step = 1;
            return;
        }
        if (argument_count == 2 && strcmp(command->arguments[1], "TIME") == 0)
        {
            g_console_output_step = 10;
            return;
        }
        if (argument_count == 2 && strcmp(command->arguments[1], "DB") == 0)
        {
            g_console_output_step = 20;
            return;
        }
        break;

    case UART_CMD_STATUS:
        if (argument_count == 1)
        {
            g_console_output_step = 40;
            return;
        }
        break;

    case UART_CMD_RTC:
        if (argument_count == 1)
        {
            Hal_Uart_Printf("RTC status=%u time=20%u-%u-%u %u:%u:%u\r\n", (unsigned int)g_rtc_read_status,
            (unsigned int)g_rtc_time.year, (unsigned int)g_rtc_time.month, (unsigned int)g_rtc_time.day,
            (unsigned int)g_rtc_time.hour, (unsigned int)g_rtc_time.minute,
            (unsigned int)g_rtc_time.second);
            return;
        }
        break;

    case UART_CMD_TIME_SET:
        Hal_Uart_Print("ERR TIME_SOURCE_COORDINATOR - set #TIME on coordinator\r\n");
        return;

    case UART_CMD_UID:
        if (argument_count == 1)
        {
            App_Terminal_Hex(g_last_card_uid, g_last_card_uid_length, uid_text);
            Hal_Uart_Printf("UID %s\r\n", uid_text);
            return;
        }
        break;

    case UART_CMD_BEEP:
        if (argument_count == 1)
        {
            Hal_Buzzer_Beep(80);
            Hal_Uart_Print("OK BEEP\r\n");
            return;
        }
        break;

    case UART_CMD_CANCEL:
        if (argument_count == 1)
        {
            App_Terminal_Begin_Mode(0, NULL);
            return;
        }
        break;

    case UART_CMD_REGISTER:
        if (argument_count == 1)
        {
            App_Terminal_Begin_Mode(1, NULL);
            return;
        }
        if (argument_count == 3 && App_Terminal_Parse_Identity(command->arguments[1], command->arguments[2], payload))
        {
            App_Terminal_Begin_Mode(1, payload);
            return;
        }
        break;

    case UART_CMD_UNREGISTER:
        if (argument_count == 1)
        {
            App_Terminal_Begin_Mode(2, NULL);
            return;
        }
        break;

    default:
        break;
    }

    if (g_list_command_type || g_database_mutation_pending)
    {
        Hal_Uart_Print("ERR BUSY\r\n");
        return;
    }

    switch (command->cmd_type)
    {
    case UART_CMD_LIST:
        if (argument_count == 1)
        {
            g_list_command_type = ATT_USER;
            g_list_command_index = 0;
            g_list_waiting_for_response = 0;
            return;
        }
        break;

    case UART_CMD_EXPORT:
        if (argument_count == 1)
        {
            g_export_csv = 1;
            g_list_command_type = ATT_LOG;
            g_list_command_index = 0;
            g_list_waiting_for_response = 0;
            Hal_Uart_Print("seq,id,date,time,valid,origin\r\n");
            return;
        }
        break;

    case UART_CMD_LOG:
        g_export_csv = 0;
        if (argument_count == 1 || (argument_count == 2 && strcmp(command->arguments[1], "ALL") == 0))
        {
            g_list_command_type = ATT_LOG;
            g_list_command_index = 0;
            g_list_waiting_for_response = 0;
            return;
        }
        if (argument_count == 2 && App_Terminal_Number(command->arguments[1], 10, payload))
        {
            App_Terminal_Request(ATT_LOG, payload, 1);
            return;
        }
        break;

    case UART_CMD_GET:
        if (argument_count == 2 && App_Terminal_Number(command->arguments[1], 8, payload))
        {
            App_Terminal_Request(ATT_USER, payload, 1);
            return;
        }
        break;

    case UART_CMD_FIND:
        if (argument_count == 2 && App_Terminal_Parse_Uid(command->arguments[1], payload))
        {
            App_Terminal_Request(ATT_FIND, payload, 11);
            return;
        }
        break;

    case UART_CMD_USER:
        if (argument_count == 5 && strcmp(command->arguments[1], "SET") == 0 &&
        App_Terminal_Number(command->arguments[2], 8, payload) &&
        App_Terminal_Parse_Identity(command->arguments[3], command->arguments[4], payload + 1))
        {
            App_Terminal_Request(ATT_SET, payload, ATT_MODE_PAYLOAD_LENGTH);
            return;
        }
        if (argument_count == 3 && strcmp(command->arguments[1], "DEL") == 0 &&
        App_Terminal_Number(command->arguments[2], 8, payload))
        {
            App_Terminal_Request(ATT_DELETE, payload, 1);
            return;
        }
        break;

    case UART_CMD_DATABASE:
        if (argument_count == 2 && strcmp(command->arguments[1], "STATUS") == 0)
        {
            App_Terminal_Request(ATT_META, NULL, 0);
            return;
        }
        if (argument_count == 3 && strcmp(command->arguments[1], "INIT") == 0 &&
        strcmp(command->arguments[2], "CONFIRM") == 0)
        {
            App_Terminal_Request(ATT_FORMAT, (const uint8 *)"INIT", 4);
            return;
        }
        break;

    case UART_CMD_SYNC:
        if (argument_count == 1)
        {
            if (!g_network_joined)
            {
                Hal_Uart_Print("ERR OFFLINE\r\n");
                return;
            }
            /* HELLO��Э������ȡʱ�䣻�ն˲�������д��һ��ʱ�䡣 */
            App_Terminal_Hello(1);
            Hal_Uart_Print("TIME SYNC requested\r\n");
            return;
        }
        break;

    default:
        break;
    }

    Hal_Uart_Print("ERR SYNTAX - #HELP\r\n");
}

/* ==================== �����ʾ��ҵ��ģʽ ==================== */
static const char *App_Terminal_Result_Text(uint8 status)
{
    switch (status)
    {
    case ATT_OK:
        return "OK";
    case ATT_BUSY:
        return "BUSY";
    case ATT_PARAM:
        return "BAD PARAMETER";
    case ATT_UNKNOWN:
        return "UNKNOWN CARD";
    case ATT_FULL:
        return "DATABASE FULL";
    case ATT_EXISTS:
        return "ALREADY EXISTS";
    case ATT_STORAGE:
        return "STORAGE ERROR";
    case ATT_CORRUPT:
        return "DATABASE CORRUPT";
    case ATT_OFFLINE:
        return "READER OFFLINE";
    case ATT_TIMEOUT:
        return "ACK TIMEOUT";
    default:
        return "PROTOCOL ERROR";
    }
}

static void App_Terminal_Send(uint16 destination, uint8 opcode, uint16 session, uint16 transaction, const uint8 *payload, uint8 payload_length)
{
    uint8 frame_length = Comm_Protocol_PackFrame(g_transmit_frame, sizeof(g_transmit_frame), opcode, session, transaction, payload, payload_length);
    if (frame_length && g_network_joined)
    {
        Comm_Unicast_Send(destination, g_transmit_frame, frame_length);
    }
}

static void App_Terminal_Hex(const uint8 *uid, uint8 uid_length, char *text)
{
    static const char digits[] = "0123456789ABCDEF";
    uint8 index;
    for (index = 0; index < uid_length; index++)
    {
        text[index * 2] = digits[uid[index] >> 4];
        text[index * 2 + 1] = digits[uid[index] & 15];
    }
    text[uid_length * 2] = 0;
}

static void App_Terminal_Show_Result(uint8 opcode, const uint8 *payload, uint8 payload_length)
{
    char student_id[13], student_name[17], uid_text[21];
    uint8 index;
    if (payload_length < 4)
    {
        return;
    }
    if (opcode == ATT_SCAN && (payload_length == 5 || payload_length == 45) && payload[payload_length - 1] <= 2)
    {
        g_last_scan_mode = payload[payload_length - 1];
        --payload_length;
    }
    if (opcode == ATT_SCAN)
    {
        g_attendance_mode = 0;
        g_mode_timeout_seconds = 0;
        osal_memset(g_registered_identity, 0, sizeof(g_registered_identity));
    }
    /* ��ѯ����������κţ������������ESP��127�ֽ�TX��������� */
    if (payload[0] != ATT_OK ||
        (opcode != ATT_USER && opcode != ATT_FIND && opcode != ATT_LOG && opcode != ATT_META))
    {
        Hal_Uart_Printf("RSP op=%u status=%u slot=%u gen=%u\r\n", (unsigned int)opcode, (unsigned int)payload[0],
        (unsigned int)payload[1], (unsigned int)Comm_Protocol_ReadUint16(payload + 2));
    }
    if (opcode == ATT_META && payload_length == 8)
    {
        g_database_status = payload[0];
        g_database_user_count = payload[4];
        Hal_Uart_Printf("DB users=%u capacity=8 logs=%u capacity=10 gen=%u\r\n", (unsigned int)payload[4],
        (unsigned int)payload[5], (unsigned int)Comm_Protocol_ReadUint16(payload + 2));
    }
    else if ((opcode == ATT_USER || opcode == ATT_FIND) && !payload[0] && payload_length == 44)
    {
        if (payload[4] != 4 && payload[4] != 7 && payload[4] != 10)
        {
            return;
        }
        App_Terminal_Hex(payload + 5, payload[4], uid_text);
        osal_memcpy(student_id, payload + 15, 12);
        student_id[12] = 0;
        osal_memcpy(student_name, payload + 27, 16);
        student_name[16] = 0;
        Hal_Uart_Printf("USER slot=%u uid=%s id=%s name=%s gen=%u\r\n", (unsigned int)payload[1], uid_text, student_id, student_name, (unsigned int)Comm_Protocol_ReadUint16(payload + 2));
    }
    else if (opcode == ATT_LOG && !payload[0] && payload_length == 20)
    {
        for (index = 0; index < 6; index++)
        {
            student_id[index * 2] = '0' + (payload[4 + index] >> 4);
            student_id[index * 2 + 1] = '0' + (payload[4 + index] & 15);
        }
        student_id[12] = 0;
        if (g_export_csv)
        {
            Hal_Uart_Printf("%u,%s,20%u-%u-%u,%u:%u:%u,%u,%u\r\n",
            (unsigned int)Comm_Protocol_ReadUint16(payload + 18), student_id,
            (unsigned int)payload[10], (unsigned int)payload[11], (unsigned int)payload[12],
            (unsigned int)payload[13], (unsigned int)payload[14], (unsigned int)payload[15],
            (unsigned int)payload[16], (unsigned int)payload[17]);
        }
        else
        {
            Hal_Uart_Printf("LOG index=%u seq=%u id=%s time=20%u-%u-%u %u:%u:%u valid=%u origin=%u gen=%u\r\n",
            (unsigned int)payload[1], (unsigned int)Comm_Protocol_ReadUint16(payload + 18), student_id, (unsigned int)payload[10],
            (unsigned int)payload[11], (unsigned int)payload[12], (unsigned int)payload[13], (unsigned int)payload[14],
            (unsigned int)payload[15], (unsigned int)payload[16], (unsigned int)payload[17],
            (unsigned int)Comm_Protocol_ReadUint16(payload + 2));
        }
    }
    else if (opcode != ATT_TIME && opcode != ATT_MODE)
    {
        if (opcode == ATT_SCAN && payload[0] == ATT_OK)
        {
            const uint8 *user = App_Database_User(payload[1]);
            const char *heading;
            if (g_last_scan_mode == 1)
            {
                heading = "REGISTER OK";
            }
            else if (g_last_scan_mode == 2)
            {
                heading = "REMOVE OK";
            }
            else
            {
                heading = "ATTENDANCE OK";
            }
            if (user != NULL)
            {
                osal_memcpy(student_id, user + 11, 12);
                student_id[12] = 0;
                App_Ui_Message(heading, student_id);
                Hal_Uart_Printf("CARD id=%s name=%s\r\n", student_id, user + 23);
            }
            else
            {
                App_Ui_Message(heading, "CARD PROCESSED");
            }
        }
        else
        {
            const char *heading = App_Terminal_Result_Text(payload[0]);
            if (opcode == ATT_SCAN)
            {
                if (g_last_scan_mode == 1 && payload[0] == ATT_EXISTS)
                {
                    heading = "CARD ALREADY REGISTERED";
                }
                else if (g_last_scan_mode == 2 && payload[0] == ATT_UNKNOWN)
                {
                    heading = "CARD NOT REGISTERED";
                }
                else if (g_last_scan_mode == 0 && payload[0] == ATT_UNKNOWN)
                {
                    heading = "ATTENDANCE UNREGISTERED";
                }
            }
            App_Ui_Message(heading, opcode == ATT_SCAN ? "CARD PROCESSED" : "DATABASE COMMAND");
        }
        Hal_Buzzer_Beep(payload[0] ? 180 : 60);
    }
    if (g_list_waiting_for_response && opcode == g_list_command_type)
    {
        g_list_waiting_for_response = 0;
        if ((payload[0] && payload[0] != ATT_UNKNOWN) || (opcode == ATT_LOG && payload[0] == ATT_UNKNOWN))
        {
            g_list_command_type = 0;
            Hal_Uart_Print("END\r\n");
        }
        else
        {
            ++g_list_command_index;
        }
    }
}

static void App_Terminal_Set_Mode(uint8 new_mode, const uint8 *identity)
{
    g_attendance_mode = new_mode;
    g_mode_timeout_seconds = new_mode ? 30 : 0;
    osal_memset(g_registered_identity, 0, sizeof(g_registered_identity));
    if (identity)
    {
        osal_memcpy(g_registered_identity, identity, 28);
    }
    if (new_mode == 1)
    {
        App_Ui_Message("REGISTER MODE", "SCAN WITHIN 30 SEC");
    }
    else if (new_mode == 2)
    {
        App_Ui_Message("REMOVE MODE", "SCAN WITHIN 30 SEC");
    }
    else
    {
        App_Ui_Message("ATTENDANCE MODE", "SCAN REGISTERED CARD");
    }
    Hal_Uart_Printf("MODE value=%u timeout=%u\r\n", (unsigned int)g_attendance_mode,
    (unsigned int)g_mode_timeout_seconds);
}

static void App_Terminal_Time_Payload(uint8 *payload)
{
    payload[0] = g_rtc_time.year;
    payload[1] = g_rtc_time.month;
    payload[2] = g_rtc_time.day;
    payload[3] = g_rtc_time.hour;
    payload[4] = g_rtc_time.minute;
    payload[5] = g_rtc_time.second;
}

static uint8 App_Terminal_Set_Time(const uint8 *payload)
{
    rtc_time_t new_time;
    uint16 elapsed_days = 6;
    uint8 index;
    static const uint8 month_days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (payload[0] > 99 || payload[1] < 1 || payload[1] > 12 || payload[2] < 1 || payload[2] > 31)
    {
        return I2C_PARAM;
    }
    new_time.year = payload[0];
    new_time.month = payload[1];
    new_time.day = payload[2];
    new_time.hour = payload[3];
    new_time.minute = payload[4];
    new_time.second = payload[5];
    new_time.weekday = 0;
    for (index = 0; index < new_time.year; index++)
    {
        elapsed_days += index % 4 ? 365 : 366;
    }
    for (index = 1; index < new_time.month; index++)
    {
        elapsed_days += month_days[index - 1];
        if (index == 2 && new_time.year % 4 == 0)
        {
            ++elapsed_days;
        }
    }
    new_time.weekday = (elapsed_days + new_time.day - 1) % 7;
    /* RTC������������/�����飻д��ǰ���޸ĵ�ǰ��ʾֵ�� */
    return Hal_Rtc_Set_Time(&new_time);
}

static void App_Terminal_Hello(uint8 time_sync_request)
{
    uint8 payload[7];
    payload[0] = App_Database_Status();
    payload[1] = App_Database_Count();
    Comm_Protocol_WriteUint16(payload + 2, App_Database_Generation());
    /* �����ʾ����Э����Уʱ���ֶ�ͬ�����ƻ�����������Чʱ�䡣 */
    payload[4] = time_sync_request ? RTC_TIME_INVALID : g_rtc_read_status;
    payload[5] = g_attendance_mode;
    payload[6] = g_mode_timeout_seconds;
    App_Terminal_Send(0, ATT_HELLO, g_session_id, 0, payload, 7);
}

static uint8 App_Terminal_Complete_Reply(uint8 opcode, uint8 *response)
{
    const uint8 *user;
    uint8 length = App_Database_Reply_Size();

    osal_memcpy(response, App_Database_Reply(), length);
    if (opcode == ATT_SCAN)
    {
        if (response[0] == ATT_OK)
        {
            user = App_Database_User(response[1]);
            if (user != NULL)
            {
                osal_memcpy(response + 4, user, 40);
                length = 44;
            }
        }
        response[length++] = g_last_scan_mode;
    }
    return length;
}

static void App_Terminal_Execute(uint8 opcode, const uint8 *payload, uint8 payload_length, uint16 request_session, uint16 request_transaction, uint8 remote)
{
    uint8 result_code, busy_reply[4] = {ATT_BUSY, 255, 0, 0};
    uint8 response[45], response_length;
    if (g_database_mutation_pending || App_Database_Status() == ATT_BUSY)
    {
        if (remote)
        {
            App_Terminal_Send(0, opcode | ATT_REPLY, request_session, request_transaction, busy_reply, 4);
        }
        else
        {
            App_Terminal_Show_Result(opcode, busy_reply, 4);
        }
        return;
    }
    if (opcode == ATT_SCAN && payload_length == ATT_SCAN_PAYLOAD_LENGTH)
    {
        if (remote && !App_Database_Request_Fresh(request_session, request_transaction))
        {
            g_last_scan_mode = App_Database_Last_Scan_Mode();
        }
        else
        {
            g_last_scan_mode = payload[0];
        }
    }
    result_code = App_Database_Execute(opcode, payload, payload_length, request_session, request_transaction, remote);
    if (result_code == ATT_BUSY)
    {
        g_database_mutation_pending = 1;
        g_database_mutation_command_type = opcode;
        g_database_mutation_is_remote = remote;
        g_database_mutation_session_id = request_session;
        g_database_mutation_transaction_id = request_transaction;
        App_Ui_Message("SAVING", "DO NOT POWER OFF");
    }
    else
    {
        if (remote)
        {
            response_length = App_Terminal_Complete_Reply(opcode, response);
            App_Terminal_Send(0, opcode | ATT_REPLY, request_session, request_transaction, response, response_length);
            if (opcode == ATT_SCAN || opcode == ATT_SET || opcode == ATT_DELETE || opcode == ATT_FORMAT)
            {
                g_cached_session_id = request_session;
                g_cached_transaction_id = request_transaction;
                g_cached_command_type = opcode;
                g_cached_result_code = App_Database_Reply()[0];
                g_cached_slot = App_Database_Reply()[1];
                g_cached_scan_mode = g_last_scan_mode;
            }
        }
        else
        {
            App_Terminal_Show_Result(opcode, App_Database_Reply(), App_Database_Reply_Size());
        }
    }
}

static void App_Terminal_Request(uint8 opcode, const uint8 *payload, uint8 payload_length)
{
    /* ͬһ��ڷ��񴮿ں�ˢ�����ն�ִ�б�������Э������Զ������ */
    App_Terminal_Execute(opcode, payload, payload_length, g_session_id, ++g_transaction_counter, 0);
}

/* ==================== ������Ϣ���� ==================== */
void App_Terminal_Unicast_Receive(uint16 source, uint8 *raw, uint8 frame_length)
{
    comm_frame_t frame;
    uint8 opcode, payload_length;
    const uint8 *payload;
    uint16 session, transaction;
    uint8 result[5], scan_payload[ATT_SCAN_PAYLOAD_LENGTH];
    if (!g_peripherals_ready || Comm_Protocol_UnpackFrame(&frame, raw, frame_length) != COMM_OK)
    {
        return;
    }
    opcode = frame.opcode;
    payload_length = frame.data_len;
    payload = frame.data;
    session = frame.session;
    transaction = frame.transaction;
    if (source != 0)
    {
        return;
    }
    g_terminal_age_seconds = 0;
    g_terminal_short_address = 0;
    if (opcode == (ATT_EVENT | ATT_REPLY))
    {
        if (g_pending_frame_length && g_pending_frame[2] == ATT_EVENT && session == g_session_id &&
        transaction == Comm_Protocol_ReadUint16(g_pending_frame + 6))
        {
            g_pending_frame_length = 0;
            osal_stop_timerEx(SampleApp_TaskID, SAMPLEAPP_RETRY_EVT);
        }
        return;
    }
    if (opcode == ATT_HELLO)
    {
        return;
    }
    if (session == g_cached_session_id && transaction == g_cached_transaction_id && opcode == g_cached_command_type)
    {
        result[0] = g_cached_result_code;
        result[1] = g_cached_slot;
        Comm_Protocol_WriteUint16(result + 2, App_Database_Generation());
        if (opcode == ATT_SCAN)
        {
            result[4] = g_cached_scan_mode;
            App_Terminal_Send(0, opcode | ATT_REPLY, session, transaction, result, 5);
        }
        else
        {
            App_Terminal_Send(0, opcode | ATT_REPLY, session, transaction, result, 4);
        }
        return;
    }
    /* �ܾ�ͬ�Ự�ٵ��ľɿ������󣬲������������µ�ע��ģʽ�� */
    if (session == g_cached_session_id && (uint16)(transaction - g_cached_transaction_id) >= 0x8000)
    {
        result[0] = ATT_PARAM;
        result[1] = 255;
        Comm_Protocol_WriteUint16(result + 2, App_Database_Generation());
        App_Terminal_Send(0, opcode | ATT_REPLY, session, transaction, result, 4);
        return;
    }
    if (opcode == ATT_MODE || opcode == ATT_TIME)
    {
        result[0] = ATT_PARAM;
        if (opcode == ATT_MODE && payload_length == ATT_MODE_PAYLOAD_LENGTH && payload[0] <= 2)
        {
            if (g_database_mutation_pending)
            {
                result[0] = ATT_BUSY;
            }
            else
            {
                App_Terminal_Set_Mode(payload[0], payload + 1);
                result[0] = ATT_OK;
            }
        }
        else if (opcode == ATT_TIME && payload_length == ATT_TIME_PAYLOAD_LENGTH)
        {
            result[0] = App_Terminal_Set_Time(payload) ? ATT_PARAM : ATT_OK;
            if (result[0] == ATT_OK)
            {
                /* д��Э����ʱ��������ض����ý���Ϳ���ʹ��ͬһʱ�ӡ� */
                g_rtc_read_status = Hal_Rtc_Read_Time(&g_rtc_time);
                App_Ui_Time(&g_rtc_time, g_rtc_read_status);
                Hal_Uart_Printf("[TIME] coordinator sync status=%u\r\n",
                (unsigned int)g_rtc_read_status);
            }
        }
        if (result[0] != ATT_BUSY)
        {
            g_cached_session_id = session;
            g_cached_transaction_id = transaction;
            g_cached_command_type = opcode;
            g_cached_result_code = result[0];
            g_cached_slot = 255;
        }
        result[1] = 255;
        Comm_Protocol_WriteUint16(result + 2, App_Database_Generation());
        App_Terminal_Send(0, opcode | ATT_REPLY, session, transaction, result, 4);
        return;
    }
    if ((opcode >= ATT_SCAN && opcode <= ATT_META) || opcode == ATT_FIND)
    {
        if (opcode == ATT_SCAN && payload_length == ATT_SCAN_PAYLOAD_LENGTH && !g_database_mutation_pending &&
        App_Database_Status() != ATT_BUSY && App_Database_Request_Fresh(session, transaction))
        {
            /* �ն���ģʽ��������Ϣ��Ȩ���ˣ�Զ�˶����뱾�ذ�������һ�¡� */
            osal_memcpy(scan_payload, payload, ATT_SCAN_PAYLOAD_LENGTH);
            scan_payload[0] = g_attendance_mode;
            osal_memcpy(scan_payload + 12, g_registered_identity, 28);
            App_Terminal_Set_Mode(0, NULL);
            App_Terminal_Execute(opcode, scan_payload, payload_length, session, transaction, 1);
        }
        else
        {
            App_Terminal_Execute(opcode, payload, payload_length, session, transaction, 1);
        }
    }
}

/* ==================== ˢ���ɼ��뿼������ ==================== */
void App_Terminal_Card_Process(void)
{
    uint8 uid[10], uid_length, scan_payload[ATT_SCAN_PAYLOAD_LENGTH];
    char uid_text[21];
    if (!g_reader_ready)
    {
        return;
    }
    if (!Hal_Rc522_Read_Uid(uid, &uid_length))
    {
        if (g_rc522_last_error == RC522_NO_RESPONSE)
        {
            g_card_held_near_reader = 0;
        }
        return;
    }
    if (g_card_held_near_reader)
    {
        return;
    }
    g_card_held_near_reader = 1;
    g_last_card_uid_length = uid_length;
    osal_memcpy(g_last_card_uid, uid, uid_length);
    App_Terminal_Hex(uid, uid_length, uid_text);
    Hal_Uart_Printf("[CARD] uid=%s\r\n", uid_text);
    if (g_database_mutation_pending)
    {
        App_Ui_Message("BUSY", "REMOVE AND RESCAN");
        return;
    }
    osal_memset(scan_payload, 0, sizeof(scan_payload));
    scan_payload[0] = g_attendance_mode;
    scan_payload[1] = uid_length;
    osal_memcpy(scan_payload + 2, uid, uid_length);
    osal_memcpy(scan_payload + 12, g_registered_identity, 28);
    g_rtc_read_status = Hal_Rtc_Read_Time(&g_rtc_time);
    App_Terminal_Time_Payload(scan_payload + 40);
    scan_payload[46] = g_rtc_read_status == 0;
    scan_payload[47] = 1;
    App_Terminal_Set_Mode(0, NULL);
    App_Terminal_Request(ATT_SCAN, scan_payload, ATT_SCAN_PAYLOAD_LENGTH);
}

static void App_Terminal_Network_Status(uint8 line)
{
    if (line == 0)
    {
        Hal_Uart_Printf("[STATUS] role=%u state=%u PAN=%x CH=%u short=%x terminalShortAddress=%x\r\n",
        (unsigned int)1, (unsigned int)SampleApp_NwkState, (unsigned int)_NIB.nwkPanId,
        (unsigned int)_NIB.nwkLogicalChannel, (unsigned int)NLME_GetShortAddr(),
        (unsigned int)g_terminal_short_address);
    }
    else
    {
        Hal_Uart_Printf("[STATUS] db=%u users=%u rtc=%u oled=%u drop=%u\r\n", (unsigned int)g_database_status,
        (unsigned int)g_database_user_count, (unsigned int)g_rtc_read_status, (unsigned int)App_Ui_Error(),
        (unsigned int)g_uart_dropped);
    }
}

static void App_Terminal_Begin_Mode(uint8 new_mode, const uint8 *identity)
{
    if (new_mode == 0)
    {
        /* �˳�ģʽ���ȴ������¼������ݿ��ύ���ѿ�ʼ���ύ�ճ���ɡ� */
        App_Terminal_Set_Mode(0, NULL);
        App_Terminal_Hello(0);
        return;
    }
    if (g_database_mutation_pending)
    {
        Hal_Uart_Print("ERR BUSY\r\n");
        return;
    }
    App_Terminal_Set_Mode(new_mode, identity);
    App_Terminal_Hello(0);
}

static uint8 App_Terminal_Number(const char *text, uint8 limit, uint8 *output_value)
{
    uint16 number = 0;
    if (!*text)
    {
        return 0;
    }
    while (*text)
    {
        uint8 digit;
        if (*text < '0' || *text > '9')
        {
            return 0;
        }
        digit = (uint8)(*text++ - '0');
        if (digit >= limit || number > ((uint16)limit - 1 - digit) / 10)
        {
            return 0;
        }
        number = number * 10 + digit;
    }
    *output_value = (uint8)number;
    return 1;
}

static uint8 App_Terminal_Parse_Identity(char *student_id, char *student_name, uint8 *identity)
{
    uint8 index, name_length;
    if (!student_id || !student_name || strlen(student_id) != 12)
    {
        return 0;
    }
    name_length = (uint8)strlen(student_name);
    if (!name_length || name_length > 15)
    {
        return 0;
    }
    for (index = 0; index < 12; index++)
    {
        if (student_id[index] < '0' || student_id[index] > '9')
        {
            return 0;
        }
    }
    osal_memset(identity, 0, 28);
    osal_memcpy(identity, student_id, 12);
    osal_memcpy(identity + 12, student_name, name_length);
    return 1;
}

static uint8 App_Terminal_Hex_Digit(char character)
{
    if (character >= '0' && character <= '9')
    {
        return character - '0';
    }
    if (character >= 'A' && character <= 'F')
    {
        return character - 'A' + 10;
    }
    if (character >= 'a' && character <= 'f')
    {
        return character - 'a' + 10;
    }
    return 255;
}

static uint8 App_Terminal_Parse_Uid(const char *text, uint8 *uid)
{
    uint8 index, text_length = (uint8)strlen(text), high_nibble, low_nibble;
    if (text_length != 8 && text_length != 14 && text_length != 20)
    {
        return 0;
    }
    osal_memset(uid, 0, 11);
    uid[0] = text_length / 2;
    for (index = 0; index < text_length / 2; index++)
    {
        high_nibble = App_Terminal_Hex_Digit(text[index * 2]);
        low_nibble = App_Terminal_Hex_Digit(text[index * 2 + 1]);
        if (high_nibble == 255 || low_nibble == 255)
        {
            return 0;
        }
        uid[index + 1] = (high_nibble << 4) | low_nibble;
    }
    return 1;
}

void App_Terminal_Console_Process(void)
{
    uint8 index;

    /* ESP��TX���ճ�127�ֽڣ�ÿ��ֻ���һ�У���Ԥ��һ��������ѯ��Ӧ�� */
    if (Hal_Uart_Free() < 120)
    {
        return;
    }
    if (g_console_output_step)
    {
        switch (g_console_output_step++)
        {
        case 1:
            Hal_Uart_Print("#HELP #STATUS #LIST [slot] #LOG [index|CSV]\r\n");
            break;
        case 2:
            Hal_Uart_Print("KEY1=REG KEY2=REMOVE SAME/BOTH=EXIT\r\n");
            break;
        case 3:
            Hal_Uart_Print("#HELP TIME / #HELP DB : maintenance\r\n");
            g_console_output_step = 0;
            break;
        case 10:
            Hal_Uart_Print("#TIME : clock; #TIME YYMMDDhhmmss : set (CO)\r\n");
            break;
        case 11:
            Hal_Uart_Print("#TIME SYNC : coordinator -> terminal\r\n");
            g_console_output_step = 0;
            break;
        case 20:
            Hal_Uart_Print("#DB STATUS | #DB FIND UIDhex\r\n");
            break;
        case 21:
            Hal_Uart_Print("#DB SET slot 12digitID Name | #DB DEL slot\r\n");
            break;
        case 22:
            Hal_Uart_Print("#DB REG [12digitID Name] | #DB UNREG | #DB CANCEL\r\n");
            break;
        case 23:
            Hal_Uart_Print("#DB INIT CONFIRM : erase users/logs\r\n");
            break;
        case 24:
            Hal_Uart_Print("#DB UID | #DB BEEP | #DB STATS (CO)\r\n");
            break;
        case 25:
            Hal_Uart_Print("#DB STATS RESET CONFIRM : reset CO statistics\r\n");
            break;
        case 26:
            Hal_Uart_Print("Slots 0..7; UID 8/14/20 hex; Name ASCII 1..15\r\n");
            g_console_output_step = 0;
            break;
        case 40:
            App_Terminal_Network_Status(0);
            break;
        case 41:
            App_Terminal_Network_Status(1);
            g_console_output_step = 0;
            break;
        default:
            g_console_output_step = 0;
            break;
        }
        return;
    }
    /* һ���ظ���������������һ�ۣ�����ѭ���������������ű��� */
    if (g_list_command_type && !g_list_waiting_for_response && !g_pending_frame_length)
    {
        if (g_list_command_index >= (g_list_command_type == ATT_USER ? 8 : 10))
        {
            g_list_command_type = 0;
            Hal_Uart_Print("END\r\n");
            return;
        }
        index = g_list_command_index;
        g_list_waiting_for_response = 1;
        App_Terminal_Request(g_list_command_type, &index, 1);
    }
}

/* ==================== ������ʱ�ӡ���ʱ������ά�� ==================== */
void App_Terminal_Second_Process(void)
{
    static uint8 seconds;

    if (g_terminal_age_seconds < 255)
    {
        ++g_terminal_age_seconds;
    }
    if (g_mode_timeout_seconds != 0)
    {
        --g_mode_timeout_seconds;
        if (g_mode_timeout_seconds == 0)
        {
            App_Terminal_Set_Mode(0, NULL);
        }
    }

    if (g_peripherals_ready)
    {
        g_rtc_read_status = Hal_Rtc_Read_Time(&g_rtc_time);
        App_Ui_Time(&g_rtc_time, g_rtc_read_status);
        App_Ui_Second();
    }

    if (g_network_joined && g_terminal_age_seconds <= SAMPLEAPP_PEER_TIMEOUT_SECONDS)
    {
        HalLedSet(HAL_LED_1, HAL_LED_MODE_ON);
    }
    else
    {
        HalLedSet(HAL_LED_1, HAL_LED_MODE_TOGGLE);
    }

    ++seconds;
    if (g_network_joined && seconds % SAMPLEAPP_HELLO_INTERVAL_SECONDS == 0)
    {
        App_Terminal_Hello(0);
    }
    if (seconds == 240)
    {
        seconds = 0;
    }
}
