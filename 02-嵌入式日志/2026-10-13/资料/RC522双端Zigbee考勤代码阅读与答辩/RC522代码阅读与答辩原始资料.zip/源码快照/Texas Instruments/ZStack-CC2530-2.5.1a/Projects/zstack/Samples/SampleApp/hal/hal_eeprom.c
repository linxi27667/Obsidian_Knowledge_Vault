#include "OSAL.h"
#include "hal_eeprom.h"
#define EEPROM_WRITE_TIMEOUT_MS 20
static uint8 g_write_buf[EEPROM_WRITE_MAX];
static uint16 g_write_addr;
static uint16 g_capacity = EEPROM_CAPACITY;
static uint8 g_page_size = EEPROM_PAGE_SIZE, g_poll_address;
static uint8 g_write_len, g_write_pos, g_writing, g_waiting, g_result;
static uint32 g_write_start;
/* AT24C08: ��ַ����λ��������֣��Ͱ�λ��Ϊ�ֵ�ַ�� */
static uint8 Hal_Eeprom_Device(uint16 addr)
{
    return EEPROM_I2C_ADDR | (uint8)(addr >> 8);
}
uint8 Hal_Eeprom_Configure(uint16 size, uint8 page)
{
    if (g_writing)
    {
        return I2C_BUSY;
    }
    if (!((size == 256 && page == 8) || (size == 1024 && page == 16)))
    {
        return I2C_PARAM;
    }
    g_capacity = size;
    g_page_size = page;
    return I2C_OK;
}
uint8 Hal_Eeprom_Init(void)
{
    return Hal_I2c_Write(EEPROM_I2C_ADDR, NULL, 0);
}
uint8 Hal_Eeprom_Read(uint16 addr, uint8 *data, uint8 len)
{
    if (g_writing)
    {
        return I2C_BUSY;
    }
    uint8 n, status;
    uint16 remain;
    if (!data || !len || addr >= g_capacity || len > g_capacity - addr)
    {
        return I2C_PARAM;
    }
    while (len)
    {
        remain = 256 - (addr & 255);
        n = len > 32 ? 32 : len;
        if (n > remain)
        {
            n = (uint8)remain;
        }
        status = Hal_I2c_Read_Reg(Hal_Eeprom_Device(addr), (uint8)addr, data, n);
        if (status)
        {
            return status;
        }
        addr += n;
        data += n;
        len -= n;
    }
    return I2C_OK;
}
uint8 Hal_Eeprom_Read_Byte(uint16 addr, uint8 *value)
{
    return Hal_Eeprom_Read(addr, value, 1);
}
uint8 Hal_Eeprom_Write(uint16 addr, const uint8 *data, uint8 len)
{
    if (g_writing)
    {
        return I2C_BUSY;
    }
    if (!data || !len || len > EEPROM_WRITE_MAX || addr >= g_capacity || len > g_capacity - addr)
    {
        return I2C_PARAM;
    }
    osal_memcpy(g_write_buf, data, len);
    g_write_addr = addr;
    g_write_len = len;
    g_write_pos = g_waiting = 0;
    g_writing = 1;
    g_result = I2C_BUSY;
    return I2C_OK;
}
uint8 Hal_Eeprom_Write_Byte(uint16 addr, uint8 value)
{
    return Hal_Eeprom_Write(addr, &value, 1);
}
uint8 Hal_Eeprom_Is_Busy(void)
{
    return g_writing;
}
uint8 Hal_Eeprom_Process(void)
{
    uint8 n, status;
    if (!g_writing)
    {
        return g_result;
    }
    if (g_waiting)
    {
        status = Hal_I2c_Write(g_poll_address, NULL, 0);
        if (status == I2C_NACK &&
        (uint32)(osal_GetSystemClock() - g_write_start) < EEPROM_WRITE_TIMEOUT_MS)
        {
            return I2C_BUSY;
        }
        if (status)
        {
            g_result = status == I2C_NACK ? I2C_TIMEOUT : status;
            g_writing = 0;
            return g_result;
        }
        g_waiting = 0;
        if (g_write_pos == g_write_len)
        {
            g_writing = 0;
            g_result = I2C_OK;
            return g_result;
        }
    }
    /* ÿ���¼�����һҳ��ҳβ�ضϣ��ȴ��׶β�ռ�����ߡ� */
    n = g_page_size - ((g_write_addr + g_write_pos) % g_page_size);
    if (n > g_write_len - g_write_pos)
    {
        n = g_write_len - g_write_pos;
    }
    g_poll_address = Hal_Eeprom_Device(g_write_addr + g_write_pos);
    status = Hal_I2c_Write_Reg(g_poll_address, (uint8)(g_write_addr + g_write_pos), g_write_buf + g_write_pos, n);
    if (status)
    {
        g_result = status;
        g_writing = 0;
        return g_result;
    }
    g_write_pos += n;
    g_waiting = 1;
    g_write_start = osal_GetSystemClock();
    return I2C_BUSY;
}
