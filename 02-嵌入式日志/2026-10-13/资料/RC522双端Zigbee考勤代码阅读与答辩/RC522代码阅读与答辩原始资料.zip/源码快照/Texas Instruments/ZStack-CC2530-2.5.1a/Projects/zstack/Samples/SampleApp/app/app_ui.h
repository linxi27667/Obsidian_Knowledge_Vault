#ifndef APP_UI_H
#define APP_UI_H
#include "hal_rtc.h"
void App_Ui_Init(uint8 terminal);
void App_Ui_Status(uint8 network, uint8 peer, uint8 db_status, uint8 users, uint8 mode, uint8 seconds);
void App_Ui_Time(const rtc_time_t *time, uint8 status);
void App_Ui_Message(const char *title, const char *detail);
void App_Ui_Second(void);
void App_Ui_Tick(void);
uint8 App_Ui_Error(void);
#endif
