#ifndef APP_DATABASE_H
#define APP_DATABASE_H
#include "comm_protocol.h"
#define ATT_USERS 8
#define ATT_LOGS 10
#define ATT_USER_SIZE 40
/* ���� ATT_BUSY ��ʾ�ѽ����첽�ύ��ֻ�� App_Database_Tick ����ҽ��Ϊ OK ����ɹ��� */
void App_Database_Init(void);
void App_Database_Tick(void);
uint8 App_Database_Status(void);
uint8 App_Database_Count(void);
uint16 App_Database_Generation(void);
uint8 App_Database_Execute(uint8 op, const uint8 *p, uint8 n, uint16 session, uint16 tx, uint8 remote);
uint8 App_Database_Take_Done(void);
const uint8 *App_Database_Reply(void);
uint8 App_Database_Reply_Size(void);
const uint8 *App_Database_User(uint8 slot);
uint8 App_Database_Last_Scan_Mode(void);
uint8 App_Database_Request_Fresh(uint16 session, uint16 tx);
#endif
