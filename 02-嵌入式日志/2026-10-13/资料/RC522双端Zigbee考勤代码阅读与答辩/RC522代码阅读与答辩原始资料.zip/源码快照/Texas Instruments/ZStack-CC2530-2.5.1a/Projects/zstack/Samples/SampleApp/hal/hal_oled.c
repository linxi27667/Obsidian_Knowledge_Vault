#include "hal_i2c.h"
#include "hal_oled.h"

#define OLED_CONTROL_CMD 0x00
#define OLED_CONTROL_DATA 0x40
#define OLED_LINE_CHARS 21

static uint8 g_oled_address;

static const uint8 g_font5x7[36][5] = {
    {0x3E, 0x51, 0x49, 0x45, 0x3E}, {0x00, 0x42, 0x7F, 0x40, 0x00}, {0x42, 0x61, 0x51, 0x49, 0x46},
    {0x21, 0x41, 0x45, 0x4B, 0x31}, {0x18, 0x14, 0x12, 0x7F, 0x10}, {0x27, 0x45, 0x45, 0x45, 0x39},
    {0x3C, 0x4A, 0x49, 0x49, 0x30}, {0x01, 0x71, 0x09, 0x05, 0x03}, {0x36, 0x49, 0x49, 0x49, 0x36},
    {0x06, 0x49, 0x49, 0x29, 0x1E}, {0x7E, 0x11, 0x11, 0x11, 0x7E}, {0x7F, 0x49, 0x49, 0x49, 0x36},
    {0x3E, 0x41, 0x41, 0x41, 0x22}, {0x7F, 0x41, 0x41, 0x22, 0x1C}, {0x7F, 0x49, 0x49, 0x49, 0x41},
    {0x7F, 0x09, 0x09, 0x09, 0x01}, {0x3E, 0x41, 0x49, 0x49, 0x7A}, {0x7F, 0x08, 0x08, 0x08, 0x7F},
    {0x00, 0x41, 0x7F, 0x41, 0x00}, {0x20, 0x40, 0x41, 0x3F, 0x01}, {0x7F, 0x08, 0x14, 0x22, 0x41},
    {0x7F, 0x40, 0x40, 0x40, 0x40}, {0x7F, 0x02, 0x0C, 0x02, 0x7F}, {0x7F, 0x04, 0x08, 0x10, 0x7F},
    {0x3E, 0x41, 0x41, 0x41, 0x3E}, {0x7F, 0x09, 0x09, 0x09, 0x06}, {0x3E, 0x41, 0x51, 0x21, 0x5E},
    {0x7F, 0x09, 0x19, 0x29, 0x46}, {0x46, 0x49, 0x49, 0x49, 0x31}, {0x01, 0x01, 0x7F, 0x01, 0x01},
    {0x3F, 0x40, 0x40, 0x40, 0x3F}, {0x1F, 0x20, 0x40, 0x20, 0x1F}, {0x3F, 0x40, 0x38, 0x40, 0x3F},
    {0x63, 0x14, 0x08, 0x14, 0x63}, {0x07, 0x08, 0x70, 0x08, 0x07}, {0x61, 0x51, 0x49, 0x45, 0x43}};

static uint8 Hal_Oled_Set_Position(uint8 page, uint8 column)
{
    uint8 bytes[4];
    bytes[0] = OLED_CONTROL_CMD;
    bytes[1] = (uint8)(0xB0 | (page & 0x07));
    bytes[2] = (uint8)(column & 0x0F);
    bytes[3] = (uint8)(0x10 | (column >> 4));
    return Hal_I2c_Write(g_oled_address, bytes, sizeof(bytes));
}

static uint8 Hal_Oled_Clear(void)
{
    uint8 page, column, count, i, status;
    uint8 bytes[32];
    bytes[0] = OLED_CONTROL_DATA;
    for (i = 1; i < sizeof(bytes); ++i)
    {
        bytes[i] = 0;
    }
    for (page = 0; page < 8; ++page)
    {
        status = Hal_Oled_Set_Position(page, 0);
        if (status)
        {
            return status;
        }
        for (column = 0; column < 128; column = (uint8)(column + count))
        {
            count = (uint8)(128 - column);
            if (count > sizeof(bytes) - 1)
            {
                count = sizeof(bytes) - 1;
            }
            status = Hal_I2c_Write(g_oled_address, bytes, (uint8)(count + 1));
            if (status)
            {
                return status;
            }
        }
    }
    return I2C_OK;
}

static uint8 Hal_Oled_Clear_Page(uint8 page)
{
    uint8 column, count, i, status;
    uint8 bytes[32];
    bytes[0] = OLED_CONTROL_DATA;
    for (i = 1; i < sizeof(bytes); ++i)
    {
        bytes[i] = 0;
    }
    status = Hal_Oled_Set_Position(page, 0);
    if (status)
    {
        return status;
    }
    for (column = 0; column < 128; column = (uint8)(column + count))
    {
        count = (uint8)(128 - column);
        if (count > sizeof(bytes) - 1)
        {
            count = sizeof(bytes) - 1;
        }
        status = Hal_I2c_Write(g_oled_address, bytes, (uint8)(count + 1));
        if (status)
        {
            return status;
        }
    }
    return I2C_OK;
}

void Hal_Oled_Glyph(uint8 c, uint8 glyph[6])
{
    uint8 i;
    for (i = 0; i < 6; ++i)
    {
        glyph[i] = 0;
    }
    if (c >= 'a' && c <= 'z')
    {
        c = (uint8)(c - 'a' + 'A');
    }
    if (c >= '0' && c <= '9')
    {
        for (i = 0; i < 5; ++i)
        {
            glyph[i] = g_font5x7[c - '0'][i];
        }
    }
    else if (c >= 'A' && c <= 'Z')
    {
        for (i = 0; i < 5; ++i)
        {
            glyph[i] = g_font5x7[10 + c - 'A'][i];
        }
    }
    else if (c == ':')
    {
        glyph[1] = 0x36;
        glyph[2] = 0x36;
    }
    else if (c == '-')
    {
        glyph[1] = 0x08;
        glyph[2] = 0x08;
        glyph[3] = 0x08;
    }
    else if (c == '.')
    {
        glyph[2] = 0x60;
        glyph[3] = 0x60;
    }
}

uint8 Hal_Oled_Init(void)
{
    uint8 status;
    uint8 commands[] = {OLED_CONTROL_CMD,
        0xAE,
        0xD5,
        0x80,
        0xA8,
        0x3F,
        0xD3,
        0x00,
        0x40,
        0x8D,
        0x14,
        0x20,
        0x02,
        0xA1,
        0xC8,
        0xDA,
        0x12,
        0x81,
        0xCF,
        0xD9,
        0xF1,
        0xDB,
        0x40,
        0xA4,
        0xA6,
        0xAF};

    status = Hal_I2c_Probe(OLED_I2C_ADDR_0);
    if (!status)
    {
        g_oled_address = OLED_I2C_ADDR_0;
    }
    else if (status == I2C_NACK)
    {
        status = Hal_I2c_Probe(OLED_I2C_ADDR_1);
        if (!status)
        {
            g_oled_address = OLED_I2C_ADDR_1;
        }
    }
    if (status)
    {
        return status;
    }

    status = Hal_I2c_Write(g_oled_address, commands, sizeof(commands));
    if (status)
    {
        return status;
    }
    return Hal_Oled_Clear();
}

uint8 Hal_Oled_Get_Address(void)
{
    return g_oled_address;
}

uint8 Hal_Oled_Show_Line(uint8 page, const char *text)
{
    uint8 bytes[32], glyph[6], used, index, i, status;
    uint8 c;
    if (!text || page > 7 || !g_oled_address)
    {
        return I2C_PARAM;
    }
    status = Hal_Oled_Clear_Page(page);
    if (status)
    {
        return status;
    }
    status = Hal_Oled_Set_Position(page, 0);
    if (status)
    {
        return status;
    }
    bytes[0] = OLED_CONTROL_DATA;
    used = 1;
    index = 0;
    while (text[index] && index < OLED_LINE_CHARS)
    {
        if (used + sizeof(glyph) > sizeof(bytes))
        {
            status = Hal_I2c_Write(g_oled_address, bytes, used);
            if (status)
            {
                return status;
            }
            used = 1;
            bytes[0] = OLED_CONTROL_DATA;
        }
        c = (uint8)text[index++];
        Hal_Oled_Glyph(c, glyph);
        for (i = 0; i < sizeof(glyph); ++i)
        {
            bytes[used++] = glyph[i];
        }
    }
    if (used > 1)
    {
        return Hal_I2c_Write(g_oled_address, bytes, used);
    }
    return I2C_OK;
}

/* ÿ������31�У�Ӧ�ò��ʱ���ͣ�����ʱ��ռ��OSAL���� */
uint8 Hal_Oled_Write_Chunk(uint8 page, uint8 x, const uint8 *data, uint8 len)
{
    uint8 b[32], i, s;
    if (!g_oled_address || page > 7 || x > 127 || !len || len > 31 || len > 128 - x)
    {
        return I2C_PARAM;
    }
    s = Hal_Oled_Set_Position(page, x);
    if (s)
    {
        return s;
    }
    b[0] = 0x40;
    for (i = 0; i < len; i++)
    {
        b[i + 1] = data[i];
    }
    return Hal_I2c_Write(g_oled_address, b, len + 1);
}
