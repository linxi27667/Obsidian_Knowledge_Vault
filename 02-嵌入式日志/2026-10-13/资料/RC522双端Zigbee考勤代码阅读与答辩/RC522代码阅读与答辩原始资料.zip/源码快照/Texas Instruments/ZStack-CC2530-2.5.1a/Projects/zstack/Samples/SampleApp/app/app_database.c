/* �ն�AT24C08���ݿ⣺˫512�ֽھ���CRC16�����κš�����ύ��ǡ�
* RAM��ֻ��һ�ݾ���д���ڼ�ܾ���������ʧ��ʱװ�ؾɿ⡣
* �û�8*40�ֽڣ�����10*16�ֽڣ���־����ѧ�ſ��գ�ע�����ƻ���ʷ��
*/
#include "OSAL.h"
#include "app_database.h"
#include "hal_eeprom.h"
#include <string.h>
#define BANK_SIZE 512
#define USER_BASE 32
#define LOG_BASE 352
#define COMMIT 0xA5
static uint8 g_db[BANK_SIZE], g_check[32], g_reply[44];
static uint8 g_state, g_status, g_active, g_target, g_valid[2], g_blank[2], g_done, g_reply_size;
static uint16 g_offset, g_generations[2];
/* ״̬: 1/2 ���������⣬3 װ�أ�4 ʧЧ��ǣ�5 �ȴ���6 ����д��7 У�飬8 �ύ��9 �ύ�ȴ��� */
static uint16 App_Database_Image_Crc(void)
{
    uint16 crc, saved = Comm_Protocol_ReadUint16(g_db + 30);
    uint8 marker = g_db[5];
    g_db[5] = 0;
    g_db[30] = g_db[31] = 0;
    crc = Comm_Protocol_CalcChecksum(g_db, BANK_SIZE);
    g_db[5] = marker;
    Comm_Protocol_WriteUint16(g_db + 30, saved);
    return crc;
}
static uint8 App_Database_Image_Valid(void)
{
    uint8 i, *u;
    if (memcmp(g_db, "ATD2", 4) || g_db[4] != 2 || g_db[5] != COMMIT || g_db[8] >= ATT_LOGS ||
    g_db[9] > ATT_LOGS || Comm_Protocol_ReadUint16(g_db + 30) != App_Database_Image_Crc())
    {
        return 0;
    }
    for (i = 0; i < ATT_USERS; i++)
    {
        u = g_db + USER_BASE + (uint16)i * ATT_USER_SIZE;
        if (u[0] && u[0] != 4 && u[0] != 7 && u[0] != 10)
        {
            return 0;
        }
        if (u[38] != 0 || u[39] > 1)
        {
            return 0;
        }
    }
    return 1;
}
static void App_Database_Empty(void)
{
    osal_memset(g_db, 0, sizeof(g_db));
    osal_memcpy(g_db, "ATD2", 4);
    g_db[4] = 2;
    Comm_Protocol_WriteUint16(g_db + 10, 1);
}
void App_Database_Init(void)
{
    Hal_Eeprom_Configure(1024, 16);
    g_state = 1;
    g_offset = 0;
    g_active = 0xFF;
    g_valid[0] = g_valid[1] = 0;
    g_blank[0] = g_blank[1] = 1;
    g_status = ATT_BUSY;
    g_done = 0;
}
uint8 App_Database_Status(void)
{
    return g_state ? ATT_BUSY : g_status;
}
uint16 App_Database_Generation(void)
{
    return Comm_Protocol_ReadUint16(g_db + 6);
}
const uint8 *App_Database_User(uint8 slot)
{
    if (App_Database_Status() != ATT_OK || slot >= ATT_USERS || !g_db[USER_BASE + (uint16)slot * 40])
    {
        return NULL;
    }
    return g_db + USER_BASE + (uint16)slot * 40;
}
/* ԭATD2ͷ�������ֽ�22�������һ��Զ��ˢ����ʵ��ģʽ�� */
uint8 App_Database_Last_Scan_Mode(void)
{
    return g_db[22] <= 2 ? g_db[22] : 0;
}

uint8 App_Database_Request_Fresh(uint16 session, uint16 tx)
{
    uint16 delta = (uint16)(tx - Comm_Protocol_ReadUint16(g_db + 14));
    return g_db[19] != 1 || Comm_Protocol_ReadUint16(g_db + 12) != session || (delta && delta < 0x8000);
}
uint8 App_Database_Count(void)
{
    uint8 i, n = 0;
    if (App_Database_Status() != ATT_OK)
    {
        return 0;
    }
    for (i = 0; i < ATT_USERS; i++)
    {
        if (g_db[USER_BASE + (uint16)i * 40])
        {
            ++n;
        }
    }
    return n;
}
static void App_Database_Failed(void)
{
    /* ʧ�ܺ�����װ�ؾɿ⣬��ֹδ�־û����ݱ���ѯΪ�ɹ��� */
    g_reply[0] = ATT_STORAGE;
    g_offset = 0;
    if (g_active < 2)
    {
        g_target = g_active;
        g_state = 3;
        g_status = ATT_STORAGE;
    }
    else
    {
        App_Database_Empty();
        g_state = 0;
        g_status = ATT_STORAGE;
        g_done = 1;
    }
}
void App_Database_Tick(void)
{
    uint8 s, i, bank;
    if (!g_state)
    {
        return;
    }
    if (g_state <= 3)
    {
        bank = g_state == 3 ? g_target : g_state - 1;
        s = Hal_Eeprom_Read((uint16)bank * 512 + g_offset, g_db + g_offset, 32);
        if (s)
        {
            g_state = 0;
            g_status = ATT_STORAGE;
            g_done = 1;
            return;
        }
        if (g_state < 3)
        {
            for (i = 0; i < 32; i++)
            {
                if (g_db[g_offset + i] != 0xFF)
                {
                    g_blank[bank] = 0;
                }
            }
        }
        g_offset += 32;
        if (g_offset < 512)
        {
            return;
        }
        g_offset = 0;
        if (g_state == 3)
        {
            g_state = 0;
            g_status = App_Database_Image_Valid() ? ATT_OK : ATT_CORRUPT;
            Comm_Protocol_WriteUint16(g_reply + 2, App_Database_Generation());
            g_done = 1;
            return;
        }
        g_valid[bank] = App_Database_Image_Valid();
        g_generations[bank] = Comm_Protocol_ReadUint16(g_db + 6);
        if (g_state == 1)
        {
            g_state = 2;
            return;
        }
        if (g_valid[0] || g_valid[1])
        {
            g_active =
            (!g_valid[0] || (g_valid[1] && (uint16)(g_generations[1] - g_generations[0]) < 0x8000)) ? 1 : 0;
            g_target = g_active;
            g_state = 3;
        }
        else
        {
            g_state = 0;
            g_status = (g_blank[0] && g_blank[1]) ? ATT_OK : ATT_CORRUPT;
            App_Database_Empty();
        }
        return;
    }
    if (g_state == 4)
    {
        s = Hal_Eeprom_Write_Byte((uint16)g_target * 512 + 5, 0);
        if (s)
        {
            App_Database_Failed();
            return;
        }
        g_state = 5;
        return;
    }
    if (g_state == 5)
    {
        s = Hal_Eeprom_Process();
        if (s == I2C_BUSY)
        {
            return;
        }
        if (s)
        {
            App_Database_Failed();
            return;
        }
        g_state = 6;
        return;
    }
    if (g_state == 6)
    {
        s = Hal_Eeprom_Write((uint16)g_target * 512 + g_offset, g_db + g_offset, 32);
        if (s)
        {
            App_Database_Failed();
            return;
        }
        g_state = 7;
        return;
    }
    if (g_state == 7)
    {
        s = Hal_Eeprom_Process();
        if (s == I2C_BUSY)
        {
            return;
        }
        if (s || Hal_Eeprom_Read((uint16)g_target * 512 + g_offset, g_check, 32) ||
        memcmp(g_check, g_db + g_offset, 32))
        {
            App_Database_Failed();
            return;
        }
        g_offset += 32;
        g_state = g_offset == 512 ? 8 : 6;
        return;
    }
    if (g_state == 8)
    {
        s = Hal_Eeprom_Write_Byte((uint16)g_target * 512 + 5, COMMIT);
        if (s)
        {
            App_Database_Failed();
            return;
        }
        g_state = 9;
        return;
    }
    s = Hal_Eeprom_Process();
    if (s == I2C_BUSY)
    {
        return;
    }
    if (s || Hal_Eeprom_Read_Byte((uint16)g_target * 512 + 5, g_check) || g_check[0] != COMMIT)
    {
        App_Database_Failed();
        return;
    }
    g_db[5] = COMMIT;
    g_active = g_target;
    g_state = 0;
    g_status = ATT_OK;
    g_done = 1;
    Comm_Protocol_WriteUint16(g_reply + 2, App_Database_Generation());
}
static uint8 App_Database_Find(const uint8 *uid, uint8 n)
{
    uint8 i, *u;
    for (i = 0; i < ATT_USERS; i++)
    {
        u = g_db + USER_BASE + (uint16)i * 40;
        if (u[0] == n && !memcmp(u + 1, uid, n))
        {
            return i;
        }
    }
    return 0xFF;
}
static uint8 App_Database_Identity(const uint8 *id, const uint8 *name, uint8 except)
{
    uint8 i, j, *u;
    for (i = 0; i < 12; i++)
    {
        if (id[i] < '0' || id[i] > '9')
        {
            return ATT_PARAM;
        }
    }
    if (!name[0] || name[15])
    {
        return ATT_PARAM;
    }
    for (i = 0; i < 15 && name[i]; i++)
    {
        if (name[i] < 33 || name[i] > 126)
        {
            return ATT_PARAM;
        }
    }
    for (j = 0; j < ATT_USERS; j++)
    {
        u = g_db + USER_BASE + (uint16)j * 40;
        if (j != except && u[0] && !memcmp(u + 11, id, 12))
        {
            return ATT_EXISTS;
        }
    }
    return ATT_OK;
}
uint8 App_Database_Execute(uint8 op, const uint8 *p, uint8 n, uint16 session, uint16 tx, uint8 remote)
{
    uint8 slot = 0xFF, i, *u, *log, r = ATT_OK;
    uint16 sequence;
    if (g_state)
    {
        return ATT_BUSY;
    }
    g_reply_size = 4;
    g_reply[0] = ATT_OK;
    g_reply[1] = 0xFF;
    Comm_Protocol_WriteUint16(g_reply + 2, App_Database_Generation());
    g_done = 0;
    if (g_status != ATT_OK && op != ATT_FORMAT && op != ATT_META)
    {
        return g_reply[0] = g_status;
    }
    if (op == ATT_META && !n)
    {
        g_reply[0] = g_status;
        g_reply[4] = App_Database_Count();
        g_reply[5] = g_db[9];
        g_reply[6] = ATT_USERS;
        g_reply[7] = ATT_LOGS;
        g_reply_size = 8;
        return g_reply[0];
    }
    if (remote && op != ATT_USER && op != ATT_LOG && op != ATT_META && op != ATT_FIND &&
    g_db[19] == 1 && Comm_Protocol_ReadUint16(g_db + 12) == session && Comm_Protocol_ReadUint16(g_db + 14) == tx)
    {
        if (g_db[16] != op)
        {
            return g_reply[0] = ATT_PARAM;
        }
        g_reply[1] = g_db[17];
        return g_reply[0] = g_db[18];
    }
    /* ������Ƚ�����16λ����Ż��ƣ��ܾ�ͬ�Ự�Ѿ����ڵ��޸ġ� */
    if (remote && op != ATT_USER && op != ATT_LOG && op != ATT_META && op != ATT_FIND &&
    g_db[19] == 1 && Comm_Protocol_ReadUint16(g_db + 12) == session && (uint16)(tx - Comm_Protocol_ReadUint16(g_db + 14)) >= 0x8000)
    {
        return g_reply[0] = ATT_PARAM;
    }
    if (op == ATT_USER && n == 1 && p[0] < ATT_USERS)
    {
        slot = p[0];
        u = g_db + USER_BASE + (uint16)slot * 40;
        g_reply[1] = slot;
        if (!u[0])
        {
            return g_reply[0] = ATT_UNKNOWN;
        }
        osal_memcpy(g_reply + 4, u, 40);
        g_reply_size = 44;
        return ATT_OK;
    }
    if (op == ATT_FIND && n == 11 && (p[0] == 4 || p[0] == 7 || p[0] == 10))
    {
        slot = App_Database_Find(p + 1, p[0]);
        if (slot == 0xFF)
        {
            return g_reply[0] = ATT_UNKNOWN;
        }
        g_reply[1] = slot;
        osal_memcpy(g_reply + 4, g_db + USER_BASE + (uint16)slot * 40, 40);
        g_reply_size = 44;
        return ATT_OK;
    }
    if (op == ATT_LOG && n == 1 && p[0] < g_db[9])
    {
        slot = (g_db[8] + ATT_LOGS - 1 - p[0]) % ATT_LOGS;
        osal_memcpy(g_reply + 4, g_db + LOG_BASE + (uint16)slot * 16, 16);
        g_reply[1] = p[0];
        g_reply_size = 20;
        return ATT_OK;
    }
    if (op == ATT_LOG && n == 1 && p[0] < ATT_LOGS)
    {
        return g_reply[0] = ATT_UNKNOWN;
    }
    if (op == ATT_SCAN && n == 48 && p[0] <= 2 && (p[1] == 4 || p[1] == 7 || p[1] == 10))
    {
        slot = App_Database_Find(p + 2, p[1]);
        if (p[0] == 1)
        {
            if (slot != 0xFF)
            {
                return g_reply[0] = ATT_EXISTS;
            }
            for (slot = 0; slot < ATT_USERS; slot++)
            {
                if (!g_db[USER_BASE + (uint16)slot * 40])
                {
                    break;
                }
            }
            if (slot == ATT_USERS)
            {
                return g_reply[0] = ATT_FULL;
            }
            u = g_db + USER_BASE + (uint16)slot * 40;
            /* Ĭ�ϱ�ŵ�������������ע����λ���ö�����ѧ�š� */
            if (!p[12])
            {
                sequence = Comm_Protocol_ReadUint16(g_db + 10);
                do
                {
                    if (!sequence)
                    {
                        return g_reply[0] = ATT_FULL;
                    }
                    osal_memcpy(g_check, "202600000000", 12);
                    i = 12;
                    {
                        uint16 v = sequence;
                        while (v && i)
                        {
                            g_check[--i] = '0' + v % 10;
                            v /= 10;
                        }
                    }
                    osal_memset(g_check + 12, 0, 16);
                    osal_memcpy(g_check + 12, "Student", 7);
                    g_check[19] = '1' + slot;
                    r = App_Database_Identity(g_check, g_check + 12, slot);
                    ++sequence;
                } while (r == ATT_EXISTS);
                Comm_Protocol_WriteUint16(g_db + 10, sequence);
                osal_memcpy(u + 11, g_check, 28);
            }
            else
            {
                r = App_Database_Identity(p + 12, p + 24, slot);
                if (r)
                {
                    return g_reply[0] = r;
                }
                osal_memcpy(u + 11, p + 12, 28);
            }
            u[0] = p[1];
            osal_memcpy(u + 1, p + 2, 10);
            u[39] = 1;
        }
        else
        {
            if (slot == 0xFF)
            {
                return g_reply[0] = ATT_UNKNOWN;
            }
            u = g_db + USER_BASE + (uint16)slot * 40;
            if (p[0] == 2)
            {
                osal_memset(u, 0, 40);
            }
            else
            {
                log = g_db + LOG_BASE + (uint16)g_db[8] * 16;
                for (i = 0; i < 6; i++)
                {
                    log[i] = ((u[11 + i * 2] - '0') << 4) | (u[12 + i * 2] - '0');
                }
                osal_memcpy(log + 6, p + 40, 6);
                log[12] = p[46];
                log[13] = p[47];
                sequence = Comm_Protocol_ReadUint16(g_db + 20) + 1;
                Comm_Protocol_WriteUint16(g_db + 20, sequence);
                Comm_Protocol_WriteUint16(log + 14, sequence);
                g_db[8] = (g_db[8] + 1) % ATT_LOGS;
                if (g_db[9] < ATT_LOGS)
                {
                    ++g_db[9];
                }
            }
        }
    }
    else if (op == ATT_SET && n == 29 && p[0] < ATT_USERS)
    {
        slot = p[0];
        u = g_db + USER_BASE + (uint16)slot * 40;
        if (!u[0])
        {
            return g_reply[0] = ATT_UNKNOWN;
        }
        r = App_Database_Identity(p + 1, p + 13, slot);
        if (r)
        {
            return g_reply[0] = r;
        }
        osal_memcpy(u + 11, p + 1, 28);
    }
    else if (op == ATT_DELETE && n == 1 && p[0] < ATT_USERS)
    {
        slot = p[0];
        u = g_db + USER_BASE + (uint16)slot * 40;
        if (!u[0])
        {
            return g_reply[0] = ATT_UNKNOWN;
        }
        osal_memset(u, 0, 40);
    }
    else if (op == ATT_FORMAT && n == 4 && !memcmp(p, "INIT", 4))
    {
        sequence = App_Database_Generation();
        App_Database_Empty();
        Comm_Protocol_WriteUint16(g_db + 6, sequence);
    }
    else
    {
        return g_reply[0] = ATT_PARAM;
    }
    g_reply[1] = slot;
    if (remote)
    {
        Comm_Protocol_WriteUint16(g_db + 12, session);
        Comm_Protocol_WriteUint16(g_db + 14, tx);
        g_db[16] = op;
        g_db[17] = slot;
        g_db[18] = ATT_OK;
        g_db[19] = 1;
        if (op == ATT_SCAN)
        {
            g_db[22] = p[0];
        }
    }
    Comm_Protocol_WriteUint16(g_db + 6, App_Database_Generation() + 1);
    g_db[5] = 0;
    Comm_Protocol_WriteUint16(g_db + 30, App_Database_Image_Crc());
    g_target = g_active == 0 ? 1 : 0;
    g_offset = 0;
    g_state = 4;
    return ATT_BUSY;
}
uint8 App_Database_Take_Done(void)
{
    uint8 v = g_done;
    g_done = 0;
    return v;
}
const uint8 *App_Database_Reply(void)
{
    return g_reply;
}
uint8 App_Database_Reply_Size(void)
{
    return g_reply_size;
}
