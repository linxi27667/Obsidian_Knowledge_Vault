#ifndef HAL_RC522_H
#define HAL_RC522_H
#include "ZComDef.h"
#define RC522_OK 0
#define RC522_NO_RESPONSE 1
#define RC522_PROTOCOL_ERROR 2
#define RC522_NOT_READY 3
#define RC522_BAD_PARAM 4
#define RC522_UID_MAX 10
extern uint8 g_rc522_last_error;
extern uint8 g_rc522_version;
bool Hal_Rc522_Init(void);
bool Hal_Rc522_Reset(void);
uint8 Hal_Rc522_Read_Reg(uint8 reg);
void Hal_Rc522_Write_Reg(uint8 reg, uint8 value);
bool Hal_Rc522_Request(uint8 atqa[2]);
bool Hal_Rc522_Anticoll(uint8 level, uint8 block[5]);
bool Hal_Rc522_Select(uint8 level, const uint8 block[5], uint8 *sak);
/* ֧��4/7/10�ֽ�UID���࿨��ײ���ش��󣬲�����Ȩ���жϡ� */
bool Hal_Rc522_Read_Uid(uint8 uid[RC522_UID_MAX], uint8 *len);
#endif
