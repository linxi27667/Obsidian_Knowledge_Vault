/* ���� UART Ψһӵ���ߣ�RX ����һ�н�����ɫ���ļ���TX ÿ������ƽ�32�ֽڡ� */
#include "OSAL.h"
#include "board_config.h"
#include "hal_console_uart.h"
#include "hal_uart.h"
#include <stdarg.h>
#include <string.h>

#define DBG_TX_CAPACITY 256
#define DBG_TX_CHUNK 32
#define DBG_LINE_CAPACITY 80
static uint8 g_transmit_buffer[DBG_TX_CAPACITY];
static uint8 g_transmit_read_index;
static uint8 g_transmit_write_index;
static uint8 g_receive_task_id;
static uint16 g_receive_event;
static char g_receive_line[DBG_LINE_CAPACITY];
static uint8 g_receive_line_length;
static uint8 g_receive_line_overflow;
static void (*g_line_callback)(char *);
uint16 g_uart_dropped;

static void Hal_Uart_Rx_Callback(uint8 port, uint8 event)
{
    (void)port;
    (void)event;
    osal_set_event(g_receive_task_id, g_receive_event);
}
void Hal_Uart_Init(uint8 task, uint16 event)
{
    halUARTCfg_t cfg;
    g_receive_task_id = task;
    g_receive_event = event;
    g_transmit_read_index = 0;
    g_transmit_write_index = 0;
    g_receive_line_length = 0;
    g_receive_line_overflow = 0;
    g_uart_dropped = 0;
    osal_memset(&cfg, 0, sizeof(cfg));
    cfg.configured = TRUE;
    cfg.baudRate = HAL_UART_BR_38400;
    cfg.flowControl = FALSE;
    cfg.rx.maxBufSize = 128;
    cfg.tx.maxBufSize = 128;
    cfg.idleTimeout = 6;
    cfg.intEnable = TRUE;
    cfg.callBackFunc = Hal_Uart_Rx_Callback;
    HalUARTOpen(BOARD_DEBUG_UART_PORT, &cfg);
}
static void Hal_Uart_Queue_Byte(char c)
{
#if ENABLE_DEBUG_LOG
    uint8 next = g_transmit_write_index + 1;
    if (next == g_transmit_read_index)
    {
        ++g_uart_dropped;
        return;
    }
    g_transmit_buffer[g_transmit_write_index] = (uint8)c;
    g_transmit_write_index = next;
#else
    (void)c;
#endif
}
/* ��� Device1_UART_SendData �Խӣ�����������Ҳ��ԭ������ӡ� */
void Hal_Uart_Write(const uint8 *data, uint8 length)
{
    uint8 index;

    if (data == NULL)
    {
        return;
    }
    for (index = 0; index < length; ++index)
    {
        Hal_Uart_Queue_Byte((char)data[index]);
    }
}

void Hal_Uart_Print(char *text)
{
    while (*text)
    {
        Hal_Uart_Queue_Byte(*text++);
    }
}
void Hal_Uart_Printf(char *format, ...)
{
    va_list args;
    uint16 value, divisor;
    uint8 digit, started;
    va_start(args, format);
    while (*format)
    {
        if (*format != '%')
        {
            Hal_Uart_Queue_Byte(*format++);
            continue;
        }
        ++format;
        if (!*format)
        {
            break;
        }
        switch (*format++)
        {
        case 's':
            Hal_Uart_Print(va_arg(args, char *));
            break;
        case 'c':
            Hal_Uart_Queue_Byte((char)va_arg(args, int));
            break;
        case 'x':
            value = va_arg(args, unsigned int);
            for (divisor = 0x1000; divisor; divisor >>= 4)
            {
                digit = (uint8)((value / divisor) & 15);
                Hal_Uart_Queue_Byte(digit < 10 ? '0' + digit : 'A' + digit - 10);
            }
            break;
        case 'u':
            value = va_arg(args, unsigned int);
            started = 0;
            for (divisor = 10000; divisor; divisor /= 10)
            {
                digit = (uint8)(value / divisor);
                value %= divisor;
                if (digit || started || divisor == 1)
                {
                    Hal_Uart_Queue_Byte('0' + digit);
                    started = 1;
                }
            }
            break;
        default:
            Hal_Uart_Queue_Byte('?');
            break;
        }
    }
    va_end(args);
}
void Hal_Uart_Flush(void)
{
    uint8 len = (uint8)(g_transmit_write_index - g_transmit_read_index);
    uint16 contiguous = DBG_TX_CAPACITY - (uint16)g_transmit_read_index;
    if (len > DBG_TX_CHUNK)
    {
        len = DBG_TX_CHUNK;
    }
    if (len > contiguous)
    {
        len = (uint8)contiguous;
    }
    /* HALд���岻����������һ���¼��������ȴ�TX��ɡ� */
    if (len)
    {
        g_transmit_read_index += (uint8)HalUARTWrite(BOARD_DEBUG_UART_PORT, g_transmit_buffer + g_transmit_read_index, len);
    }
}

void Hal_Uart_Set_Handler(void (*handler)(char *))
{
    g_line_callback = handler;
}
uint8 Hal_Uart_Free(void)
{
    return 255 - (uint8)(g_transmit_write_index - g_transmit_read_index);
}
uint8 Hal_Uart_Process_Rx(void)
{
    uint8 i, c;
    /* ����������32�ֽڣ�CR��LF��CRLF�����ã�������ж����� */
    for (i = 0; i < 32; i++)
    {
        if (HalUARTRead(BOARD_DEBUG_UART_PORT, &c, 1) != 1)
        {
            break;
        }
        if (c == '\r' || c == '\n')
        {
            if (g_receive_line_length || g_receive_line_overflow)
            {
                g_receive_line[g_receive_line_length] = 0;
                if (g_receive_line_overflow)
                {
                    Hal_Uart_Print("ERR LINE_TOO_LONG\r\n");
                }
                else if (g_line_callback)
                {
                    g_line_callback(g_receive_line);
                }
            }
            g_receive_line_length = 0;
            g_receive_line_overflow = 0;
        }
        else if (c == 8 || c == 127)
        {
            if (g_receive_line_length && !g_receive_line_overflow)
            {
                --g_receive_line_length;
            }
        }
        else if (c >= 32 && c <= 126)
        {
            if (g_receive_line_length < DBG_LINE_CAPACITY - 1)
            {
                g_receive_line[g_receive_line_length++] = (char)c;
            }
            else
            {
                g_receive_line_overflow = 1;
            }
        }
        else
        {
            g_receive_line_overflow = 1;
        }
    }
    if (Hal_UART_RxBufLen(BOARD_DEBUG_UART_PORT))
    {
        osal_set_event(g_receive_task_id, g_receive_event);
    }
    return 0;
}
