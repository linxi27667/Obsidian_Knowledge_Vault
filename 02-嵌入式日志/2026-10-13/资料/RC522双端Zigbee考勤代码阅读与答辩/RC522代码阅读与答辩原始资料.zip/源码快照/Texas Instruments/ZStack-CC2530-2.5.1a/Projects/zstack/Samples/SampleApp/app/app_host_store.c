/* Э��������ͳ�ơ�ֻ���ն�ȷ�ϳɹ��������ͳ�ƹ��ϲ�ð�俼�����ʧ�ܡ�
* ��д��Ч��ǣ���д���ݲ����أ����д�ύ��ǡ���һ����һֱ������
* ���Զ����Ƿǿ����޷�ʶ���EEPROM���ݣ�#DB STATS RESET CONFIRM��ʽ�ؽ��� */
#include "OSAL.h"
#include "app_host_store.h"
#include "comm_protocol.h"
#include "hal_eeprom.h"
#include <string.h>

#define HOST_IMAGE_SIZE 64
#define HOST_COMMIT 0xA5
#define HOST_IDLE 0
#define HOST_LOAD 1
#define HOST_INVALIDATE 2
#define HOST_INVALIDATE_WAIT 3
#define HOST_WRITE 4
#define HOST_VERIFY 5
#define HOST_COMMIT_WRITE 6
#define HOST_COMMIT_WAIT 7

static uint8 g_images[2][HOST_IMAGE_SIZE];
static uint8 g_verify_buffer[32];
static uint8 g_state, g_status, g_active_bank, g_target_bank, g_offset, g_load_bank;

static uint16 App_Host_Store_Image_Crc(uint8 *image)
{
    uint8 marker = image[5];
    uint16 saved_crc = Comm_Protocol_ReadUint16(image + 62);
    uint16 crc;

    image[5] = 0;
    image[62] = 0;
    image[63] = 0;
    crc = Comm_Protocol_CalcChecksum(image, HOST_IMAGE_SIZE);
    image[5] = marker;
    Comm_Protocol_WriteUint16(image + 62, saved_crc);
    return crc;
}

static uint8 App_Host_Store_Image_Valid(uint8 *image)
{
    return memcmp(image, "HST1", 4) == 0 && image[4] == 1 && image[5] == HOST_COMMIT &&
    Comm_Protocol_ReadUint16(image + 62) == App_Host_Store_Image_Crc(image);
}

static uint8 App_Host_Store_Is_Blank(void)
{
    uint8 bank, index;

    for (bank = 0; bank < 2; ++bank)
    {
        for (index = 0; index < HOST_IMAGE_SIZE; ++index)
        {
            if (g_images[bank][index] != 0xFF)
            {
                return 0;
            }
        }
    }
    return 1;
}

static void App_Host_Store_Image_Empty(uint8 *image)
{
    osal_memset(image, 0, HOST_IMAGE_SIZE);
    osal_memcpy(image, "HST1", 4);
    image[4] = 1;
}

static void App_Host_Store_Save_Start(void)
{
    uint8 *image = g_images[g_target_bank];

    Comm_Protocol_WriteUint16(image + 6, Comm_Protocol_ReadUint16(g_images[g_active_bank] + 6) + 1);
    image[5] = 0;
    Comm_Protocol_WriteUint16(image + 62, App_Host_Store_Image_Crc(image));
    g_offset = 0;
    g_state = HOST_INVALIDATE;
}

static void App_Host_Store_Count_Increment(uint8 *value)
{
    uint16 count = Comm_Protocol_ReadUint16(value);

    /* �γ̰�ͳ�Ƶ�65535�󱣳ָ�ֵ�������Ƴ��㡣 */
    if (count < 65535)
    {
        Comm_Protocol_WriteUint16(value, count + 1);
    }
}

void App_Host_Store_Init(void)
{
    Hal_Eeprom_Configure(256, 8);
    g_load_bank = 0;
    g_offset = 0;
    g_active_bank = 0;
    g_status = ATT_BUSY;
    g_state = HOST_LOAD;
}

uint8 App_Host_Store_Status(void)
{
    return g_state != HOST_IDLE ? ATT_BUSY : g_status;
}

uint16 App_Host_Store_Count(uint8 mode)
{
    if (mode > 2 || g_status != ATT_OK)
    {
        return 0;
    }
    return Comm_Protocol_ReadUint16(g_images[g_active_bank] + 10 + mode * 2);
}

uint16 App_Host_Store_Boot_Count(void)
{
    return g_status == ATT_OK ? Comm_Protocol_ReadUint16(g_images[g_active_bank] + 8) : 0;
}

uint8 App_Host_Store_Record(uint8 mode, const uint8 *uid, uint8 uid_length,
const rtc_time_t *time, uint8 time_status)
{
    uint8 *image;

    if (g_state != HOST_IDLE)
    {
        return ATT_BUSY;
    }
    if (g_status != ATT_OK)
    {
        return g_status;
    }
    if (mode > 2 || uid == NULL || time == NULL ||
    (uid_length != 4 && uid_length != 7 && uid_length != 10))
    {
        return ATT_PARAM;
    }

    g_target_bank = g_active_bank ^ 1;
    image = g_images[g_target_bank];
    osal_memcpy(image, g_images[g_active_bank], HOST_IMAGE_SIZE);
    App_Host_Store_Count_Increment(image + 10 + mode * 2);
    image[16] = uid_length;
    osal_memset(image + 17, 0, 10);
    osal_memcpy(image + 17, uid, uid_length);
    image[27] = time->year;
    image[28] = time->month;
    image[29] = time->day;
    image[30] = time->hour;
    image[31] = time->minute;
    image[32] = time->second;
    image[33] = time_status == 0;
    App_Host_Store_Save_Start();
    return ATT_OK;
}

uint8 App_Host_Store_Reset(void)
{
    if (g_state != HOST_IDLE)
    {
        return ATT_BUSY;
    }
    g_target_bank = g_active_bank ^ 1;
    App_Host_Store_Image_Empty(g_images[g_target_bank]);
    App_Host_Store_Save_Start();
    return ATT_BUSY;
}

void App_Host_Store_Process(void)
{
    uint8 result, valid0, valid1;
    uint16 address;

    if (g_state == HOST_IDLE)
    {
        return;
    }

    if (g_state == HOST_LOAD)
    {
        result = Hal_Eeprom_Read((uint16)g_load_bank * HOST_IMAGE_SIZE + g_offset,
        g_images[g_load_bank] + g_offset, 32);
        if (result != I2C_OK)
        {
            g_status = ATT_STORAGE;
            g_state = HOST_IDLE;
            return;
        }
        g_offset += 32;
        if (g_offset < HOST_IMAGE_SIZE)
        {
            return;
        }
        g_offset = 0;
        if (++g_load_bank < 2)
        {
            return;
        }

        valid0 = App_Host_Store_Image_Valid(g_images[0]);
        valid1 = App_Host_Store_Image_Valid(g_images[1]);
        if (valid0 || valid1)
        {
            g_active_bank = !valid0 || (valid1 &&
            (uint16)(Comm_Protocol_ReadUint16(g_images[1] + 6) - Comm_Protocol_ReadUint16(g_images[0] + 6)) < 0x8000) ? 1 : 0;
        }
        else if (App_Host_Store_Is_Blank())
        {
            g_active_bank = 0;
            App_Host_Store_Image_Empty(g_images[0]);
        }
        else
        {
            g_status = ATT_CORRUPT;
            g_state = HOST_IDLE;
            return;
        }

        g_status = ATT_OK;
        g_target_bank = g_active_bank ^ 1;
        osal_memcpy(g_images[g_target_bank], g_images[g_active_bank], HOST_IMAGE_SIZE);
        App_Host_Store_Count_Increment(g_images[g_target_bank] + 8);
        App_Host_Store_Save_Start();
        return;
    }

    address = (uint16)g_target_bank * HOST_IMAGE_SIZE;
    switch (g_state)
    {
    case HOST_INVALIDATE:
        result = Hal_Eeprom_Write_Byte(address + 5, 0);
        if (result == I2C_OK)
        {
            g_state = HOST_INVALIDATE_WAIT;
        }
        break;

    case HOST_INVALIDATE_WAIT:
        result = Hal_Eeprom_Process();
        if (result == I2C_OK)
        {
            g_state = HOST_WRITE;
        }
        break;

    case HOST_WRITE:
        result = Hal_Eeprom_Write(address + g_offset, g_images[g_target_bank] + g_offset, 32);
        if (result == I2C_OK)
        {
            g_state = HOST_VERIFY;
        }
        break;

    case HOST_VERIFY:
        result = Hal_Eeprom_Process();
        if (result != I2C_OK)
        {
            break;
        }
        if (Hal_Eeprom_Read(address + g_offset, g_verify_buffer, 32) != I2C_OK ||
        memcmp(g_verify_buffer, g_images[g_target_bank] + g_offset, 32) != 0)
        {
            result = I2C_NACK;
            break;
        }
        g_offset += 32;
        g_state = g_offset == HOST_IMAGE_SIZE ? HOST_COMMIT_WRITE : HOST_WRITE;
        break;

    case HOST_COMMIT_WRITE:
        result = Hal_Eeprom_Write_Byte(address + 5, HOST_COMMIT);
        if (result == I2C_OK)
        {
            g_state = HOST_COMMIT_WAIT;
        }
        break;

    default:
        result = Hal_Eeprom_Process();
        if (result != I2C_OK)
        {
            break;
        }
        if (Hal_Eeprom_Read_Byte(address + 5, g_verify_buffer) != I2C_OK || g_verify_buffer[0] != HOST_COMMIT)
        {
            result = I2C_NACK;
            break;
        }
        g_images[g_target_bank][5] = HOST_COMMIT;
        g_active_bank = g_target_bank;
        g_status = ATT_OK;
        g_state = HOST_IDLE;
        break;
    }

    if (result != I2C_OK && result != I2C_BUSY)
    {
        /* �����δ���޸ģ�ʧ��ʱ�Ա����ϴγɹ�ͳ�ơ� */
        g_status = ATT_STORAGE;
        g_state = HOST_IDLE;
    }
}
