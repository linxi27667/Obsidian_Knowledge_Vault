#include "OSAL.h"
#include "app_ui.h"
#include "comm_protocol.h"
#include "app_font.h"
#include "hal_oled.h"
#include <string.h>

/* ÿ��ֻ����һҳ 128 �ֽڣ������� CC2530 XDATA �з�����֡���塣 */
static uint8 g_pixels[128];
static uint8 g_page, g_column, g_dirty, g_painting, g_error;
static uint8 g_role, g_network, g_peer_online, g_db_status, g_users, g_mode, g_seconds;
static uint8 g_clock_status, g_message_seconds;
static rtc_time_t g_clock_time;
static char g_title[22], g_detail[22];

static void App_Ui_Copy(char *target, const char *source)
{
    uint8 index = 0;
    while (index < 21 && source[index])
    {
        target[index] = source[index];
        ++index;
    }
    target[index] = 0;
}

/* ���÷�����ԭ��Ӣ��״̬�룻����ֻת�� OLED �İ������ı䴮��Э�顣 */
static const char *App_Ui_Chinese(const char *text)
{
    static const struct
    {
        const char *english;
        const char *chinese;
    } messages[] = {
        {"OK", CN_OK},
        {"BUSY", CN_BUSY},
        {"BAD PARAMETER", CN_BAD_PARAMETER},
        {"UNKNOWN CARD", CN_UNKNOWN_CARD},
        {"DATABASE FULL", CN_DATABASE_FULL},
        {"ALREADY EXISTS", CN_ALREADY_EXISTS},
        {"CARD ALREADY REGISTERED", CN_CARD_ALREADY_REGISTERED},
        {"CARD NOT REGISTERED", CN_CARD_NOT_REGISTERED},
        {"ATTENDANCE UNREGISTERED", CN_ATTENDANCE_UNREGISTERED},
        {"STORAGE ERROR", CN_STORAGE_ERROR},
        {"DATABASE CORRUPT", CN_DATABASE_CORRUPT},
        {"READER OFFLINE", CN_PEER_OFFLINE},
        {"ACK TIMEOUT", CN_ACK_TIMEOUT},
        {"PROTOCOL ERROR", CN_PROTOCOL_ERROR},
        {"CARD PROCESSED", CN_CARD_PROCESSED},
        {"DATABASE COMMAND", CN_DATABASE_COMMAND},
        {"CARD OK", CN_CARD_OK},
        {"REGISTER OK", CN_REGISTER_OK},
        {"REMOVE OK", CN_REMOVE_OK},
        {"ATTENDANCE OK", CN_ATTENDANCE_OK},
        {"REGISTER MODE", CN_REGISTER_MODE},
        {"REMOVE MODE", CN_REMOVE_MODE},
        {"ATTENDANCE MODE", CN_ATTENDANCE_MODE},
        {"SCAN WITHIN 30 SEC", CN_SCAN_WITHIN_30_SEC},
        {"SCAN REGISTERED CARD", CN_SCAN_REGISTERED_CARD},
        {"REMOVE AND RESCAN", CN_REMOVE_AND_RESCAN},
        {"NETWORK READY", CN_NETWORK_READY},
        {"ATTENDANCE ONLINE", CN_ATTENDANCE_ONLINE},
        {"NETWORK WAIT", CN_NETWORK_WAIT},
        {"LOCAL ATTENDANCE READY", CN_LOCAL_ATTENDANCE_READY},
        {"SAVING", CN_SAVING},
        {"DO NOT POWER OFF", CN_DO_NOT_POWER_OFF},
        {"REMOVE ONE CARD", CN_REMOVE_ONE_CARD}};
    uint8 index;
    for (index = 0; index < sizeof(messages) / sizeof(messages[0]); ++index)
    {
        if (strcmp(text, messages[index].english) == 0)
        {
            return messages[index].chinese;
        }
    }
    return text;
}

static void App_Ui_Pair(char *target, uint8 value)
{
    target[0] = '0' + value / 10;
    target[1] = '0' + value % 10;
}

/* ���� GBK ˫�ֽ����򣬲��Ҷ�Ӧ�� 16x16 ���Ρ� */
static const att_hanzi_t *App_Ui_Hanzi(uint16 code)
{
    uint8 low = 0;
    uint8 high = ATT_HANZI_COUNT;
    uint8 middle;
    while (low < high)
    {
        middle = (uint8)((low + high) / 2);
        if (g_att_hanzi[middle].code < code)
        {
            low = (uint8)(middle + 1);
        }
        else
        {
            high = middle;
        }
    }
    if (low < ATT_HANZI_COUNT && g_att_hanzi[low].code == code)
    {
        return &g_att_hanzi[low];
    }
    return NULL;
}

/* ͬһ�з���ҳ���ƣ����ֿ� 16���� 16�����ֺͱ�����°�ҳ��ʾ�� */
static void App_Ui_Text(uint8 x, const char *string, uint8 half)
{
    uint8 glyph[6], index;
    uint8 lead, trail;
    uint16 code;
    const att_hanzi_t *hanzi;
    while (*string && x < 128)
    {
        lead = (uint8)*string;
        if (lead >= 0x81 && string[1])
        {
            if (x > 112)
            {
                break;
            }
            trail = (uint8)string[1];
            code = ((uint16)lead << 8) | trail;
            hanzi = App_Ui_Hanzi(code);
            if (hanzi != NULL)
            {
                for (index = 0; index < 16; ++index)
                {
                    g_pixels[x + index] = hanzi->bitmap[half * 16 + index];
                }
            }
            x = (uint8)(x + 16);
            string += 2;
        }
        else
        {
            if (x > 122)
            {
                break;
            }
            if (half)
            {
                Hal_Oled_Glyph(lead, glyph);
                for (index = 0; index < 6; ++index)
                {
                    g_pixels[x + index] = glyph[index];
                }
            }
            x = (uint8)(x + 6);
            ++string;
        }
    }
}

static uint8 App_Ui_Width(const char *string)
{
    uint8 width = 0;
    while (*string)
    {
        if ((uint8)*string >= 0x81 && string[1])
        {
            width = (uint8)(width + 16);
            string += 2;
        }
        else
        {
            width = (uint8)(width + 6);
            ++string;
        }
    }
    return width;
}

static void App_Ui_Center(const char *string, uint8 half)
{
    uint8 width = App_Ui_Width(string);
    App_Ui_Text(width < 128 ? (uint8)((128 - width) / 2) : 0, string, half);
}

/* ����ԭ�� 5x7 ������ģ�������Ŵ�ʱ�䣬��Ȼ��ҳ���ɡ� */
static void App_Ui_Big_Time(uint8 half, const char *string)
{
    uint8 glyph[6], index, row, x = 16, bits;
    uint16 expanded;
    while (*string && x <= 116)
    {
        Hal_Oled_Glyph(*string++, glyph);
        for (index = 0; index < 6; ++index)
        {
            expanded = 0;
            for (row = 0; row < 8; ++row)
            {
                if (glyph[index] & (1 << row))
                {
                    expanded |= (uint16)3 << (row * 2);
                }
            }
            bits = half ? (uint8)(expanded >> 8) : (uint8)expanded;
            g_pixels[x++] = bits;
            g_pixels[x++] = bits;
        }
    }
}

static void App_Ui_Render(void)
{
    char value[16];
    uint8 line = g_page / 2;
    uint8 half = g_page & 1;
    uint8 index;
    osal_memset(g_pixels, 0, sizeof(g_pixels));

    if (line == 0)
    {
        App_Ui_Text(4, g_role ? CN_TERMINAL : CN_COORDINATOR, half);
        App_Ui_Text(80, g_network ? CN_ONLINE : CN_OFFLINE, half);
        if (g_network)
        {
            g_pixels[117] = g_pixels[118] = half ? 0xF0 : 0;
            g_pixels[121] = g_pixels[122] = half ? 0xFF : 0;
            g_pixels[125] = g_pixels[126] = half ? 0xFF : 0xC0;
        }
        for (index = 0; index < 128; ++index)
        {
            g_pixels[index] ^= 0xFF;
        }
    }
    else if (line == 1)
    {
        if (g_message_seconds)
        {
            if (strcmp(g_title, CN_PEER_OFFLINE) == 0)
            {
                /* ����ˢ����ʾ��ʾʣ���������ײ�����ʾ�ն����ߡ� */
                App_Ui_Pair(value, g_message_seconds);
                value[2] = 0;
                App_Ui_Text(20, CN_COUNTDOWN, half);
                App_Ui_Text(72, value, half);
                App_Ui_Text(88, CN_SECOND, half);
            }
            else
            {
                App_Ui_Center(g_title, half);
            }
        }
        else
        {
            value[0] = value[1] = value[3] = value[4] = value[6] = value[7] = '-';
            value[2] = value[5] = ':';
            value[8] = 0;
            if (!g_clock_status)
            {
                App_Ui_Pair(value, g_clock_time.hour);
                App_Ui_Pair(value + 3, g_clock_time.minute);
                App_Ui_Pair(value + 6, g_clock_time.second);
            }
            App_Ui_Big_Time(half, value);
        }
    }
    else if (line == 2)
    {
        if (g_message_seconds)
        {
            if (strlen(g_detail) == 12 && g_detail[0] >= '0' && g_detail[0] <= '9')
            {
                App_Ui_Text(4, CN_ID, half);
                App_Ui_Text(42, g_detail, half);
            }
            else
            {
                App_Ui_Center(g_detail, half);
            }
        }
        else if (g_clock_status)
        {
            App_Ui_Center(CN_CLOCK_INVALID, half);
        }
        else
        {
            App_Ui_Copy(value, "20YY-MM-DD");
            App_Ui_Pair(value + 2, g_clock_time.year);
            App_Ui_Pair(value + 5, g_clock_time.month);
            App_Ui_Pair(value + 8, g_clock_time.day);
            App_Ui_Text(4, value, half);
            App_Ui_Text(76, CN_USERS, half);
            value[0] = '0' + g_users;
            value[1] = 0;
            App_Ui_Text(110, value, half);
        }
    }
    else
    {
        if (g_mode)
        {
            if (g_seconds % 4 < 2)
            {
                App_Ui_Text(0, g_mode == 1 ? CN_SCAN_REGISTER : CN_SCAN_REMOVE, half);
                App_Ui_Pair(value, g_seconds);
                value[2] = 0;
                App_Ui_Text(90, value, half);
                App_Ui_Text(104, CN_SECOND, half);
            }
            else
            {
                App_Ui_Center(g_mode == 1 ? CN_REGISTER_EXIT : CN_REMOVE_EXIT, half);
            }
        }
        else if (g_db_status == ATT_BUSY)
        {
            App_Ui_Center(CN_DB_BUSY, half);
        }
        else if (g_db_status != ATT_OK && g_db_status != ATT_OFFLINE)
        {
            App_Ui_Center(CN_DB_ERROR, half);
        }
        else if (!g_network)
        {
            App_Ui_Center(CN_NETWORK_WAIT, half);
        }
        else if (!g_peer_online)
        {
            App_Ui_Center(g_role ? CN_COORD_OFFLINE : CN_PEER_OFFLINE, half);
        }
        else
        {
            /* ���м�����ģʽ������������ʾˢ������������������ */
            App_Ui_Center(g_clock_time.second % 6 < 3 ? CN_ATTENDANCE_HINT : CN_KEY_HINT, half);
        }
    }
}

void App_Ui_Init(uint8 terminal)
{
    g_role = terminal;
    g_error = Hal_Oled_Init();
    g_dirty = 1;
    g_clock_status = 5;
}

void App_Ui_Status(uint8 joined, uint8 peer, uint8 database, uint8 count, uint8 new_mode,
uint8 remaining_seconds)
{
    if (g_network != joined || g_peer_online != peer || g_db_status != database || g_users != count ||
    g_mode != new_mode || g_seconds != remaining_seconds)
    {
        g_dirty = 1;
    }
    g_network = joined;
    g_peer_online = peer;
    g_db_status = database;
    g_users = count;
    g_mode = new_mode;
    g_seconds = remaining_seconds;
}

void App_Ui_Time(const rtc_time_t *time, uint8 status)
{
    g_clock_time = *time;
    g_clock_status = status;
    g_dirty = 1;
}

void App_Ui_Message(const char *heading, const char *explanation)
{
    App_Ui_Copy(g_title, App_Ui_Chinese(heading));
    App_Ui_Copy(g_detail, App_Ui_Chinese(explanation));
    g_message_seconds = 5;
    g_dirty = 1;
}

void App_Ui_Second(void)
{
    if (g_message_seconds)
    {
        --g_message_seconds;
        /* ����ʱÿ���ػ棻����ʱ�ָ�ʵʱ���档 */
        g_dirty = 1;
    }
}

uint8 App_Ui_Error(void)
{
    return g_error;
}

/* �������д 31 �У�������ԭ���ķֶ�ˢ�£��������������塣 */
void App_Ui_Tick(void)
{
    uint8 count;
    if (g_error)
    {
        return;
    }
    if (!g_painting)
    {
        if (!g_dirty)
        {
            return;
        }
        g_dirty = 0;
        g_painting = 1;
        g_page = g_column = 0;
    }
    if (!g_column)
    {
        App_Ui_Render();
    }
    count = 128 - g_column;
    if (count > 31)
    {
        count = 31;
    }
    g_error = Hal_Oled_Write_Chunk(g_page, g_column, g_pixels + g_column, count);
    g_column += count;
    if (g_column == 128)
    {
        g_column = 0;
        if (++g_page == 8)
        {
            g_painting = 0;
        }
    }
}
