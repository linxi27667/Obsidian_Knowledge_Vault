"""根据本册源稿和源码快照生成可点击Markdown及排版PDF，不修改固件。"""
from pathlib import Path
import hashlib
import html
import json
import re
import sys

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, LongTable,
    TableStyle, PageBreak, Preformatted, Flowable
)
from reportlab.platypus.tableofcontents import TableOfContents

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
APP = ROOT / 'Texas Instruments/ZStack-CC2530-2.5.1a/Projects/zstack/Samples/SampleApp'
DATA = json.loads((HERE / '源码索引.json').read_text(encoding='utf-8'))
QAS = json.loads((HERE / '答辩问答.json').read_text(encoding='utf-8'))
FILES = {item['file']: item for item in DATA['files']}
FUNCTIONS = {(item['file'], func['name']): func for item in DATA['files'] for func in item['functions']}
EXTRA = {
    'Comm_Unicast_Init': '重置AF事务号和接收回调，配置16位单播目标地址及端点。',
    'Comm_Unicast_Send': '检查数据参数，调用AF_DataRequest；返回的是发送接受状态，不是业务提交结果。',
    'Comm_Unicast_RegisterCallback': '登记同步接收回调；不创建新的应用任务。',
    'Comm_Unicast_ProcessMSG': '提取源短地址和AF数据，存在回调时同步分发。',
    'Comm_Broadcast_Init': '重置广播事务和回调，配置广播目标及端点；当前核心业务未使用广播。',
    'Comm_Broadcast_Send': '按广播Cluster调用AF发送；不替代单播数据库事务。',
    'Comm_Broadcast_RegisterCallback': '注册广播业务回调；当前角色主文件没有启用广播业务回调。',
    'Comm_Broadcast_ProcessMSG': '有回调时提取并分发广播数据，否则不执行额外考勤业务。',
    'Comm_Protocol_ReadUint16': '从两个字节读取小端16位数；调用者保证缓冲长度。',
    'Comm_Protocol_WriteUint16': '把16位数写为低字节在前；用于会话、事务、代次及CRC。',
    'Comm_Protocol_CalcChecksum': 'CRC16初值FFFF、多项式1021，校验通信帧和数据库镜像。',
    'Comm_Protocol_PackFrame': '检查容量和载荷，填ATT2头、复制数据并追加CRC，失败返回0长度。',
    'Comm_Protocol_ValidateFrame': '检查空指针、帧长、头、版本、载荷长度和CRC，返回COMM域错误。',
    'Comm_Protocol_UnpackFrame': '验证后公开opcode及借用的数据指针，只在原消息有效期内使用。',
    'Device1_UART_Init': '仅重置解析回调，不重复初始化串口硬件。',
    'Device1_UART_SendData': '旧式发送入口，按给定长度进入HAL固定TX缓冲。',
    'Device1_UART_SendString': '旧式字符串发送入口，同样按长度转给HAL。',
    'UART_FindCMD': '找首个井号、确认尾部并去行尾空白，拒绝空命令和混入第二条命令。',
    'UART_GetCMDType': '分词后识别六类公开命令，归一DB动作及LOG CSV参数位置。',
    'UART_IsSeparator': '识别空格、TAB和冒号为参数分隔符。',
    'Device1_UART_ParseCMD': '复制命令到固定80字节体，最多分5项，参数指针仅当前同步回调有效。',
    'Device1_UART_ProcessCMD': '解析完整命令并同步调用已注册的业务回调。',
    'Device1_UART_RegisterCallback': '保存当前角色的业务处理函数指针。',
    'Hal_Key_Init': '只重置项目消抖状态，GPIO初始化由SDK负责。',
    'Hal_Key_Poll': '每10ms采样SDK键值，3次稳定后只返回新按下边沿，长按不重复。',
    'Hal_Buzzer_Init': '先写关闭电平再切GPIO输出，避免初始化脉冲。',
    'Hal_Buzzer_Bind': '登记蜂鸣器关闭事件的应用任务ID和事件位。',
    'Hal_Buzzer_On': 'P0.0高电平打开蜂鸣器，不负责业务持续时间。',
    'Hal_Buzzer_Off': 'P0.0低电平关闭蜂鸣器，供定时事件和失败清理调用。',
    'Hal_Buzzer_Beep': '关闭旧输出、停止旧计时，成功安排关闭事件后才响，资源失败保持静音。',
    'Hal_Delay_Us': '保留原NOP循环忙等接口，未用仪器校准，不用于长业务等待。',
    'Hal_Delay_Ms': '重复调用短忙等接口，当前主业务没有以此替代OSAL定时器。',
    'App_Coordinator_Network_Status': '按line分条输出网络和外设；由CONSOLE步骤推进，避免连续占满TX。',
    'App_Terminal_Network_Status': '按line分条输出终端网络和外设；串口STATUS设置输出步骤。',
    'App_Terminal_Hello': '发7字节数据库及模式概要，手动校时请求仅改变载荷标记，不破坏有效RTC。',
    'App_Coordinator_Command_Process': '检查就绪、TX空间和命令参数；TIME/DB分组复用原业务动作。',
    'App_Terminal_Command_Process': '执行本地查询及管理；独立校时被拒绝，TIME SYNC向协调器取时。'
}
MODULES = {
    'Source/Coordinator.c': '协调器任务文件', 'Source/EndDevice.c': '终端任务文件',
    'Source/SampleApp.h': '应用端点与事件配置', 'app/app_coordinator.c': '协调器业务模块',
    'app/app_terminal.c': '终端业务模块', 'app/app_database.c': '终端数据库模块',
    'app/app_host_store.c': '协调器统计模块', 'app/app_ui.c': '中文界面业务模块',
    'app/app_font.h': '中文点阵与文案', 'app/Common/device1_uart.c': '旧式串口解析模块',
    'app/Common/comm_unicast.c': '单播通信模块', 'app/Common/comm_broadcast.c': '广播接口模块',
    'app/Common/comm_protocol.c': 'ATT2编解码模块', 'hal/board/board_config.h': '集中引脚配置',
    'hal/hal_i2c.c': '软件I2C模块', 'hal/hal_eeprom.c': 'EEPROM驱动模块',
    'hal/hal_rtc.c': 'RTC驱动模块', 'hal/hal_rc522.c': 'RFID驱动模块',
    'hal/hal_oled.c': 'OLED硬件驱动模块', 'hal/hal_console_uart.c': 'UART缓冲模块',
    'hal/hal_board_key.c': '按键消抖模块', 'hal/hal_buzzer.c': '独立蜂鸣器模块',
    'hal/hal_delay.c': '保留的延时接口'
}
ORDER = ['Source/Coordinator.c','Source/EndDevice.c','app/app_coordinator.c','app/app_terminal.c',
         'app/Common/comm_unicast.c','app/Common/comm_broadcast.c','app/Common/comm_protocol.c',
         'app/Common/device1_uart.c','app/app_database.c','app/app_host_store.c',
         'app/app_ui.c','hal/hal_console_uart.c','hal/hal_board_key.c','hal/hal_buzzer.c',
         'hal/hal_i2c.c','hal/hal_eeprom.c','hal/hal_rtc.c','hal/hal_rc522.c','hal/hal_oled.c','hal/hal_delay.c']


def anchor(file, name):
    return 'fn_' + hashlib.sha1((file + '#' + name).encode()).hexdigest()[:14]


def ref_md(match):
    file, name = match[1].split('#')
    f = FUNCTIONS[file, name]
    return f'[{name} 第{f["start"]}行](<{(APP / file).as_posix()}:{f["start"]}>)'


def source_text(path):
    raw = path.read_bytes()
    for encoding in ['utf-8-sig', 'cp936']:
        try:
            return raw.decode(encoding).replace('\r\n', '\n')
        except UnicodeError:
            pass
    raise ValueError(path)


def code_md(match):
    file, tail = match[1].split('#')
    name, length = tail.rsplit(':', 1)
    f = FUNCTIONS[file, name]
    lines = source_text(APP / file).splitlines()
    if length.isdigit():
        excerpt = '\n'.join(lines[f['start'] - 1:f['start'] - 1 + int(length)])
    else:
        body = f['body']
        start = body.index('    if (events & ' + length + ')')
        opening = body.index('{', start)
        end = opening + 1
        depth = 1
        while depth:
            depth += (body[end] == '{') - (body[end] == '}')
            end += 1
        excerpt = body[start:end]
    return '以下为当前刷卡事件分支的实际代码，完整消息处理见源码定位。\n\n```c\n' + excerpt + '\n```'


def make_catalog():
    callers = {key: [] for key in FUNCTIONS}
    all_names = {key[1] for key in FUNCTIONS}
    for item in DATA['files']:
        for f in item['functions']:
            references = set(re.findall(r'\b\w+\b', f['body'])) & all_names
            for target in callers:
                if target[1] in references and target != (item['file'], f['name']):
                    callers[target].append(f['name'])
    parts = ['### 在用文件清单', '', '| 文件 | 行数 | 职责 |', '|---|---|---|']
    for item in DATA['files']:
        name = item['file']
        purpose = item['purpose'] or '配套类型、常量和公开接口，先与同名C文件对照。'
        if name.endswith('.h') and name not in ['app/app_font.h', 'Source/SampleApp.h', 'hal/board/board_config.h']:
            purpose = '同名实现的公开类型、常量和接口声明。'
        parts.append(f'| [{name}](<{(APP / name).as_posix()}>) | {item["lines"]} | {purpose} |')
    for file in ORDER:
        item = FILES[file]
        parts.extend(['', '### ' + MODULES[file], '', '文件：' + file + '。按以下源码顺序逐个函数阅读。',
                      '', '| 函数及定位 | 用途及引用关系 |', '|---|---|'])
        for f in item['functions']:
            name = f['name']; summary = EXTRA.get(name) or f['summary']
            assert summary, (file, name)
            referenced = sorted(set(callers[file, name]))
            if referenced:
                use = '被引用：' + '、'.join(referenced[:3]) + ('等' if len(referenced) > 3 else '') + '。'
            elif name in ['SampleApp_Init','SampleApp_ProcessEvent']:
                use = '由SDK任务注册与调度调用。'
            else:
                use = '当前自写主业务无引用，属于保留接口；测试或外部SDK引用需另查。'
            label = f'{name} 第{f["start"]}到{f["end"]}行'
            link = f'[{label}](<{(APP / file).as_posix()}:{f["start"]}>)'
            parts.append(f'| {link}<br> `{f["signature"]}` | {summary}<br>{use} |')
    parts.extend(['', '### SDK继续阅读入口', '',
                  '| 模块 | 从哪个入口继续 |', '|---|---|',
                  '| ZMain.c | main，硬件、AF和OSAL系统初始化 |',
                  '| OSAL_SampleApp.c | tasksArr、osalInitTasks，注册顺序 |',
                  '| OSAL.c及OSAL_Timers.c | osal_run_system、事件位、消息和定时器 |',
                  '| ZDApp.c及ZDO模块 | ZDApp_Init、ZDOInitDevice、ZDO_NETWORK_INIT、ZDO_StartDevice |',
                  '| AF.c | afRegister、AF_DataRequest，端点及发送分派 |',
                  '| hal_board_cfg.h | GAOCHANG_RC522_BOARD分支，LED及按键适配 |',
                  '| hal_led.c及hal_key.c | HalLedSet、HalKeyRead，直接SDK驱动 |',
                  '| hal_uart.c及_hal_uart_isr.c | HalUARTOpen、HalUARTRead、HalUARTWrite |',
                  '| f8wConfig.cfg及角色cfg | PAN、信道、安全、轮询与角色编译宏 |',
                  '| f8w2530.xcl与SampleApp.map | CODE银行、XDATA布局及实际占用 |'])
    assert sum(len(FILES[f]['functions']) for f in ORDER) == DATA['function_count']
    return '\n'.join(parts)


def make_md():
    text = (HERE / '正文源稿.md').read_text(encoding='utf-8')
    qa = []
    for i, row in enumerate(QAS, 1):
        qa.extend(['### 问题' + str(i) + ' ' + row['q'], '', row['a'], '',
                   '源码依据：' + '；'.join('{{REF:' + r + '}}' for r in row['refs']) + '。', ''])
    text = text.replace('{{QA}}', '\n'.join(qa)).replace('{{CATALOG}}', make_catalog())
    text = re.sub(r'\{\{CODE:([^}]+)\}\}', code_md, text)
    text = re.sub(r'\{\{REF:([^}]+)\}\}', ref_md, text)
    text = re.sub(r'\{\{FILE:([^}]+)\}\}', lambda m: f'[{m[1]}](<{(APP / m[1]).as_posix()}>)', text)
    # Markdown保留独立SVG图示，PDF直接画相同矢量结构。
    text = re.sub(r'\{\{FIG:(\w+)\}\}', lambda m: f'![{m[1]}流程示意](图示/{m[1]}.svg)', text)
    headings = re.findall(r'^## (.+)$', text, re.M)
    toc = '## 章节导航\n\n' + '\n'.join(f'- [{h}](#{re.sub(r"\s+", "-", h.strip()).lower()})' for h in headings) + '\n\n'
    first = text.index('## 如何使用')
    text = text[:first] + toc + text[first:]
    (HERE / 'RC522双端考勤代码阅读与答辩手册.md').write_text(text, encoding='utf-8')
    return text


pdfmetrics.registerFont(TTFont('Cn', 'C:/Windows/Fonts/msyh.ttc', subfontIndex=0))
pdfmetrics.registerFont(TTFont('CnBold', 'C:/Windows/Fonts/msyhbd.ttc', subfontIndex=0))
pdfmetrics.registerFont(TTFont('Code', 'C:/Windows/Fonts/consola.ttf'))
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyCn', fontName='Cn', fontSize=10.2, leading=16.2, spaceAfter=6, wordWrap='CJK'))
styles.add(ParagraphStyle(name='TitleCn', fontName='CnBold', fontSize=23, leading=33, spaceAfter=18))
styles.add(ParagraphStyle(name='H1Cn', fontName='CnBold', fontSize=15, leading=23, spaceBefore=17, spaceAfter=8, keepWithNext=True))
styles.add(ParagraphStyle(name='H2Cn', fontName='CnBold', fontSize=12, leading=19, spaceBefore=12, spaceAfter=6, keepWithNext=True))
styles.add(ParagraphStyle(name='SmallCn', fontName='Cn', fontSize=9, leading=13.5, spaceAfter=4, wordWrap='CJK'))
styles.add(ParagraphStyle(name='CellCn', fontName='Cn', fontSize=9, leading=13.3, wordWrap='CJK'))
styles.add(ParagraphStyle(name='CellHeadCn', fontName='CnBold', fontSize=9, leading=13.5, textColor=colors.white, wordWrap='CJK'))
styles.add(ParagraphStyle(name='CodeCn', fontName='Cn', fontSize=8.5, leading=12.5, leftIndent=8, spaceAfter=6, wordWrap='CJK'))


def inline(text):
    text = html.escape(text, quote=False)
    text = re.sub(r'\[([^\]]+)\]\(&lt;([^\n]+?)&gt;\)', lambda m: '<font color="#1C5964">' + m[1] + '</font>', text)
    text = re.sub(r'\[([^\]]+)\]\((https?://[^\s)]+)\)', lambda m: '<a href="' + m[2] + '" color="#1C5964">' + m[1] + '</a>', text)
    text = re.sub(r'\[([^\]]+)\]\(#[^)]+\)', r'\1', text)
    text = re.sub(r'`([^`]+)`', r'<font name="Code">\1</font>', text)
    text = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', text)
    return text.replace('&lt;br&gt;', '<br/>')


DIAGRAMS = {
    'architecture': [('协调器 CC2530','建网与统一时间','本机RC522读卡'),('终端 CC2530','名单与考勤权威端','本机RC522读卡'),('AT24C02','本机成功统计','双64字节镜像'),('AT24C08','8人及10条日志','双512字节镜像')],
    'local_scan': [('终端读卡','UID与瞬间RTC'),('本地执行','校验卡与当前模式'),('异步提交','写入 回读 最后标记'),('成功结果','显示 鸣叫 尝试通知')],
    'remote_scan': [('协调器读卡','保存UID与时间'),('ATT_SCAN请求','同会话事务重试'),('终端提交','唯一数据库保存'),('最终应答','匹配后显示并统计')],
    'commit': [('旧镜像有效','目标标记置0'),('写目标内容','每块回读校验'),('最终提交','最后写0xA5'),('新镜像活动','重启按代次选择')]
}


class Diagram(Flowable):
    def __init__(self, name):
        Flowable.__init__(self)
        self.name = name
        self.width = 490
        self.height = 170 if name == 'architecture' else 100

    def draw(self):
        c = self.canv
        nodes = DIAGRAMS[self.name]
        if self.name == 'architecture':
            positions = [(20, 95, 180, 70), (290, 95, 180, 70), (20, 2, 180, 57), (290, 2, 180, 57)]
            edges = [(200,130,290,130),(110,95,110,59),(380,95,380,59)]
        else:
            positions = [(i * 125, 25, 115, 65) for i in range(4)]
            edges = [(i * 125+115,58,(i+1)*125,58) for i in range(3)]
        c.setStrokeColor(colors.HexColor('#7F9EA3'))
        c.setLineWidth(.8)
        for x1,y1,x2,y2 in edges:
            c.line(x1,y1,x2,y2)
            if x2>x1:
                c.line(x2,y2,x2-4,y2+3);c.line(x2,y2,x2-4,y2-3)
                if self.name == 'architecture':
                    c.line(x1,y1,x1+4,y1+3);c.line(x1,y1,x1+4,y1-3)
            else:
                c.line(x2,y2,x2-3,y2+4);c.line(x2,y2,x2+3,y2+4)
        for node, (x,y,w,h) in zip(nodes,positions):
            c.setFillColor(colors.HexColor('#F4F8F8'))
            c.roundRect(x,y,w,h,5,stroke=1,fill=1)
            c.setFillColor(colors.black)
            for i,line in enumerate(node):
                c.setFont('CnBold' if i==0 else 'Cn', 10 if i==0 else 9)
                c.drawCentredString(x+w/2,y+h-20-i*16,line)
        if self.name=='architecture':
            c.setFont('Cn',8.5);c.drawCentredString(245,145,'Zigbee ATT2')


def make_svgs():
    folder = HERE / '图示';folder.mkdir(exist_ok=True)
    for name, nodes in DIAGRAMS.items():
        w=720;h=190 if name=='architecture' else 155
        svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">',
             '<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto-start-reverse"><path d="M0,0 L6,3 L0,6" fill="#62858b"/></marker></defs>',
             '<rect width="100%" height="100%" fill="white"/>']
        positions=[(20,15,280,70),(420,15,280,70),(20,125,280,55),(420,125,280,55)] if name=='architecture' else [(i*180+5,35,168,85) for i in range(4)]
        edges=[(300,50,420,50),(160,85,160,125),(560,85,560,125)] if name=='architecture' else [(i*180+173,77,(i+1)*180+5,77) for i in range(3)]
        for x1,y1,x2,y2 in edges:
            start = ' marker-start="url(#arrow)"' if name == 'architecture' and x2 > x1 else ''
            svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#62858b" stroke-width="1.5" marker-end="url(#arrow)"{start}/>')
        for node,(x,y,bw,bh) in zip(nodes,positions):
            svg.append(f'<rect x="{x}" y="{y}" width="{bw}" height="{bh}" rx="5" fill="#f4f8f8" stroke="#829ba0"/>')
            for i,line in enumerate(node):svg.append(f'<text x="{x+bw/2}" y="{y+23+i*20}" text-anchor="middle" font-family="Microsoft YaHei, sans-serif" font-size="{14 if i==0 else 12}" fill="black">{html.escape(line)}</text>')
        svg.append('</svg>');(folder/(name+'.svg')).write_text('\n'.join(svg),encoding='utf-8')


class Book(BaseDocTemplate):
    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph) and getattr(flowable, '_toc_level', None) is not None:
            level=flowable._toc_level;text=flowable.getPlainText();key=flowable._bookmark
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(text,key,level=level,closed=level>0)
            if level==0:self.notify('TOCEntry',(level,text,self.page,key))


def page_footer(canvas, doc):
    canvas.saveState();canvas.setFont('Cn',8);canvas.setFillColor(colors.HexColor('#667377'))
    canvas.drawString(18*mm,14*mm,'RC522双端考勤 代码阅读与答辩')
    canvas.drawRightString(192*mm,14*mm,str(doc.page))
    canvas.restoreState()


def table(rows, width, is_catalog=False):
    count=len(rows[0]);ratios={2:[.49,.51],3:[.44,.12,.44],4:[.18,.13,.19,.50],5:[.2,.12,.18,.22,.28]}
    if rows[0][0]=='项目':ratios[count]=[.18,.41,.41]
    if rows[0][0]=='功能':ratios[count]=[.20,.37,.43]
    if rows[0][0]=='区域':ratios[count]=[.26,.49,.25]
    if rows[0][0]=='偏移':ratios[count]=[.18,.13,.69]
    if rows[0][0]=='状态':ratios[count]=[.14,.34,.52]
    if rows[0][0]=='域':ratios[count]=[.19,.20,.61]
    if rows[0][0]=='值':ratios[count]=[.10,.23,.67]
    if rows[0][0]=='器件或信号':ratios[count]=[.31,.24,.45]
    if rows[0][0]=='字节偏移':ratios[count]=[.15,.10,.20,.55]
    if rows[0][0]=='载荷偏移':ratios[count]=[.20,.14,.66]
    if rows[0][0]=='文件':ratios[count]=[.46,.08,.46]
    if rows[0][0]=='事件':ratios[count]=[.19,.13,.25,.43]
    if rows[0][0]=='变量':ratios[count]=[.37,.15,.48]
    widths=[width*v for v in ratios.get(count,[1/count]*count)]
    cells=[[Paragraph(inline(value),styles['CellHeadCn'] if i==0 else styles['CellCn']) for value in row] for i,row in enumerate(rows)]
    t=LongTable(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
    commands=[('BACKGROUND',(0,0),(-1,0),colors.HexColor('#344D55')),
              ('GRID',(0,0),(-1,-1),.45,colors.HexColor('#D9D9D9')),
              ('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),7),
              ('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),
              ('BOTTOMPADDING',(0,0),(-1,-1),6)]
    for i in range(2,len(rows),2):commands.append(('BACKGROUND',(0,i),(-1,i),colors.HexColor('#F3F6F7')))
    t.setStyle(TableStyle(commands))
    return t


def make_pdf(text):
    path=HERE/'RC522双端考勤代码阅读与答辩手册.pdf'
    doc=Book(str(path),pagesize=(210*mm,297*mm),leftMargin=18*mm,rightMargin=18*mm,
             topMargin=18*mm,bottomMargin=21*mm,title='RC522双端Zigbee考勤系统代码阅读与答辩手册',author='课程设计代码阅读资料')
    frame=Frame(doc.leftMargin,doc.bottomMargin,doc.width,doc.height,id='body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
    doc.addPageTemplates(PageTemplate(id='normal',frames=[frame],onPage=page_footer))
    story=[];lines=text.splitlines();i=0;heading_count=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:i+=1;continue
        if line.startswith('# '):
            story.append(Paragraph('RC522双端Zigbee考勤系统',styles['TitleCn']))
            story.append(Paragraph('代码阅读与答辩手册',styles['TitleCn']));i+=1;continue
        if line=='## 章节导航':
            story.append(PageBreak());story.append(Paragraph('阅读目录',styles['H1Cn']))
            toc=TableOfContents();toc.levelStyles=[ParagraphStyle(name='TocCn',fontName='Cn',fontSize=10,leading=15,leftIndent=0,firstLineIndent=0,spaceBefore=2,spaceAfter=2)]
            story.append(toc);story.append(PageBreak());i+=1
            while i<len(lines) and not lines[i].startswith('## '):i+=1
            continue
        if line.startswith('## ') or line.startswith('### '):
            level=0 if line.startswith('## ') else 1
            label=line[3:] if level==0 else line[4:]
            heading_count+=1;p=Paragraph(inline(label),styles['H1Cn'] if level==0 else styles['H2Cn'])
            p._toc_level=level;p._bookmark='heading_'+str(heading_count)
            if label in ['答辩问题和回答依据','全部文件和函数阅读索引']:story.append(PageBreak())
            story.append(p);i+=1;continue
        if line.startswith('!['):
            m=re.search(r'图示/(\w+)\.svg',line)
            if m:story.extend([Spacer(1,4),Diagram(m[1]),Spacer(1,6)])
            i+=1;continue
        if line.startswith('```'):
            code=[];i+=1
            while i<len(lines) and not lines[i].startswith('```'):
                code.append(lines[i]);i+=1
            for row in code:
                story.append(Paragraph(html.escape(row).replace(' ','&#160;'),styles['CodeCn']))
            i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                row=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[:\-\s]+',v) for v in row):rows.append(row)
                i+=1
            assert all(len(row)==len(rows[0]) for row in rows),rows
            story.extend([table(rows,doc.width),Spacer(1,9)]);continue
        story.append(Paragraph(inline(line),styles['BodyCn']));i+=1
    doc.multiBuild(story)
    return path


def audit(text):
    refs=[]
    for link in re.findall(r'\]\(<([^>]+)>\)',text):
        if re.search(r':\d+$',link):link=re.sub(r':\d+$','',link)
        assert Path(link).is_file(),link
        refs.append(link)
    for item in DATA['files']:
        assert hashlib.sha256((APP/item['file']).read_bytes()).hexdigest()==item['sha256'], item['file']
        for f in item['functions']:
            assert f'[{f["name"]} 第{f["start"]}到{f["end"]}行]' in text,f['name']
    assert not re.search(r'\{\{(?:REF|FILE|CODE|QA|CATALOG)',text)
    report={'date':'2026-10-13','source_files':len(DATA['files']),'functions':DATA['function_count'],
            'defense_questions':len(QAS),'verified_source_links':len(refs),'firmware_unchanged':True,
            'line_numbers':'current source snapshot','hardware_validation':'not performed during document task'}
    (HERE/'文档内容核查.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))


if __name__=='__main__':
    make_svgs()
    text=make_md()
    audit(text)
    if '--markdown-only' not in sys.argv:print(make_pdf(text))
